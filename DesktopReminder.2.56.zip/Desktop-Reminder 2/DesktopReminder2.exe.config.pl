<?xml version="1.0" encoding="utf-8"?>

<configuration>
  <configSections>
    <sectionGroup name="userSettings" type="System.Configuration.UserSettingsGroup, System, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089">
      <section name="Polenter.DesktopReminder.Properties.Settings" type="System.Configuration.ClientSettingsSection, System, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" allowExeDefinition="MachineToLocalUser" requirePermission="false" />
    </sectionGroup>
    <sectionGroup name="applicationSettings" type="System.Configuration.ApplicationSettingsGroup, System, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089">
      <section name="Polenter.DesktopReminder.Properties.Settings" type="System.Configuration.ClientSettingsSection, System, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" requirePermission="false" />
    </sectionGroup>
  </configSections>
  <userSettings>
    <Polenter.DesktopReminder.Properties.Settings>
      <setting name="FirstDayOfWeek" serializeAs="String">
        <value>0</value>
      </setting>
      <setting name="ShowWeekNumbers" serializeAs="String">
        <value>False</value>
      </setting>
      <setting name="Version" serializeAs="String">
        <value />
      </setting>
      <setting name="SoundProfileMode" serializeAs="String">
        <value>0</value>
      </setting>
      <setting name="SoundProfileValidUntil" serializeAs="String">
        <value />
      </setting>
      <setting name="AutoCheckForUpdates" serializeAs="String">
        <value>True</value>
      </setting>
      <setting name="CurrentDatabaseFilename" serializeAs="String">
        <value />
      </setting>
      <setting name="RepeatedSoundFile" serializeAs="String">
        <value />
      </setting>
      <setting name="SingleSoundFile" serializeAs="String">
        <value />
      </setting>
      <setting name="MainFormSize" serializeAs="String">
        <value>750, 500</value>
      </setting>
      <setting name="MainFormLocation" serializeAs="String">
        <value>-1, -1</value>
      </setting>
      <setting name="MainFormMaximized" serializeAs="String">
        <value>False</value>
      </setting>
      <setting name="ProgramToken" serializeAs="String">
        <value />
      </setting>
      <setting name="UpdateVersion" serializeAs="String">
        <value />
      </setting>
      <setting name="UpdateUrl" serializeAs="String">
        <value />
      </setting>
      <setting name="UpdateLastCheck" serializeAs="String">
        <value />
      </setting>
      <setting name="HideImportWizard" serializeAs="String">
        <value>False</value>
      </setting>
      <setting name="IsProActive" serializeAs="String">
        <value>False</value>
      </setting>
      <setting name="CurrentCalendarViewInFreeMode" serializeAs="String">
        <value>1</value>
      </setting>
      <setting name="PrintPreviewSize" serializeAs="String">
        <value>750, 500</value>
      </setting>
      <setting name="PrintPreviewLocation" serializeAs="String">
        <value>-1, -1</value>
      </setting>
      <setting name="PrintPreviewMaximized" serializeAs="String">
        <value>False</value>
      </setting>
      <setting name="PrintPreviewShowOptions" serializeAs="String">
        <value>True</value>
      </setting>
      <setting name="SkinName" serializeAs="String">
        <value />
      </setting>
    </Polenter.DesktopReminder.Properties.Settings>
  </userSettings>
  <applicationSettings>
    <Polenter.DesktopReminder.Properties.Settings>
      <setting name="Culture" serializeAs="String">
        <value >pl-PL</value>
      </setting>
      <setting name="DesktopReminder_Polenter_Support_UpdateProviderService" serializeAs="String">
        <value>
          http://support.bitmit.eu:21080/UpdateProviderService/
        </value>
      </setting>
    </Polenter.DesktopReminder.Properties.Settings>
  </applicationSettings>
  <startup>
    <supportedRuntime version="v2.0.50727" />
  </startup>
</configuration>
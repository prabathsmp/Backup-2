function hideShowImage(spanID, imgID) {
  spanElement = document.getElementById(spanID);
  imgElement = document.getElementById(imgID);
  if (imgElement.style.display == "none") {
    imgElement.style.display = "";
    spanElement.innerHTML = "Hide image";
    spanElement.className = "imagehide";
  } else {
    imgElement.style.display = "none";
    spanElement.innerHTML = "Show image";
    spanElement.className = "imageshow";
  }
}

function hideShowElement(spanID, elementID) {
  spanElement = document.getElementById(spanID);
  targetElement = document.getElementById(elementID);
  if (targetElement.style.display == "none") {
    targetElement.style.display = "";
    spanElement.title = "Collapse section";
    spanElement.className = "sectioncollapse";
  } else {
    targetElement.style.display = "none";
    spanElement.title = "Expand section";
    spanElement.className = "sectionexpand";
  }
}

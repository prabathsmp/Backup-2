#include<hierarchicaldb.h>
#include<iostream>
using namespace std;

using namespace ci::hierarchicaldb

class CA
{
public:
CA();

~CA();
	int Loadxml();
	int displaynode();
};

int main()
{
CA obj;
obj.Load();
obj.displaynode();

CA::CA(){
}
CA::~CA(){
}

//1.	Load and parse an xml file. 
int CA::Load(){

	Status s_status;
	s_status=CreateDocument(/JobTemplates,&pNewDocument,10_BACKUP_TEMP100208);
	cout<<"Parsing xml file"<<endl;
	return 0;
}
//2.Get node from element node
int CA::displaynode(){
	NodeRef elementnode;
	CString nodename;
	elementnode=BindToElement(/JobTemplates,/JobTemplates/GroupList/Group[@gid="000"]/MetaData,false,false);
	cout<<"Binding to elementnode Metadata"<<endl;
	nodename=GetNodeValue(dom::JobTemplates,elementnode);
	cout<<"NodeName of elementnode ="<<nodename<<endl;
	return 0;
}

//3.Get the text from a text node.
int CA::displaytext(){
	CString nodename;
	 nodename=GetPathValue(dom::/JobTemplates,/JobTemplates/GroupList/Group[@gid="000"]/MetaData/groupName,true);
	 cout<<"Textnode value = "<<nodename<<endl;
	 return 0;
}
//4.4.	Change the text in a text node
int CA::replacetext(){
	Status status;
	CString nodename;
	if((status=BeginTransaction(dom::/JobTemplates, ci::hierarchicaldb::eWRITE))==OK)
        {					
		cout<<"node locked for write transaction"<<endl;
		SetNodeValue(dom::/JobTemplates,/JobTemplates/GroupList/Group[@gid="000"/MetaData/groupName,"NewSTRING");
		cout<<"Textnode value = "<<nodename<<endl;
		nodename=GetPathValue(dom::/JobTemplates,/JobTemplates/GroupList/Group[@gid="000"]/MetaData/groupName,true);
		cout<<"Textnode value = "<<nodename<<endl;
		if((status=EndTransaction(dom::/JobTemplates,ci::hierarchicaldb::eWRITE,false))!=OK)
		cout<<"error"<<endl;
		cout<<"node unlocked for write transaction"<<endl;
	}
	else 
		cout<<"error"<<endl;
	return 0;
}
//5. Read the an attribute value.
int CA::attribtevalue(){
	CString attr;
	Status status;
	if((status=BeginTransaction(dom::/JobTemplates,ci::hierarchicaldb::eWRITE))==OK)
        {	
		cout<<"node locked for Read transaction"<<endl;
		attr=GetAttributeValue(dom::/JobTemplates/GroupList/Group,/JobTemplates/GroupList/Group[@gid="000");
		cout<<"Attributenode value = "<<attr<<endl;
		if((status=EndTransaction(dom::/JobTemplates,ci::hierarchicaldb::eWRITE , false))!=OK)
		cout<<"error"<<endl;
		cout<<"node unlocked for write transaction"<<endl;
	}
	else
		cout<<"error"<<endl;
	return 0;
}
//6.Change an attribute value.



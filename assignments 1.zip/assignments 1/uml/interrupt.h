///////////////////////////////////////////////////////////
//  interrupt.h
//  Implementation of the Class interrupt
//  Created on:      14-Mar-2013 11:09:46
///////////////////////////////////////////////////////////

#if !defined(EA_4F93A632_71EF_460d_B55B_87CB5E94A5DF__INCLUDED_)
#define EA_4F93A632_71EF_460d_B55B_87CB5E94A5DF__INCLUDED_

#include "states.h"

class interrupt : public states
{

public:
	interrupt();
	virtual ~interrupt();

	void f_uninterrupt();

};
#endif // !defined(EA_4F93A632_71EF_460d_B55B_87CB5E94A5DF__INCLUDED_)

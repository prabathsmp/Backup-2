///////////////////////////////////////////////////////////
//  C_stateMN.cpp
//  Implementation of the Class C_stateMN
//  Created on:      18-Mar-2013 14:07:31
///////////////////////////////////////////////////////////

#include "C_stateMN.h"


C_stateMN::C_stateMN(){

}



C_stateMN::~C_stateMN(){

}





C_stateMN::stateMN(){

}


C_stateMN::~stateMN(){

}
///////////////////////////////////////////////////////////
//  C_interrupt.h
//  Implementation of the Class C_interrupt
//  Created on:      18-Mar-2013 14:08:23
///////////////////////////////////////////////////////////

#if !defined(EA_11391FC2_654C_4540_8A76_8262E6746875__INCLUDED_)
#define EA_11391FC2_654C_4540_8A76_8262E6746875__INCLUDED_

#include "C_states.h"

class C_interrupt : public C_states
{

public:
	C_interrupt();
	virtual ~C_interrupt();

	void f_uninterrupt();
	interrupt();
	virtual ~interrupt();

};
#endif // !defined(EA_11391FC2_654C_4540_8A76_8262E6746875__INCLUDED_)

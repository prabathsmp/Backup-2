///////////////////////////////////////////////////////////
//  run.cpp
//  Implementation of the Class run
//  Created on:      14-Mar-2013 11:09:04
///////////////////////////////////////////////////////////

#include "run.h"


run::run(){

}



run::~run(){

}





void run::f_cancel(){

}


void run::f_finish(){

}


void run::f_interrupt(){

}


void run::f_suspend(){

}
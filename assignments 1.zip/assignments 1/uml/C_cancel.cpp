///////////////////////////////////////////////////////////
//  C_cancel.cpp
//  Implementation of the Class C_cancel
//  Created on:      18-Mar-2013 14:08:31
///////////////////////////////////////////////////////////

#include "C_cancel.h"


C_cancel::C_cancel(){

}



C_cancel::~C_cancel(){

}





C_cancel::cancel(){

}


C_cancel::~cancel(){

}


void C_cancel::f_finish(){

}
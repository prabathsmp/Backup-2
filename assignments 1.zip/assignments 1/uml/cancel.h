///////////////////////////////////////////////////////////
//  cancel.h
//  Implementation of the Class cancel
//  Created on:      14-Mar-2013 11:10:02
///////////////////////////////////////////////////////////

#if !defined(EA_B72FAA5D_C1A1_4725_BBFF_94A0E72CFCE1__INCLUDED_)
#define EA_B72FAA5D_C1A1_4725_BBFF_94A0E72CFCE1__INCLUDED_

#include "states.h"

class cancel : public states
{

public:
	cancel();
	virtual ~cancel();

	void f_finish();

};
#endif // !defined(EA_B72FAA5D_C1A1_4725_BBFF_94A0E72CFCE1__INCLUDED_)

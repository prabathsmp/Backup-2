///////////////////////////////////////////////////////////
//  stateMN.cpp
//  Implementation of the Class stateMN
//  Created on:      14-Mar-2013 11:08:01
///////////////////////////////////////////////////////////

#include "stateMN.h"


stateMN::stateMN(){

}



stateMN::~stateMN(){

}





void stateMN::f_cancel(){

}


C_stateMN::C_stateMN(){

}



C_stateMN::~C_stateMN(){

}





C_stateMN::stateMN(){

}


C_stateMN::~stateMN(){

}
///////////////////////////////////////////////////////////
//  C_suspend.h
//  Implementation of the Class C_suspend
//  Created on:      18-Mar-2013 14:08:13
///////////////////////////////////////////////////////////

#if !defined(EA_1E643B68_A01A_4b75_B4EE_2F681F6B84C1__INCLUDED_)
#define EA_1E643B68_A01A_4b75_B4EE_2F681F6B84C1__INCLUDED_

#include "C_states.h"

class C_suspend : public C_states
{

public:
	C_suspend();
	virtual ~C_suspend();

	void f_cancel();
	void f_resume();
	suspend();
	virtual ~suspend();

};
#endif // !defined(EA_1E643B68_A01A_4b75_B4EE_2F681F6B84C1__INCLUDED_)

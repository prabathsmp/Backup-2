///////////////////////////////////////////////////////////
//  C_stateMN.h
//  Implementation of the Class C_stateMN
//  Created on:      18-Mar-2013 14:07:31
///////////////////////////////////////////////////////////

#if !defined(EA_72C5CD16_99A0_40ff_B57E_0754D62EDBEC__INCLUDED_)
#define EA_72C5CD16_99A0_40ff_B57E_0754D62EDBEC__INCLUDED_

class C_stateMN
{

public:
	C_stateMN();
	virtual ~C_stateMN();

	stateMN();
	virtual ~stateMN();

private:
	C_states* C_cancel;
	C_states* C_current_state;
	C_states* C_idle;
	C_states* C_interrupt;
	C_states* C_previous_state;
	C_states* C_run;
	C_states* C_suspend;

};
#endif // !defined(EA_72C5CD16_99A0_40ff_B57E_0754D62EDBEC__INCLUDED_)

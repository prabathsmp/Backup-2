///////////////////////////////////////////////////////////
//  cancel.cpp
//  Implementation of the Class cancel
//  Created on:      14-Mar-2013 11:10:02
///////////////////////////////////////////////////////////

#include "cancel.h"


cancel::cancel(){

}



cancel::~cancel(){

}





void cancel::f_finish(){

}
///////////////////////////////////////////////////////////
//  C_states.h
//  Implementation of the Class C_states
//  Created on:      18-Mar-2013 14:07:21
///////////////////////////////////////////////////////////

#if !defined(EA_87720823_A52F_45c3_ADA1_64C9BC13F0C3__INCLUDED_)
#define EA_87720823_A52F_45c3_ADA1_64C9BC13F0C3__INCLUDED_

#include "stateMN.h"

class C_states
{

public:
	C_states();
	virtual ~C_states();
	C_stateMN *m_C_stateMN;

	virtual void f_cancel();
	virtual void f_finish();
	virtual void f_init();
	virtual void f_interrupt();
	virtual void f_resume();
	virtual void f_suspend();
	virtual void f_uninterrupt();
	states();
	virtual ~states();

private:
	int sequence_no;
	C_stateMN* stateMN;

};
#endif // !defined(EA_87720823_A52F_45c3_ADA1_64C9BC13F0C3__INCLUDED_)

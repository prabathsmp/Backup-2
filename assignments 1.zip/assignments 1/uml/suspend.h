///////////////////////////////////////////////////////////
//  suspend.h
//  Implementation of the Class suspend
//  Created on:      14-Mar-2013 11:09:26
///////////////////////////////////////////////////////////

#if !defined(EA_36E69C76_3FB0_4014_B158_1531479A9E01__INCLUDED_)
#define EA_36E69C76_3FB0_4014_B158_1531479A9E01__INCLUDED_

#include "states.h"

class suspend : public states
{

public:
	suspend();
	virtual ~suspend();

	void f_cancel();
	void f_resume();

};
#endif // !defined(EA_36E69C76_3FB0_4014_B158_1531479A9E01__INCLUDED_)

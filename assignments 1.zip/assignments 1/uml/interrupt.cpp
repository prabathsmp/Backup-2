///////////////////////////////////////////////////////////
//  interrupt.cpp
//  Implementation of the Class interrupt
//  Created on:      14-Mar-2013 11:09:46
///////////////////////////////////////////////////////////

#include "interrupt.h"


interrupt::interrupt(){

}



interrupt::~interrupt(){

}





void interrupt::f_uninterrupt(){

}
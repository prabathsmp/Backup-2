///////////////////////////////////////////////////////////
//  idle.h
//  Implementation of the Class idle
//  Created on:      14-Mar-2013 11:08:51
///////////////////////////////////////////////////////////

#if !defined(EA_D3D9BBB2_0702_4591_84E9_3B1035564E84__INCLUDED_)
#define EA_D3D9BBB2_0702_4591_84E9_3B1035564E84__INCLUDED_

#include "states.h"

class idle : public states
{

public:
	idle();
	virtual ~idle();

	void f_cancel();
	void f_run();
	void f_suspend();

};
#endif // !defined(EA_D3D9BBB2_0702_4591_84E9_3B1035564E84__INCLUDED_)

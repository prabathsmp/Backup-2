///////////////////////////////////////////////////////////
//  idle.cpp
//  Implementation of the Class idle
//  Created on:      14-Mar-2013 11:08:51
///////////////////////////////////////////////////////////

#include "idle.h"


idle::idle(){

}



idle::~idle(){

}





void idle::f_cancel(){

}


void idle::f_run(){

}


void idle::f_suspend(){

}
///////////////////////////////////////////////////////////
//  run.h
//  Implementation of the Class run
//  Created on:      14-Mar-2013 11:09:04
///////////////////////////////////////////////////////////

#if !defined(EA_CA1C3854_3205_4eaf_9D42_E258FCD1B5AF__INCLUDED_)
#define EA_CA1C3854_3205_4eaf_9D42_E258FCD1B5AF__INCLUDED_

#include "states.h"

class run : public states
{

public:
	run();
	virtual ~run();

	void f_cancel();
	void f_finish();
	void f_interrupt();
	void f_suspend();

};
#endif // !defined(EA_CA1C3854_3205_4eaf_9D42_E258FCD1B5AF__INCLUDED_)

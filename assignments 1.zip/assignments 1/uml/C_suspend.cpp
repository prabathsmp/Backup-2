///////////////////////////////////////////////////////////
//  C_suspend.cpp
//  Implementation of the Class C_suspend
//  Created on:      18-Mar-2013 14:08:14
///////////////////////////////////////////////////////////

#include "C_suspend.h"


C_suspend::C_suspend(){

}



C_suspend::~C_suspend(){

}





void C_suspend::f_cancel(){

}


void C_suspend::f_resume(){

}


C_suspend::suspend(){

}


C_suspend::~suspend(){

}
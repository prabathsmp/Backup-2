///////////////////////////////////////////////////////////
//  C_idle.cpp
//  Implementation of the Class C_idle
//  Created on:      18-Mar-2013 14:07:56
///////////////////////////////////////////////////////////

#include "C_idle.h"


C_idle::C_idle(){

}



C_idle::~C_idle(){

}





void C_idle::f_cancel(){

}


void C_idle::f_init(){

}


void C_idle::f_suspend(){

}


C_idle::~idle(){

}


C_idle::idle(){

}
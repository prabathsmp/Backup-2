///////////////////////////////////////////////////////////
//  CNw_print_idle.h
//  Implementation of the Class CNw_print_idle
//  Created on:      18-Mar-2013 14:08:53
///////////////////////////////////////////////////////////

#if !defined(EA_DD3CE4C3_8BCE_48d9_A5D4_68BB78E9C60B__INCLUDED_)
#define EA_DD3CE4C3_8BCE_48d9_A5D4_68BB78E9C60B__INCLUDED_

#include "C_idle.h"

class CNw_print_idle : public C_idle
{

public:
	CNw_print_idle();
	virtual ~CNw_print_idle();

	void f_cancel();
	void f_init();
	void f_suspend();

};
#endif // !defined(EA_DD3CE4C3_8BCE_48d9_A5D4_68BB78E9C60B__INCLUDED_)

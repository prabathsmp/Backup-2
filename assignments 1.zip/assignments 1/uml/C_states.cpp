///////////////////////////////////////////////////////////
//  C_states.cpp
//  Implementation of the Class C_states
//  Created on:      18-Mar-2013 14:07:22
///////////////////////////////////////////////////////////

#include "C_states.h"


C_states::C_states(){

}



C_states::~C_states(){

}





void C_states::f_cancel(){

}


void C_states::f_finish(){

}


void C_states::f_init(){

}


void C_states::f_interrupt(){

}


void C_states::f_resume(){

}


void C_states::f_suspend(){

}


void C_states::f_uninterrupt(){

}


C_states::states(){

}


C_states::~states(){

}
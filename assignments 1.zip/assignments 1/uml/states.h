///////////////////////////////////////////////////////////
//  states.h
//  Implementation of the Class states
//  Created on:      14-Mar-2013 11:08:17
///////////////////////////////////////////////////////////

#if !defined(EA_61E51C64_5441_4023_AB1F_ADB3DC42A632__INCLUDED_)
#define EA_61E51C64_5441_4023_AB1F_ADB3DC42A632__INCLUDED_

#include "stateMN.h"

class states
{

public:
	states();
	virtual ~states();
	//stateMN *m_stateMN;

	virtual void f_cancel();
	virtual void f_finish();
	virtual void f_init();
	virtual void f_interrupt();
	virtual void f_resume();
	virtual void f_suspend();
	virtual void f_uninterrupt();

private:
	int sequence_no;
	stateMN* stateMN;

};
#endif // !defined(EA_61E51C64_5441_4023_AB1F_ADB3DC42A632__INCLUDED_)

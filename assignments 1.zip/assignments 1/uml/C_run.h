///////////////////////////////////////////////////////////
//  C_run.h
//  Implementation of the Class C_run
//  Created on:      18-Mar-2013 14:08:04
///////////////////////////////////////////////////////////

#if !defined(EA_DB511966_9BE0_4957_945C_E3E2F1F7FEDC__INCLUDED_)
#define EA_DB511966_9BE0_4957_945C_E3E2F1F7FEDC__INCLUDED_

#include "C_states.h"

class C_run : public C_states
{

public:
	C_run();
	virtual ~C_run();

	void f_cancel();
	void f_finish();
	void f_interrupt();
	void f_suspend();
	run();
	virtual ~run();

};
#endif // !defined(EA_DB511966_9BE0_4957_945C_E3E2F1F7FEDC__INCLUDED_)

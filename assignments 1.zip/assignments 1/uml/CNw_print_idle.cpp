///////////////////////////////////////////////////////////
//  CNw_print_idle.cpp
//  Implementation of the Class CNw_print_idle
//  Created on:      18-Mar-2013 14:08:53
///////////////////////////////////////////////////////////

#include "CNw_print_idle.h"


CNw_print_idle::CNw_print_idle(){

}



CNw_print_idle::~CNw_print_idle(){

}





void CNw_print_idle::f_cancel(){

}


void CNw_print_idle::f_init(){

}


void CNw_print_idle::f_suspend(){

}
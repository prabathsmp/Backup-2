///////////////////////////////////////////////////////////
//  C_cancel.h
//  Implementation of the Class C_cancel
//  Created on:      18-Mar-2013 14:08:31
///////////////////////////////////////////////////////////

#if !defined(EA_294C34BC_9391_4d0a_845A_274A76ADA9A9__INCLUDED_)
#define EA_294C34BC_9391_4d0a_845A_274A76ADA9A9__INCLUDED_

#include "C_states.h"

class C_cancel : public C_states
{

public:
	C_cancel();
	virtual ~C_cancel();

	cancel();
	virtual ~cancel();
	void f_finish();

};
#endif // !defined(EA_294C34BC_9391_4d0a_845A_274A76ADA9A9__INCLUDED_)

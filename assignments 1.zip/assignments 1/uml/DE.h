///////////////////////////////////////////////////////////
//  DE.h
//  Implementation of the Class DE
//  Created on:      18-Mar-2013 14:05:51
///////////////////////////////////////////////////////////

#if !defined(EA_1838E713_C2CD_41a8_9471_B7F81A14D142__INCLUDED_)
#define EA_1838E713_C2CD_41a8_9471_B7F81A14D142__INCLUDED_

#include "stateMN.h"

class DE
{

public:
	DE();
	virtual ~DE();
	C_stateMN* stateMN;
	
	int addtomap(int iseq);
	void deletemap();

};
#endif // !defined(EA_1838E713_C2CD_41a8_9471_B7F81A14D142__INCLUDED_)

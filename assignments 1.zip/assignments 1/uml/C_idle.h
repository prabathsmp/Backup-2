///////////////////////////////////////////////////////////
//  C_idle.h
//  Implementation of the Class C_idle
//  Created on:      18-Mar-2013 14:07:56
///////////////////////////////////////////////////////////

#if !defined(EA_1D059066_BA60_47b4_896E_FCD68057841C__INCLUDED_)
#define EA_1D059066_BA60_47b4_896E_FCD68057841C__INCLUDED_

#include "C_states.h"

class C_idle : public C_states
{

public:
	C_idle();
	virtual ~C_idle();

	virtual void f_cancel();
	void f_init();
	virtual void f_suspend();
	virtual ~idle();
	idle();

};
#endif // !defined(EA_1D059066_BA60_47b4_896E_FCD68057841C__INCLUDED_)

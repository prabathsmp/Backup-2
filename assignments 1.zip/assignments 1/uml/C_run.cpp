///////////////////////////////////////////////////////////
//  C_run.cpp
//  Implementation of the Class C_run
//  Created on:      18-Mar-2013 14:08:05
///////////////////////////////////////////////////////////

#include "C_run.h"


C_run::C_run(){

}



C_run::~C_run(){

}





void C_run::f_cancel(){

}


void C_run::f_finish(){

}


void C_run::f_interrupt(){

}


void C_run::f_suspend(){

}


C_run::run(){

}


C_run::~run(){

}
///////////////////////////////////////////////////////////
//  states.cpp
//  Implementation of the Class states
//  Created on:      14-Mar-2013 11:08:17
///////////////////////////////////////////////////////////

#include "states.h"


states::states(){

}



states::~states(){

}





void states::f_cancel(){

}


void states::f_finish(){

}


void states::f_init(){

}


void states::f_interrupt(){

}


void states::f_resume(){

}


void states::f_suspend(){

}


void states::f_uninterrupt(){

}
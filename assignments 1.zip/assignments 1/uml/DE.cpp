///////////////////////////////////////////////////////////
//  DE.cpp
//  Implementation of the Class DE
//  Created on:      18-Mar-2013 14:05:51
///////////////////////////////////////////////////////////

#include "DE.h"


DE::DE(){

}



DE::~DE(){

}





int DE::addtomap(int iseq){
//map<int, string> Employees;

	return 0;
}


void DE::deletemap(){

}
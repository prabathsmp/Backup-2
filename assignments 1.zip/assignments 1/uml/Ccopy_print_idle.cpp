///////////////////////////////////////////////////////////
//  Ccopy_print_idle.cpp
//  Implementation of the Class Ccopy_print_idle
//  Created on:      18-Mar-2013 14:08:44
///////////////////////////////////////////////////////////

#include "Ccopy_print_idle.h"


Ccopy_print_idle::Ccopy_print_idle(){

}



Ccopy_print_idle::~Ccopy_print_idle(){

}





void Ccopy_print_idle::f_cancel(){

}


void Ccopy_print_idle::f_init(){

}


void Ccopy_print_idle::f_suspend(){

}
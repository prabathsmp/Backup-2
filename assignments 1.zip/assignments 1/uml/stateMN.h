///////////////////////////////////////////////////////////
//  stateMN.h
//  Implementation of the Class stateMN
//  Created on:      14-Mar-2013 11:08:01
///////////////////////////////////////////////////////////

#if !defined(EA_C04140AF_29F0_4710_AFDC_AA4CCAFC4811__INCLUDED_)
#define EA_C04140AF_29F0_4710_AFDC_AA4CCAFC4811__INCLUDED_

class stateMN
{

public:
	stateMN();
	virtual ~stateMN();

	
private:
	states* cancel;
	states* current_state;
	states* idle;
	states* interrupt;
	states* previous_state;
	states* run;
	states* suspend;
	//states* current_states;

};

class C_stateMN
{

public:
	C_stateMN();
	virtual ~C_stateMN();

	stateMN();
	virtual ~stateMN();

private:
	C_states* C_cancel;
	C_states* C_current_state;
	C_states* C_idle;
	C_states* C_interrupt;
	C_states* C_previous_state;
	C_states* C_run;
	C_states* C_suspend;

};
#endif // !defined(EA_C04140AF_29F0_4710_AFDC_AA4CCAFC4811__INCLUDED_)

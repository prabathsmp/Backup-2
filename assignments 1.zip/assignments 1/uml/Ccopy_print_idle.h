///////////////////////////////////////////////////////////
//  Ccopy_print_idle.h
//  Implementation of the Class Ccopy_print_idle
//  Created on:      18-Mar-2013 14:08:44
///////////////////////////////////////////////////////////

#if !defined(EA_D155AF47_0689_4210_89E4_4A0F67FA59F3__INCLUDED_)
#define EA_D155AF47_0689_4210_89E4_4A0F67FA59F3__INCLUDED_

#include "C_idle.h"

class Ccopy_print_idle : public C_idle
{

public:
	Ccopy_print_idle();
	virtual ~Ccopy_print_idle();

	void f_cancel();
	void f_init();
	void f_suspend();

};
#endif // !defined(EA_D155AF47_0689_4210_89E4_4A0F67FA59F3__INCLUDED_)

///////////////////////////////////////////////////////////
//  C_interrupt.cpp
//  Implementation of the Class C_interrupt
//  Created on:      18-Mar-2013 14:08:23
///////////////////////////////////////////////////////////

#include "C_interrupt.h"


C_interrupt::C_interrupt(){

}



C_interrupt::~C_interrupt(){

}





void C_interrupt::f_uninterrupt(){

}


C_interrupt::interrupt(){

}


C_interrupt::~interrupt(){

}
///////////////////////////////////////////////////////////
//  suspend.cpp
//  Implementation of the Class suspend
//  Created on:      14-Mar-2013 11:09:26
///////////////////////////////////////////////////////////

#include "suspend.h"


suspend::suspend(){

}



suspend::~suspend(){

}





void suspend::f_cancel(){

}


void suspend::f_resume(){

}
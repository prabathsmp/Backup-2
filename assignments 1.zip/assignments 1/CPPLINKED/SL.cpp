///////////////////////////////////////////////////////////
//  SL.cpp
//  Implementation of the Class SL
//  Created on:      27-Feb-2013 15:56:53
///////////////////////////////////////////////////////////
template<class x>
#include "SL.h"


SL<x>::SL()
{
	cout<<"SL Constructor"<<endl;
}



SL<x>::~SL()
{
	freedown();
	cout<<"SL Destructor"<<endl;
}





int SL<x>::operator+(x val)
{


	node *temp=createnode(val);
	if(!head)
		head=temp;
	else
		tail->next=temp;
	tail=temp;
	display();
	return 0;
}
void SL<x>::deletev(x val)
{
//	x value;
	node *trav1;
	node *trav2;
	node *temp;
	trav2=trav1=head;
	for(temp=head;temp->value!=val;temp=temp->next)
	{
		trav2=trav1;
		trav1=trav1->next;
		if(!trav1)
		{
			cout<<"Enter the valid position"<<endl;
			break;
		}
	}
	if(trav1)
	{ 
		if(trav1==head)
		{
			head=head->next;
			if(head==NULL)
				tail=NULL;
			delete(trav1);
			trav1=NULL;
		}
		else
		{
			trav2->next=trav1->next;
			if(trav1==tail)
				tail=trav2;
			delete(trav1);
			trav1=NULL;
		}	
	}
}

void SL<x>::insert(x val,int pos)
{
	int c=0;
	node *trav1;
	node *trav2;
	node *temp=createnode(val);
	if(pos<1 ||!head)
		cout<<"position error"<<endl;
	else
	{
		trav2=trav1=head;
		int i;
		for(i=1;i<pos && trav1;i++)
		{
			trav2=trav1;
			trav1=trav1->next;
			if(!trav1)
			{
				cout<<" Enter the valid position"<<endl;
				c=1;
			}
			if(c==1)
				break;
		}
		if(trav2 && trav1!=head)
		{
			trav2->next=temp;
			temp->next=trav1;
		}
		else
		{
			temp->next=trav1;
			head=temp;
		}
	}
}

void SL<x>::deletep(int pos)
{
	int i;
	node *trav1;
	node *trav2;
	if(pos<1 ||!head)
		cout<<"position error"<<endl;
	else if(pos==1)
	{
		trav1=head;
		head=head->next;
		if(head==NULL)
			tail=NULL;
		delete(trav1);
		trav1=NULL;
		//	display();
	}
	else
	{
		trav2=trav1=head;
		for(i=1;i<pos;i++)
		{
			trav2=trav1;
			trav1=trav1->next;
			if(!trav1)
			{
				cout<<"Enter the valid position"<<endl;
				break;
			}
		}
		if(trav1)
		{
			trav2->next=trav1->next;
			if(trav1==tail)
				tail=trav2;
			delete(trav1);
			trav1=NULL;
		}
		//		display();	
	}
}

node* SL<x>:: createnode(x val)
{
	//x value;
	node *temp=new node;

	if(temp)
	{
		temp->value=val;
		temp->next=NULL;
		return temp;
	}
}

int SL<x>:: display()
{
	//x value;
	node *temp;
	for(temp=head;temp;temp=temp->next)
		cout<<temp->value<<"\t";
	return 0;
}
void SL<x>::freedown()
{
	node *temp;
	for(temp=head;temp;temp=temp->next)
		delete(temp);
	head=NULL;
	tail=NULL;

}

/*main()
  {
  SL obj;
  list *ptr=&obj;
  int w;
  cout<<"Enter the choice="<<endl;
  cin>>w;
  switch(w)
  {
  case 1:
  ptr->addnode();
  break;
  case 2:ptr->display();
  break;
  case 5:
  ptr->freedown();
  exit(1);
  }	
  }  */

///////////////////////////////////////////////////////////
//  DL.h
//  Implementation of the Class DL
//  Created on:      27-Feb-2013 15:57:07
///////////////////////////////////////////////////////////

#if !defined(EA_CC0A267F_4B12_4e33_998A_E2B50FAB1B5A__INCLUDED_)
#define EA_CC0A267F_4B12_4e33_998A_E2B50FAB1B5A__INCLUDED_

/*#include<iostream>
#include<cstdlib>
#include "list.h"
using namespace std;*/
#include"list.h"
template<class T>
class DL:public list<T>
{
public:
	DL();
	virtual ~DL();
	node<T> *head;
        node<T> *tail;
	int operator+(T val);
	int display();
	node<T> *createnode(T val);
	void deletep(int pos);
	void deletev(T val);
	void insert(T val,int pos);
	void freedown();
};
template<class T>
DL<T>::DL(){
	head=NULL;
	tail=NULL;
	cout<<"DL ctor"<<endl;
}


template<class T>
DL<T>::~DL(){
	cout<<"DL destructor"<<endl;
	freedown();
}



template<class T>
node<T> *DL<T>::createnode(T val)
{
	node<T> *temp=new node<T>;

	if(temp)
	{
		temp->value=val;
		temp->next=NULL;
		temp->prev=NULL;
		return temp;
	}
}

template<class T>
int DL<T>::operator+(T val)
{

	node<T> *temp=createnode(val);
	if(temp)
	{
		if(!head)
		{
			head=temp;
			head->prev=NULL;
			head->next=NULL;
		}
		else
		{
			tail->next=temp;
			temp->prev=tail;
		}
		tail=temp;

		display();
	}
}


template<class T>
void DL<T>::deletep(int pos)
{
	int i,c=0;
	node<T> *trav1;
	node<T> *trav2;
	node<T> *trav3;
	if(pos<1 ||!head)
	{
		cout<<"position error"<<endl;
	}
	else if(pos==1)
	{
		trav1=head;
		head=head->next;
		head->prev=NULL;
		if(head==NULL)
		{
			head->next=NULL;
			head->prev=NULL;
			tail=NULL;
		}
		delete(trav1);
	}
	else
	{
		trav2=trav1=head;
		for(i=1;i<pos;i++)
		{
			trav2=trav1;
			trav1=trav1->next;
			if(!trav1)
			{
				cout<<" Enter the valid position"<<endl;
				c==1;
			}
			if(c==1)
				break;
		}


		trav3=trav1->next;
		if(!trav3)
		{
			trav2->next=NULL;
			tail=trav2;
			delete(trav1);
		}
		if(trav1 && trav2 && trav3)
		{
			trav2->next=trav3;
			trav3->prev=trav2;

			if(trav1==tail)
				tail=trav2;
			delete(trav1);
		}

	}
}
template<class T>
void DL<T>::insert(T val,int pos)
{
	int c=0;
	node<T> *trav1;
	node<T> *trav2;
	node<T> *temp=createnode(val);
	if(temp)
	{
		if(pos<1 ||!head)
			cout<<"position error"<<endl;
		else
		{
			trav2=trav1=head;
			int i;
			for(i=1;i<pos && trav1;i++)
			{
				trav2=trav1;
				trav1=trav1->next;
				if(!trav1)
				{
					cout<<"Enter the Valid Position"<<endl;
					c=1;
				}
				if(c==1)
					break;
			}
			if(trav2 && trav1!=head)
			{
				trav2->next=temp;
				temp->prev=trav2;
				temp->next=trav1;
				trav1->prev=temp;
			}
			else
			{
				temp->next=trav1;
				head=temp;
				temp->prev=NULL;
			}
		}
	}
}
template<class T>
void DL<T>::deletev(T val)
{
	node<T> *trav1=NULL;
	node<T> *trav2=NULL;
	trav1=trav2=head;
	if(trav1 && trav1->value==val)
	{
		head=head->next;
		head->prev=NULL;
		if(!head)
			tail=NULL;
		delete(trav1);
	}
	else if(trav1 && trav2)
	{
		while(trav1 && (trav1->value!=val))
		{
			trav2=trav1;
			trav1=trav1->next;
		}
		if(trav1==tail)
		{
			tail=trav2;
			trav2->next=NULL;
			trav1->prev=NULL;
			delete(trav1);
		}
		else if(trav1)
		{
			trav2->next=trav1->next;
			(trav1->next)->prev=trav2;
			delete(trav1);
		}
		else
			cout<<"Invalid"<<endl;

	}
	else
		cout<<"\nEmpty List"<<endl;

}

template<class T>
int DL<T>::display()
{
	node<T> *temp;
	for(temp=head;temp;temp=temp->next)
		cout<<temp->value<<"\t";
	return 0;
}
template<class T>
void DL<T>::freedown()
{
	node<T> * temp;
	for(temp=head;temp;temp=temp->next)
		delete(temp);
	head=NULL;
	tail=NULL;
}

#endif // !defined(EA_CC0A267F_4B12_4e33_998A_E2B50FAB1B5A__INCLUDED_)

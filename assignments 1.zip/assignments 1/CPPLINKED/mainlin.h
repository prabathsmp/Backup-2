//#include"DL.h"
#include"SL.h"
//#include"CL.h"
//#include <fstream>
//using std::ifstream;
//using std::ofstream;
void menu();
//ostream & operator<<(/*std::*/ostream &os,list *a);


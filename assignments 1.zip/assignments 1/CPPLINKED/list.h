///////////////////////////////////////////////////////////
//  list.h
//  Implementation of the Class list
//  Created on:      27-Feb-2013 15:56:26
///////////////////////////////////////////////////////////

#if !defined(EA_C01242EC_38DB_475d_AB07_746ABBFB6E84__INCLUDED_)
#define EA_C01242EC_38DB_475d_AB07_746ABBFB6E84__INCLUDED_

//#include "SL.h"
//#include "DL.h"
//#include "CL.h"
/*
#include<iostream>
#include "node.cpp"
using namespace std;
*/
#include<iostream>
#include<cstdlib>
#include<malloc.h>
#include"node.h"
using namespace std;

template<class T>
class list
{
public:
	list();
	virtual ~list();
	node<T> *head;
	//node *temp;
	node<T> *tail;

	virtual int operator+(T val);
	virtual node<T> *createnode(T val);
	virtual int display();
	virtual void deletep(int pos);
	virtual void deletev(T val);
	virtual void insert(T val,int pos);
	virtual void freedown();

};

template<class T>
list<T>::list()
{
        cout<<"list ctor"<<endl;
	
}

template<class T>
list<T>:: ~list()
{

}

template<class T>
int list<T>::operator+(T val)
{

        return 0;
}

template<class T>
int list<T>::display()
{
        node<T> *temp;
        for(temp=head;temp;temp=temp->next)
                cout<<temp->value<<endl;

        return 0;
}

template<class T>
node<T> *list<T>::createnode(T val)
{
        return NULL;
}

template<class T>
void list<T>::deletep(int pos)
{
}

template<class T>
void list<T>::deletev(T val)
{

}

template<class T>
void list<T>::insert(T val,int pos)
{

}

template<class T>
void list<T>::freedown(){
if(head)
        {               node<T> *temp=head;
                for(;temp!=NULL;temp=temp->next)
                        delete(temp);
 	}
}

#endif // !defined(EA_C01242EC_38DB_475d_AB07_746ABBFB6E84__INCLUDED_)

///////////////////////////////////////////////////////////
//  CL.h
//  Implementation of the Class CL
//  Created on:      27-Feb-2013 15:57:51
///////////////////////////////////////////////////////////

#if !defined(EA_F6565940_C608_48e8_AEB9_DA76F3FC7A1A__INCLUDED_)
#define EA_F6565940_C608_48e8_AEB9_DA76F3FC7A1A__INCLUDED_
#include"list.h"
class CL:public list
{

public:
	CL();
	virtual ~CL();

	int operator+(int val);
	int display();
        node* createnode(int val);
        void deletep(int pos);
        void deletev(int val);
        void insert(int val,int pos);
        void freedown();
};
#endif // !defined(EA_F6565940_C608_48e8_AEB9_DA76F3FC7A1A__INCLUDED_)

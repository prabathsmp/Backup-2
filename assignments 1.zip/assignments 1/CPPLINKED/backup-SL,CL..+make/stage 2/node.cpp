///////////////////////////////////////////////////////////
//  node.cpp
//  Implementation of the Class node
//  Created on:      27-Feb-2013 15:58:41
///////////////////////////////////////////////////////////

#include "node.h"


node::node(){
		//cout<<"NODE constructor"<<endl;

}



node::~node(){
		//cout<<"NODE destructor"<<endl;

}

node *getNext()
{
	return this->next;
}
int getValue()
{
	return this->value;
}




/*node node::createnode(int value){

	return  NULL;
}


void node::getdata(int getdata){

}


void node::setdata(int setdata){

}*/

#include"mainlin.h"
void menu()
{
	cout<<endl<<"1->APPEND"<<endl;
	cout<<"\t2->DELETEp"<<endl;
	cout<<"\t\t3->DELETEv"<<endl;
	cout<<"\t\t\t4->INSERT"<<endl;
	cout<<"\t\t\t\t5->DISPLAY"<<endl;
	cout<<"\t\t\t\t\t6->FREEDOWN"<<endl;
	cout<<"\t\t\t\t\t\t7->exit"<<endl;
}
int main()
{
	menu();
	list *ptr=new DL;
	int q;
	while(1)
	{

		int val=0,pos=0;
		cout<<"Enter the choice="<<endl;
		cin>>q;
		switch(q)
		{
			case 1:
				cout<<"Enter the value:"<<endl;
				cin>>val;

				ptr->addnode(val);
				break;
			case 2:
				cout<<"Enter the position:"<<endl;
				cin>>pos;

				ptr->deletep(pos);
				break;
			case 3:
				cout<<"Enter the value:"<<endl;
				cin>>val;

				ptr->deletev(val);
				break;
			case 4:
				cout<<"Enter the value:"<<endl;
				cin>>val;
				cout<<"Enter the position:"<<endl;
				cin>>pos;

				ptr->insert(val,pos);
				break;
			case 5:
				ptr->display();
				break;
			case 6:
				ptr->freedown();
				break;
			case 7:
				exit(1);


		}
		menu();
	}
	delete ptr;
	return 0;
}


///////////////////////////////////////////////////////////
//  node.h
//  Implementation of the Class node
//  Created on:      27-Feb-2013 15:58:41
///////////////////////////////////////////////////////////

#if !defined(EA_708042F5_E2C7_421f_BF5C_948990EC8A7A__INCLUDED_)
#define EA_708042F5_E2C7_421f_BF5C_948990EC8A7A__INCLUDED_
//template<class x>
class SL;
class CL;
class DL;
//template<class x>
class list;
//template<class x>
class node
{
int value;
node* next;
node* prev;
public:	
node();
    ~node();
     node *getNext();
     int getValue();

	/*node* createnode(int );
	void getdata(int getdata);
	void setdata(int setdata);*/
friend class list;
friend class SL;
friend class CL;
friend class DL;

//friend ostream & operator<<(ostream &,list *);


};
#endif // !defined(EA_708042F5_E2C7_421f_BF5C_948990EC8A7A__INCLUDED_)

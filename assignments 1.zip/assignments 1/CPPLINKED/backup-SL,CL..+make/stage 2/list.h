///////////////////////////////////////////////////////////
//  list.h
//  Implementation of the Class list
//  Created on:      27-Feb-2013 15:56:26
///////////////////////////////////////////////////////////

#if !defined(EA_C01242EC_38DB_475d_AB07_746ABBFB6E84__INCLUDED_)
#define EA_C01242EC_38DB_475d_AB07_746ABBFB6E84__INCLUDED_

//#include "SL.h"
//#include "DL.h"
//#include "CL.h"
/*
#include<iostream>
#include "node.cpp"
using namespace std;
*/
#include<iostream>
#include<cstdlib>
#include<malloc.h>
#include"node.h"
using namespace std;
//template<class x>
class list
{

public:
	list();
	virtual ~list();
	node *head;
	//node *temp;
	node *tail;

	virtual int operator+(int val);
	virtual node *createnode(int val);
	virtual int display();
	virtual void deletep(int pos);
	virtual void deletev(int val);
	virtual void insert(int val,int pos);
	virtual void freedown();

};
#endif // !defined(EA_C01242EC_38DB_475d_AB07_746ABBFB6E84__INCLUDED_)

///////////////////////////////////////////////////////////
//  CL.cpp
//  Implementation of the Class CL
//  Created on:      27-Feb-2013 15:57:51
///////////////////////////////////////////////////////////

#include "CL.h"


CL::CL(){
	head=NULL;
	cout<<"CL constructor "<<endl;
}



CL::~CL(){
	freedown();
	cout<<"CL destructor "<<endl;
}
node* CL::createnode(int val)
{
	node *temp=new node;

	if(temp)
	{
		temp->value=val;
		temp->next=temp;
		return temp;
	}
}
int CL::operator+(int val)
{
	node *trav1=NULL;
//	cout<<"enter the value"<<endl;
//	cin>>val;
	node *temp=createnode(val);
	if(!head)
		head=temp;
	//	temp->next=NULL;
	else
	{
		for(trav1=head;trav1->next!=head;trav1=trav1->next);
		trav1->next=temp;
		temp->next=head;
	}
	display();
}
void CL::deletev(int val)
{

//	cout<<"Enter the value:";
//	cin>>val;
	node *trav1=NULL,*trav2=NULL;
        trav1=trav2=head;
        if(trav1 && trav1->value==val)
        {
                if(trav1->next==trav1)
                {
                        trav1->next=NULL;
                        delete(trav1);
                        head=NULL;
                }
                else
                {
                        for(trav1=head;trav1->next!=head;trav1=trav1->next);
                        head=head->next;
                        trav1->next->next=NULL;
                        delete(trav1->next);
                        trav1->next=head;

                }
        }
        else if(trav1 && trav2)
        {
                do
                {
                        trav2=trav1;
                        trav1=trav1->next;
                }while(trav1!=head && (trav1->value!=val));

                if(trav1 != head)
                {
                        trav2->next=trav1->next;
                        delete(trav1);
                }
                else
                        cout<<"Invalid id"<<endl;
        }
        else
                cout<<"\n Empty list"<<endl;
}
void CL::deletep(int pos)
{
	int i;
//	cout<<" Enter the position of the node to be deleted:"<<endl;
//	cin>>pos;
	node *temp=NULL;
	node *trav1=NULL,*trav2=NULL;
	if(pos<1 || !head)
		cout<<"Position error"<<endl;
	else if(pos==1)   
	{
		if(head->next==head)
		{
			head->next=NULL;
			delete(head);
			head=NULL;
		}
		else
		{
			for(trav1=head;trav1->next!=head;trav1=trav1->next);
			head=head->next;
			trav1->next->next=NULL;
			delete(trav1->next);
			trav1->next=head;
		}

	}
	else
	{
		trav1=trav2=head;
		for(i=1;i<pos;i++)
		{
			trav2=trav1;
			trav1=trav1->next;
		}
		if(trav1)
		{
			if(trav1->next==head)
			{
				trav2->next=head;
				trav1->next=NULL;
				delete(trav1);
			}
			else
			{
				trav2->next=trav1->next;
				delete(trav1);
			}
		}
		else
			cout<<" Position Error.."<<endl;
	}
}	


void CL::insert(int val,int pos)
{
	int c=0;
	node *trav1;
	node *trav2;
//	cout<<" Enter a value .. "<<endl;
//	cin>>value;
	node *temp=createnode(val);
//	cout<<"Enter the position to be inseted:"<<endl;
//	cin>>pos;
	if(pos<1 ||!head)
		cout<<"position error"<<endl;
	else
	{
		trav2=trav1=head;
		int i;
		for(i=1;i<pos && trav1;i++)
		{
			trav2=trav1;
			trav1=trav1->next;
			if(!trav1)
			{
			cout<<"Position Error"<<endl;
			c=1;
			}
		if(c==1)
		break;
		}
		if(trav2 && trav1!=head)
		{
			trav2->next=temp;
			temp->next=trav1;
		}
		else
		{
		node *trav=head;
		for(;trav->next!=head;trav=trav->next);
			temp->next=trav1;
			head=temp;
			trav->next=head;
		}
	}
}

int CL::display()
{
	if(head)
	{
		node *temp=head;
		for(;temp->next!=head;temp=temp->next)
			cout<<temp->value;
		cout<<temp->value<<"\t";
	}
}
void CL::freedown()
{
	if(head)
	{
		node *temp=head;
		for(;temp && temp->next!=head;temp=temp->next)
		delete(temp);
		head=NULL;     
		
		
	}
}

///////////////////////////////////////////////////////////
//  SL.cpp
//  Implementation of the Class SL
//  Created on:      27-Feb-2013 15:56:53
///////////////////////////////////////////////////////////

#include "SL.h"


SL::SL()
{
	cout<<"SL Constructor"<<endl;
}



SL::~SL()
{
	 cout<<"SL Destructor"<<endl;
}





int SL::addnode()
{
	int value;
	cout<<"Enter a value .. "<<endl;
	cin>>value;
	node *temp=createnode(value);
	if(!head)
		head=temp;
	else
		tail->next=temp;
	tail=temp;
	display();
	return 0;
}
void SL::deletev()
{

int val;
cout<<"Enter the element to be deleted:"<<endl;
cin>>val;
node *trav1;
node *trav2;
node *temp;
	trav2=trav1=head;
		for(temp=head;temp->value!=val;temp=temp->next)
		{
			trav2=trav1;
			trav1=trav1->next;
			if(!trav1)
			{
			cout<<"Enter the valid position"<<endl;
			break;
			}
		}
		if(trav1)
		{ 
			if(trav1==head)
			{
			head=head->next;
			if(head==NULL)
			tail=NULL;
			free(trav1);
			trav1=NULL;
				}
			else
			{
			trav2->next=trav1->next;
			if(trav1==tail)
				tail=trav2;
			free(trav1);
			trav1=NULL;
			}	
		}
}

void SL::insert()
{
int value,pos,c=0;
node *trav1;
node *trav2;
cout<<"Enter a value .. "<<endl;
cin>>value;
node *temp=createnode(value);
cout<<"Enter the position to be inseted:"<<endl;
cin>>pos;
        if(pos<1 ||!head)
			cout<<"position error"<<endl;
 	else
        {
                trav2=trav1=head;
		int i;
                for(i=1;i<pos && trav1;i++)
                {
                        trav2=trav1;
                        trav1=trav1->next;
			if(!trav1)
			{
			cout<<" Enter the valid position"<<endl;
			c=1;
			}
                if(c==1)
		break;
		}
                if(trav2 && trav1!=head)
		{
		trav2->next=temp;
		temp->next=trav1;
		}
		else
		{
		temp->next=trav1;
		head=temp;
	        }
	}
}

void SL::deletep()
{
	int i,pos;
	 node *trav1;
	 node *trav2;
	cout<<"Enter the position to be deleted:"<<endl;
	cin>>pos;
	if(pos<1 ||!head)
		cout<<"position error"<<endl;
	else if(pos==1)
	{
		trav1=head;
		head=head->next;
		if(head==NULL)
			tail=NULL;
		free(trav1);
		trav1=NULL;
//	display();
	}
	else
	{
		trav2=trav1=head;
		for(i=1;i<pos;i++)
		{
			trav2=trav1;
			trav1=trav1->next;
			if(!trav1)
			{
			cout<<"Enter the valid position"<<endl;
			break;
			}
		}
		if(trav1)
		{
			trav2->next=trav1->next;
			if(trav1==tail)
				tail=trav2;
			free(trav1);
			trav1=NULL;
		}
//		display();	
	}
}
node* SL :: createnode(int value)
{
	node *temp=(node *)malloc(sizeof(node));
	
	if(temp)
	{
	temp->value=value;
	temp->next=NULL;
	return temp;
	}
}

int SL :: display()
{
 node *temp;
 for(temp=head;temp;temp=temp->next)
 cout<<temp->value<<"\t";
 return 0;
}
void SL::freedown()
{
node *temp;
	for(temp=head;temp;temp=temp->next)
		free(temp);
	head=NULL;
	tail=NULL;
	
}

/*main()
{
SL obj;
list *ptr=&obj;
int w;
cout<<"Enter the choice="<<endl;
cin>>w;
switch(w)
{
		case 1:
			ptr->addnode();
			break;
		case 2:ptr->display();
			break;
		case 5:
			ptr->freedown();
			exit(1);
	}	
}  */

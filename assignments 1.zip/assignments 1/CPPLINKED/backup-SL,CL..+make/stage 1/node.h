///////////////////////////////////////////////////////////
//  node.h
//  Implementation of the Class node
//  Created on:      27-Feb-2013 15:58:41
///////////////////////////////////////////////////////////

#if !defined(EA_708042F5_E2C7_421f_BF5C_948990EC8A7A__INCLUDED_)
#define EA_708042F5_E2C7_421f_BF5C_948990EC8A7A__INCLUDED_

class node
{

public:	
	int value;
	node* next;
	node* prev;
	node();
    ~node();

	//node* createnode(int );
	void getdata(int getdata);
	void setdata(int setdata);

};
#endif // !defined(EA_708042F5_E2C7_421f_BF5C_948990EC8A7A__INCLUDED_)

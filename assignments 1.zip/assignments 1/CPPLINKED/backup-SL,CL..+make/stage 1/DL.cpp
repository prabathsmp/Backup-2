///////////////////////////////////////////////////////////
//  DL.cpp
//  Implementation of the Class DL
//  Created on:      27-Feb-2013 15:57:07
///////////////////////////////////////////////////////////

#include "DL.h"


DL::DL(){
head=NULL;
tail=NULL;
cout<<"DL ctor"<<endl;
}



DL::~DL(){

}



node* DL :: createnode(int value)
{
	node *temp=(node *)malloc(sizeof(node));
	
	if(temp)
	{
	temp->value=value;
	temp->next=NULL;
	temp->prev=NULL;
	return temp;
	}
}

int DL::addnode()
{

	int value;
	cout<<"Enter a value .. "<<endl;
	cin>>value;
	node *temp=createnode(value);
	if(temp)
	{
	if(!head)
	{
		head=temp;
		head->prev=NULL;
		head->next=NULL;
	}	
	else
	{	
		tail->next=temp;
		temp->prev=tail;	
		//	temp->next=NULL;
	}	
	tail=temp;

	display();
	}	
}
	

void DL::deletep()
{
int pos,i,c=0;
	node *trav1;
	node *trav2;
	node *trav3;
	cout<<"Enter the position to be deleted:"<<endl;
	cin>>pos;
	if(pos<1 ||!head)
	{
		cout<<"position error"<<endl;
		addnode();
	}
	else if(pos==1)
	{
		trav1=head;
		head=head->next;
		head->prev=NULL;
		if(head==NULL)
		{
			head->next=NULL;
			head->prev=NULL;
			tail=NULL;
		}
		free(trav1);
		//display();
	}
	else
        {
                trav2=trav1=head;
                for(i=1;i<pos;i++)
                {
                        trav2=trav1;
                        trav1=trav1->next;
                        if(!trav1)
                        {
                        cout<<" Enter the valid position"<<endl;
                        c==1;
                        }
 if(c==1)
                                break;
                }


                        trav3=trav1->next;
                        if(!trav3)
                        {
                        trav2->next=NULL;
                        tail=trav2;
                        free(trav1);
                        }
                        if(trav1 && trav2 && trav3)
                        {
                                trav2->next=trav3;
                                trav3->prev=trav2;

                                if(trav1==tail)
                                        tail=trav2;
 free(trav1);
                        }

                } 
}
void DL::insert()
{
	int value,pos,c=0;
	node *trav1;
	node *trav2;
	cout<<" Enter a value .. "<<endl;
	cin>>value;
	node *temp=createnode(value);
	if(temp)
	{
	cout<<"Enter the position to be inseted:"<<endl;
	cin>>pos;
	if(pos<1 ||!head)
		cout<<"position error"<<endl;
	else
	{
		trav2=trav1=head;
		int i;
		for(i=1;i<pos && trav1;i++)
		{
			trav2=trav1;
			trav1=trav1->next;
			if(!trav1)
			{
			cout<<"Enter the Valid Position"<<endl;
			c=1;
			}
		if(c==1)
		break;
		}
		if(trav2 && trav1!=head)
		{
			trav2->next=temp;
			temp->prev=trav2;
			temp->next=trav1;
			trav1->prev=temp;
		}
		else
		{
		temp->next=trav1;
		head=temp;
		temp->prev=NULL;
	}
	}
	}
}
void DL::deletev()
{
	int val;
	cout<<"Enter the value:";
	cin>>val;
	node *trav1=NULL,*trav2=NULL;
        trav1=trav2=head;
        if(trav1 && trav1->value==val)
        {
                head=head->next;
                head->prev=NULL;
                if(!head)
                        tail=NULL;
                free(trav1);
        }
        else if(trav1 && trav2)
        {
                while(trav1 && (trav1->value!=val))
                {
                        trav2=trav1;
                        trav1=trav1->next;
                }
                if(trav1==tail)
                {
                        tail=trav2;
                        trav2->next=NULL;
                        trav1->prev=NULL;
                        free(trav1);
                }
                else if(trav1)
                {
                        trav2->next=trav1->next;
                        (trav1->next)->prev=trav2;
                        free(trav1);
                }
                else
                        cout<<"Invalid"<<endl;

        }
        else
                cout<<"\nEmpty List"<<endl;

}	
				
int DL::display()
{
 node *temp;
 for(temp=head;temp;temp=temp->next)
 cout<<temp->value<<"\t";
 return 0;
}				
void DL::freedown()
{
node * temp;
	for(temp=head;temp;temp=temp->next)
		free(temp);
	head=NULL;
	tail=NULL;
}
//#include"SL.cpp"

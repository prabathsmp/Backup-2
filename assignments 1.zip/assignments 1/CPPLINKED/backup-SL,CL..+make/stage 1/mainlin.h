#include"list.h"
#include"node.h"
#include"DL.h"
#include"SL.h"
#include"CL.h"
void menu();

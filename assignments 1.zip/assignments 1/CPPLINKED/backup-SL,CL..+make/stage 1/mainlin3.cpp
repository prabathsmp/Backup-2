#include"mainlin.h"
void menu()
{
        cout<<endl<<"1->APPEND"<<endl;
        cout<<"\t2->DELETEp"<<endl;
        cout<<"\t\t3->DELETEv"<<endl;
        cout<<"\t\t\t4->INSERT"<<endl;
        cout<<"\t\t\t\t5->DISPLAY"<<endl;
        cout<<"\t\t\t\t\t6->FREEDOWN"<<endl;
        cout<<"\t\t\t\t\t\t7->exit"<<endl;
}
int main()
{
        menu();
	//CL obj;
	//list *ptr=&obj;
	list *ptr=new CL;
        int q;
        while(1)
        {
                cout<<"Enter the choice="<<endl;
                cin>>q;
                switch(q)
                {
                        case 1:
                                ptr->addnode();
                                break;
                        case 2:
                                ptr->deletep();
                                break;
                        case 3:
                                ptr->deletev();
                                break;
                        case 4:
                                ptr->insert();
                                break;
                        case 5:
                                ptr->display();
                                break;
                        case 6:
				 ptr->freedown();
                                break;
                        case 7:
                                exit(1);


                }
                menu();
        }
delete ptr;
return 0;
}


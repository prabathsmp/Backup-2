	///////////////////////////////////////////////////////////
//  DL.h
//  Implementation of the Class DL
//  Created on:      27-Feb-2013 15:57:07
///////////////////////////////////////////////////////////

#if !defined(EA_CC0A267F_4B12_4e33_998A_E2B50FAB1B5A__INCLUDED_)
#define EA_CC0A267F_4B12_4e33_998A_E2B50FAB1B5A__INCLUDED_

#include<iostream>
#include<cstdlib>
#include "list.h"
using namespace std;

class DL :public list
{

public:
	DL();
	virtual ~DL();
	int addnode();
    int display();
	 node* createnode(int value);
	void deletep();
	void deletev();
	void insert();
	void freedown();
};
#endif // !defined(EA_CC0A267F_4B12_4e33_998A_E2B50FAB1B5A__INCLUDED_)

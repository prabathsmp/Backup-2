///////////////////////////////////////////////////////////
//  list.cpp
//  Implementation of the Class list
//  Created on:      27-Feb-2013 15:56:26
///////////////////////////////////////////////////////////
//nclude<cstdlib>
#include "list.h"


list::list(){
	cout<<"list ctor"<<endl;
}



list::~list(){

}





int list::addnode(){

	return 0;
}


int list::display(){
/*	node *temp;
	for(temp=head;temp;temp=temp->next)
		cout<<temp->value<<endl;
*/
	return 0;
}

node *list::createnode(int iid)
{
	return NULL;
}

void list::deletep()
{
 //return NULL;
}

void list::deletev()
{
 //return NULL;
}
void list::insert()
{
//return NULL;
}
void list::freedown(){
if(head)
        {
                node*temp=head;
                for(;temp!=NULL;temp=temp->next)
                        free(temp);
                //free(temp);
        }
}

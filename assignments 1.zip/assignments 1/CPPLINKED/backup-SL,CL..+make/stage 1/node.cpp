///////////////////////////////////////////////////////////
//  node.cpp
//  Implementation of the Class node
//  Created on:      27-Feb-2013 15:58:41
///////////////////////////////////////////////////////////

#include "node.h"


node::node(){

}



node::~node(){

}





/*node node::createnode(int value){

	return  NULL;
}*/


void node::getdata(int getdata){

}


void node::setdata(int setdata){

}

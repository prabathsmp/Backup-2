///////////////////////////////////////////////////////////
//  SL.h
//  Implementation of the Class SL
//  Created on:      27-Feb-2013 15:56:53
///////////////////////////////////////////////////////////

#if !defined(EA_BFF9161D_BBCB_48cc_85DC_72608B8322F5__INCLUDED_)
#define EA_BFF9161D_BBCB_48cc_85DC_72608B8322F5__INCLUDED_



#include"list.h"

class SL : public list
{

public:
	SL();
	
	virtual ~SL();
	
	int addnode();
    	int display();
	node* createnode(int value);
	void deletep();
	void deletev();
	void insert();
	void freedown();
};
#endif // !defined(EA_BFF9161D_BBCB_48cc_85DC_72608B8322F5__INCLUDED_)

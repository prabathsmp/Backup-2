#include "DL.cpp"
#include "node.cpp"


int main()
{
	list *l = new DL();
	l->addnode();
}

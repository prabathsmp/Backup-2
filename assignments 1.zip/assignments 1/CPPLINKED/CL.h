///////////////////////////////////////////////////////////
//  CL.h
//  Implementation of the Class CL
//  Created on:      27-Feb-2013 15:57:51
///////////////////////////////////////////////////////////

#if !defined(EA_F6565940_C608_48e8_AEB9_DA76F3FC7A1A__INCLUDED_)
#define EA_F6565940_C608_48e8_AEB9_DA76F3FC7A1A__INCLUDED_
#include"list.h"
template<class T>
class CL:public list<T>
{

public:
	CL();
	virtual ~CL();
	node<T> *head;
	int operator+(T val);
	int display();
        node<T> *createnode(T val);
        void deletep(int pos);
        void deletev(T val);
        void insert(T val,int pos);
        void freedown();
};
template<class T>
CL<T>::CL(){
        head=NULL;
        cout<<"CL constructor "<<endl;
}

template<class T>
CL<T>::~CL(){
        freedown();
        cout<<"CL destructor "<<endl;
}
template<class T>
node<T> *CL<T>::createnode(T val)
{
        node<T> *temp=new node<T>;

        if(temp)
        {
                temp->value=val;
                temp->next=temp;
                return temp;
        }
}
template<class T>
int CL<T>::operator+(T val)
{
        node<T> *trav1=NULL;
 node<T> *temp=createnode(val);
        if(!head)
                head=temp;
 else
        {
                for(trav1=head;trav1->next!=head;trav1=trav1->next);
                trav1->next=temp;
                temp->next=head;
        }
        display();
}
template<class T>
void CL<T>::deletev(T val)
{
 node<T> *trav1=NULL;
        node<T> *trav2=NULL;
        trav1=trav2=head;
        if(trav1 && trav1->value==val)
        {
                if(trav1->next==trav1)
                {
                        trav1->next=NULL;
                        delete(trav1);
                        head=NULL;
                }
                else
                {
                        for(trav1=head;trav1->next!=head;trav1=trav1->next);
                        head=head->next;
                        trav1->next->next=NULL;
                        delete(trav1->next);
                        trav1->next=head;

                }
        }
        else if(trav1 && trav2)
{
                do
                {
                        trav2=trav1;
                        trav1=trav1->next;
                }while(trav1!=head && (trav1->value!=val));

                if(trav1 != head)
                {
                        trav2->next=trav1->next;
                        delete(trav1);
                }
                else
                        cout<<"Invalid id"<<endl;
        }
        else
                cout<<"\n Empty list"<<endl;
}
template<class T>
void CL<T>::deletep(int pos)
{
        int i;
node<T> *temp=NULL;
        node<T> *trav1=NULL;
	node<T> *trav2=NULL;
        if(pos<1 || !head)
                cout<<"Position error"<<endl;
        else if(pos==1)
        {
                if(head->next==head)
                {
                        head->next=NULL;
                        delete(head);
                        head=NULL;
                }
                else
                {
                        for(trav1=head;trav1->next!=head;trav1=trav1->next);
                        head=head->next;
                        trav1->next->next=NULL;
                        delete(trav1->next);
                        trav1->next=head;
                }

        }
 else
        {
                trav1=trav2=head;
                for(i=1;i<pos;i++)
                {
                        trav2=trav1;
                        trav1=trav1->next;
                }
                if(trav1)
                {
                        if(trav1->next==head)
                        {
                                trav2->next=head;
                                trav1->next=NULL;
                                delete(trav1);
                        }
                        else
                        {
                                trav2->next=trav1->next;
                                delete(trav1);
                        }
                }
                else
                        cout<<" Position Error.."<<endl;
        }
}
template<class T>
void CL<T>::insert(T val,int pos)
{
        int c=0;
        node<T> *trav1;
        node<T> *trav2;
node<T> *temp=createnode(val);
 if(pos<1 ||!head)
                cout<<"position error"<<endl;
        else
        {
                trav2=trav1=head;
                int i;
                for(i=1;i<pos && trav1;i++)
                {
trav2=trav1;
                        trav1=trav1->next;
                        if(!trav1)
                        {
                        cout<<"Position Error"<<endl;
                        c=1;
                        }
                if(c==1)
                break;
                }
                if(trav2 && trav1!=head)
                {
                        trav2->next=temp;
                        temp->next=trav1;
                }
                else
                {
                node<T> *trav=head;
                for(;trav->next!=head;trav=trav->next);
                        temp->next=trav1;
                        head=temp;
                        trav->next=head;
                }
        }
}
template<class T>
int CL<T>::display()
{
        if(head)
        {
                node<T> *temp=head;
                for(;temp->next!=head;temp=temp->next)
                        cout<<temp->value;
                cout<<temp->value<<"\t";
        }
}
template<class T>
void CL<T>::freedown()
{
        if(head)
        {
                node<T> *temp=head;
                for(;temp && temp->next!=head;temp=temp->next)
                delete(temp);
                head=NULL;


        }
}


#endif // !defined(EA_F6565940_C608_48e8_AEB9_DA76F3FC7A1A__INCLUDED_)

#include"SL.h"
void menu()
{
	cout<<endl<<"1->APPEND"<<endl;
	cout<<"\t2->DELETEp"<<endl;
	cout<<"\t\t3->DELETEv"<<endl;
	cout<<"\t\t\t4->INSERT"<<endl;
	cout<<"\t\t\t\t5->DISPLAY"<<endl;
	cout<<"\t\t\t\t\t6->FREEDOWN"<<endl;
	cout<<"\t\t\t\t\t\t7->exit"<<endl;
}

/*template<class x>
x entry()
{
	x val;
 	cout<<"Enter the value:"<<endl;
 	cin>>val;
	return val;
}*/

/*void menu1()
  {
  cout<<"1->SINGLEl"<<endl;
  cout<<"2->DOUBLEl"<<endl;
  cout<<"3->CIRCULAR"<<endl;
  }*/
int main()
{ 
	menu(); 
//		SL obj1;
//	list *ptr=&obj1;
	list<float> *ptr= dynamic_cast<list<float>*> (new SL<float>());
	int q;
	while(1)
	{
		float val=0;
		int pos=0;
		cout<<"Enter the choice="<<endl;
		cin>>q;
		switch(q)
		{
			case 1:
				//ut<<"Enter the value:"<<endl;
				//n>>val;
			        cout<<"Enter the value:"<<endl;
        			cin>>val;

				//val=entry();
			//	ptr->addnode(val);
				ptr->operator+(val);
			
				break;
			case 2:
				cout<<"Enter the position:"<<endl;
				cin>>pos;
				ptr->deletep(pos);
				
				break;
			case 3:
				cout<<"Enter the value:"<<endl;
				cin>>val;
			//	val=entry();
				ptr->deletev(val);
				break;
			case 4:
				cout<<"Enter the value:"<<endl;
				cin>>val;
				cout<<"Enter the position:"<<endl;
				cin>>pos;
			//	val=entry();
				ptr->insert(val,pos);
				break;
			case 5:
				ptr->display();
				//d::cout<<obj1<<std::endl;
				break;
			case 6:
				ptr->freedown();
				break;
			case 7:
				exit(1);


		}
		menu();
	}
//	delete ptr;	
	return 0;
}
/*main()
  {
  int w;
  menu1();
  while(1)
  {
  cout<<"Enter the choice="<<endl;
  cin>>w;
  switch(w)
  {
  case 1:
  cout<<"single linked list"<<endl;
  SL obj1;
  list ptr*=&obj1;
  menu2();
  iter();
  break;
  case 2:
  cout<<"Doubledlinked list "<<endl;
  DL obj2;
  list *ptr=&obj2;
  menu2();
  iter(ptr);
  break;
  case 3:			cout<<"circular linked list"<<endl;
  CL obj3;
  list ptr*=&obj3;
  menu2();
  iter();

  case 4:	break;	
  exit(1);
  }
  }
  }*/

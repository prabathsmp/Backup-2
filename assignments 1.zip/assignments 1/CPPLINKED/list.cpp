///////////////////////////////////////////////////////////
//  list.cpp
//  Implementation of the Class list
//  Created on:      27-Feb-2013 15:56:26
///////////////////////////////////////////////////////////
//nclude<cstdlib>
#include "list.h"

template<class T>
list<T>::list(){
	cout<<"list ctor"<<endl;
}


template<class T>
list<T>::~list(){

}

template<class T>
int list<T>::operator+(T val){

	return 0;
}
template<class T>
int list<T>::display()
{
	node<T> *temp;
	for(temp=head;temp;temp=temp->next)
		cout<<temp->value<<endl;

	return 0;
}

template<class T>
node<T> *list::createnode(T iid)
{
	return NULL;
}

template<class T>
void list<T>::deletep(int pos)
{
 //return NULL;
}
template<class T>
void list<T>::deletev(T val)
{
 //return NULL;
}
template<class T>
void list<T>::insert(T val,int pos)
{
//return NULL;
}

template<class T>
void list<T>::freedown(){
if(head)
        {
                node<T> *temp=head;
                for(;temp!=NULL;temp=temp->next)
                        delete(temp);
                //free(temp);
        }
}

#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<pthread.h>
#include<string.h>
#include<errno.h>
void* pthread_fun(void* arg);
char mesg[]="HELL BOY";
int main()
{
        pthread_t tid;
	pid_t pid;
        int res,s;
         int stack_size;

        stack_size=0x3000000;
        void *sp;
        void* pthread_result;
		pthread_attr_t attr;
		pthread_attr_t *attrp;
		
	pid = getpid();

	printf("\n pid =%ld",pid);	
	/*	
if((s=pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED))!=0)
        {
                printf("\n error in detach state");
        } 
if((s=pthread_attr_setinheritsched(&attr,PTHREAD_EXPLICIT_SCHED))!=0)
        {
                printf("\n error in inherit schd");
        }

        
 if((s=pthread_attr_setstack(&attr,sp,stack_size))!=0)
        {
	      printf("\n error in setstack");
        }*/
        //sleep(2);
	pthread_attr_init(&attrp);
	//	pthread_attr_t attr;
	//	exit(1);
       
     /* if((s=pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED))!=0)
        {
                printf("\n error in detach state");
        }
if((s=pthread_attr_setinheritsched(&attr,PTHREAD_EXPLICIT_SCHED))!=0)
        {
                printf("\n error in inherit schd");
        }


 if((s=pthread_attr_setstack(&attr,sp,stack_size))!=0)
        {
              printf("\n error in setstack");
         }*/
          
        res=pthread_create(&tid,NULL,&pthread_fun,(void *)mesg);

if(res!=0)
{
        printf("error\n");
        exit(1);
}
        printf("waitng for thread to finish\n");
        res=pthread_join(tid,&pthread_result);
if(res!=0)
{
        printf("join failed\n");
        exit(1);
}
        printf("thread joined successfullyit returned=%s\n",(char *)pthread_result);
        printf("message is now%s\n",mesg);
 if (attrp != NULL) {
               s = pthread_attr_destroy(attrp);      
    if((s=pthread_attr_destroy(&attr))==-1)
                        printf("\n error in pthread destroy");

       res=pthread_detach(tid); 
if(res=0)
{
        printf("thread detached\n");
        return 0;
}


}

void display_pthread_attr(pthread_attr_t *attr,char *prefix)
{
        int s,i;
        size_t v;
        void* stkaddr;
        struct sched_param sp;

        if((s=pthread_attr_getdetachstate(attr,&i))!=0)
        printf("\n error in pthread get detachstate");
        printf("%sDetach state        = %s\n", prefix,
                   (i == PTHREAD_CREATE_DETACHED) ? "PTHREAD_CREATE_DETACHED" :
                   (i == PTHREAD_CREATE_JOINABLE) ? "PTHREAD_CREATE_JOINABLE" :"??");
        s = pthread_attr_getscope(attr, &i);
           if (s != 0)
               printf("\n error in getscopre");
           printf("%sScope               = %s\n", prefix,
                   (i == PTHREAD_SCOPE_SYSTEM)  ? "PTHREAD_SCOPE_SYSTEM" :
                   (i == PTHREAD_SCOPE_PROCESS) ? "PTHREAD_SCOPE_PROCESS" :
                   "???");

           s = pthread_attr_getinheritsched(attr, &i);
           if (s != 0)
               printf("\n error in inherited sched");
           printf("%sInherit scheduler   = %s\n", prefix,
                   (i == PTHREAD_INHERIT_SCHED)  ? "PTHREAD_INHERIT_SCHED" :
                   (i == PTHREAD_EXPLICIT_SCHED) ? "PTHREAD_EXPLICIT_SCHED" :
                   "???");

           s = pthread_attr_getschedpolicy(attr, &i);
           if (s != 0)
               printf("\n error in scheduling policy");
           printf("%sScheduling policy   = %s\n", prefix,
                   (i == SCHED_OTHER) ? "SCHED_OTHER" :
                   (i == SCHED_FIFO)  ? "SCHED_FIFO" :
                   (i == SCHED_RR)    ? "SCHED_RR" :
                   "???");

           s = pthread_attr_getschedparam(attr, &sp);
           if (s != 0)
               printf("\n error in schedparam");
           printf("%sScheduling priority = %d\n", prefix, sp.sched_priority);

           s = pthread_attr_getguardsize(attr, &v);
           if (s != 0)
               printf("\n error in guardsize");
           printf("%sGuard size          = %d bytes\n", prefix, v);

           s = pthread_attr_getstack(attr, &stkaddr, &v);
           if (s != 0)
               printf("\n error in stack");
           printf("%sStack address       = %p\n", prefix, stkaddr);
           printf("%sStack size          = 0x%x bytes\n", prefix, v);
}



void* pthread_fun(void* arg)
{
 int s;
        pthread_attr_t gattr;
        if((s=  pthread_getattr_np(pthread_self(),&gattr))!=0)
        {
                printf("\n error in gattr");
        }
        printf("\n thread attributes:\n");
        display_pthread_attr(&gattr,"\t");
        printf("thread fun running,argument passed=%s\n",(char *)arg);
        sleep(3);

        strcpy(mesg,"badboy");
        pthread_exit(arg);
}

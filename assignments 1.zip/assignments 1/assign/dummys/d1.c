#include<stdio.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/types.h>
#include<string.h>
#define SIZE 30
#include<errno.h>
int main()
{
	key_t ikey;
	int id;
	char *addr;
	char str[20];

	id=shmget(ikey=5678,SIZE,IPC_CREAT|0666);
if(id==-1)
	printf("error\n");
	printf("shm id =%d",id);
	addr=shmat(id,(char*)0,0);
if(addr==(char*)-1)
	printf("error\n");
	printf("enter  a string=");
     //	scanf("%s",addr);
     	
 //	printf("string is=%s",str);
	strcpy(addr,(char*)gets(str));
	shmdt(addr);
return 0; 
}

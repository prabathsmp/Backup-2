#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<pthread.h>
#include<errno.h>
#define MSGSZ 128
#define SIZE 30
 struct msgbuf {
         long mtype;
         char mtext[MSGSZ];
         } sbuf,rbuf_1;
/*struct msgbuf {
    	long mtype;
	char mtext[MSGSZ];
	}rbuf_1;*/


void * shared(void *);

void * shared(void *t)
{
        key_t ikey;
        int id;
        char *addr;
        char str[20];

        id=shmget(ikey=5678,SIZE,IPC_CREAT|0666);
if(id==-1)
        printf("error\n");
        printf("shm id =%d",id);
        addr=shmat(id,(char*)0,0);
if(addr==(char*)-1)
        printf("error\n");
	printf("attached to shared memory%d/t%c\n",id,addr);
	return 0;
}



/*void* mess_1(void *);

void* mess_1(void *b)
{
	int msqid_1;
        key_t key_1;
        struct msgbuf rbuf_1;
                                                            printf("inside thread_1:");
	key_1 = 1235;

    if ((msqid_1 = msgget(key_1, 0666)) < 0) {
        perror("msgget");
                                                             printf("%d",msqid_1);
        exit(1);
    }
    else{

    FILE *p1;
        p1=fopen("mqserver","w+");
        if(p1==NULL){
printf("error in file opening\n");exit(0);}
       // long size;
       // ftell(p1);
       // fseek(p1,size,SEEK_SET);
        fprintf(p1,"\t%d",msqid_1);
        printf("file%d",msqid_1);
}                                
                                                                                                 sleep(1000);
   	if (msgrcv(msqid_1,&rbuf_1,MSGSZ,rbuf_1.mtype,0) < 0) {  printf("%d",msqid_1);

        perror("msgrcv");
        exit(1);
}
	printf("MESSAGE RECEIVED FROM SERVER:%s\n", rbuf_1.mtext);
	return 0;

} */

main()
{
    	int msqid;
    	int msgflg = IPC_CREAT | 0666;
    //	key_t key;
   	struct msgbuf sbuf;
   	size_t buf_length;
//	key = 1235;
/*if ((msqid = msgget(key, msgflg )) < 0) {
        perror("msgget");
        exit(1);
    }   
else*/  
       
	FILE *pfile;
            
      
       pfile = fopen("mr","r+");
       if(pfile==NULL) {fputs ("File error",stderr); exit (1);}
       fscanf(pfile,"%d",&msqid);
       fclose (pfile);
   
           (void) fprintf(stderr,"msgget: msgget succeeded: msqid = %d\n",msqid);
         sbuf.mtype = 1;

    //	(void) fprintf(stderr,"msgget: msgget succeeded: msqid = %d\n", msqid);

   	(void) strcpy(sbuf.mtext, "Did you get ?");

  //  	(void) fprintf(stderr,"msgget: msgget succeeded: msqid = %d\n", msqid);

         buf_length = strlen(sbuf.mtext) + 1 ;
 


	if (msgsnd(msqid,&sbuf,buf_length,IPC_NOWAIT) < 0) {
       	printf("%d,%d,%s,%d,%d\n", msqid, sbuf.mtype,sbuf.mtext,buf_length,errno);
        perror("msgsnd");
        exit(1);
    }

   else
     	 printf("Message: \"%s\" Sent from CLIENT\n",sbuf.mtext);

        printf("\n============================================\n");
    
	 pthread_t thread1;
    //     pthread_t thread2;
         pthread_create(&thread1,NULL,&shared,NULL);
         sleep(1);
                                        printf("\ncreated thread for shared memory");                             // sleep(500);
      //   pthread_create(&thread2,NULL,&mess_1,NULL);
       //  sleep(1);                  
        //                  printf("\ncreated thread for MESSAGE QUE-CLIENT\n");
         pthread_join(thread1,NULL);
        // pthread_join(thread2,NULL); 


}

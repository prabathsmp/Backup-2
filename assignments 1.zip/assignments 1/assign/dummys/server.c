#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<sys/shm.h>
#include<stdio.h>
#include<stdlib.h> 
#include<signal.h>
#include<pthread.h>
#include<errno.h>
#include<string.h>
#define MSGSZ 256 
/*enum C
{
  Get,
  Set
};*/
struct msg
{
        int empid;
        long msqidc;
        int choice;
};
struct msgbuf
{
        long mtype;
        struct msg mtext;
}sbuf,bufc;
struct emp
{
        char name[10];
        int empid;

};
/*
struct msgbuf 
{
         long mtype;
         long mtext[MSGSZ];
	 //char mtext1;
}rbuf,bufc;*/



void shut(int);
long msqidcl;
main()
{
       //  CR3EAING DATABASE
        signal(SIGINT,shut);
        FILE *fp;
	struct emp e1[4];
	char ch;//choice
	char cha;

	//filename
	char fil[]="data";
	fp=fopen(fil,"w+");
	int i=0;
       
	//while(1)
	//{
	printf("1) data entry 2)exit\n");
	scanf("%c",&ch);
	if(ch=='1')
	{
		printf("Enter the emp name and id details:\n");
        	for(;i<4;i++)
		{
        		scanf("%s%d",&e1[i].name,&e1[i].empid);
		        fprintf(fp,"%d\t%s\n",e1[i].empid,e1[i].name);

		}
   	}	 
	//break;
  	// } 
	printf("The contents of %s file are :- \n\n", fil);
	fseek(fp,0,SEEK_SET);
	while((cha = fgetc(fp))!= EOF)
		printf("%c",cha);
	
        fclose(fp);
	printf("\nDB closed");

       
	//CREATING MSQ
	
        long int msqid;
        key_t key;
        key =ftok("/home/prabath/data",23);
        while(1)
{
        if((msqid = msgget(key,0666 | IPC_CREAT))==-1)
	{
	     	perror("msgget");
        	printf("%ld",msqid);
        	exit(1);
    	}
	
	else
	{   
		//char fk[]="don";
		//
	// WRITING MSQID IN FILE
	printf("\nServer Message queue created\n");
    		FILE *fp1;

        	fp1=fopen("f1","w");
		printf("\nFile opened\n");
        	fprintf(fp1,"%ld",msqid);
        	printf("\nservermsqid=%ld\n",msqid);
		fclose(fp1);
    	}	
               // RECEIVING CHOICE FROM CLIENT
  	    if(msgrcv(msqid,&sbuf,sizeof(sbuf),1,MSG_NOERROR) < 0)
	{	
        	printf("%d",msqid);
		printf("errno =[%x][%d]\n",errno,errno);
        	perror("msgrcv");
        	exit(1);

        }	
        printf("\nclient msqidc=%ld\tEmpid=%d\tChoice=%d\n", sbuf.mtext.msqidc,sbuf.mtext.empid,sbuf.mtext.choice);
       
	FILE *fp2;
	long shmid;
	long shmid1;
	long msqic;
	long pid;
	fp2=fopen("f2","r");
	while(!feof(fp2))
	{ 
        fscanf(fp2,"%ld",&pid);
	fscanf(fp2,"%ld",&shmid);
	fscanf(fp2,"%ld",&msqic);
	if(sbuf.mtext.msqidc==msqic)
	{
           shmid1=shmid;
           msqidcl=msqic;
	}
            break;
	}
        int c=sbuf.mtext.choice;
       // sbuf.mtype=1;
	sbuf.mtype=1;
	printf("\nmsqidcl= %ld",msqidcl);
	// msqidcl=sbuf.mtext.msqidc;
	int id1=sbuf.mtext.empid;
	char *addr;
       	 
/*	fp2=fopen("f2","r"); 
        printf("\nFile open successful");
        if(fp2)
        {
                printf("\nthe shm id1 is:");
                fscanf(fp2,"%ld",&shmid1); 
		printf("%ld",shmid1);
                printf("\nthe shm id2 is:");
                fscanf(fp2,"%ld",&shmid2);
		 fclose(fp2);
	}
	 printf("\nFile close succeess.");*/
       i=0; 
        printf("\nchoice=%d",c);              
	char nam[7];
	switch(c)
        {
                case 10:
                        printf("\nGET FUN() ENCOUNTERED");
                        for(i=0;i<4;i++)
                        {
				
				if(e1[i].empid==id1)
                                {
                                        printf("\nID MATCH FOUND");

                                        addr=(char *)shmat(shmid1,(char *)0,0);
                               	        //printf("%s",addr);
                                        if(addr==(void *)-1)
                                        {
                                                printf("\n error:%d",errno);
                                                exit(1);
                                        }
                                        strncpy(addr,(char *)e1[i].name,7);
                                        printf("\n THE CORRESPONDING EMP NAME WRITTEN IN SHARED MEMORY:%s\t%s",addr,e1[i].name);
                                        //shmdt(addr);
				      //  memset((void *)&bufc,0,sizeof(bufc));
                                        sbuf.mtext.choice=1;
                                       // T__GET MESSAGE
                                        if(msgsnd(msqidcl,&sbuf,(sizeof(sbuf)-sizeof(long)),0)<0)
                                                perror("msgsnd");
					break;	
					
					
                                }       // N_GET MESSAGE
                                	else if(i==3)
                                        { 
					printf("\n Sorry, pls Enter the valid id");
                                        sbuf.mtext.choice=2;
                                       
                                       
                                        if(msgsnd(msqidcl,&sbuf,sizeof(sbuf),0)==-1)
                                        perror("msgsnd");

			                }                                           
                         
                        }

                       	
		 break;
                               





	       case 20:                
				/*	printf("\n SET FUN() ENCOUNTERED");	
				  	printf("\nEnter the name which u want to set:");
					scanf("%s",&nam);
                                        addr=(void *)shmat(shmid1,(void *)0,0);
                                         printf("%s",addr);
                                        if(addr==(void *)-1)
                                        {
                                                printf("\n error in =%d,errno");
                                                exit(1);
                                        }
                                        strncpy(addr,(char *)nam,7);
                                        printf("\nNAME STORED IN SHARED MEMORY:%s\t",addr);
                                        shmdt(addr);*/


                        for(;i<4;i++)
                        {
                                if(e1[i].empid==id1)
                                {
					printf("\nMatched id found");
                                        addr=(void *)shmat(shmid1,(void*)0,0);
                                        if(addr==(void*)-1)
                                                printf("\n error");  
					
                                        	strncpy(e1[i].name,addr,7);
                                        shmdt(addr);
                                        printf("\nid=%d\tnam=%s",e1[i].empid,e1[i].name);

                                       //T_SET MESSAGE  
                                       
                                       sbuf.mtext.choice=3;
                                        if(msgsnd(msqidcl,&bufc,(sizeof(sbuf)-sizeof(long)),0)==-1)
                                        perror("msgsnd");
					break;
                                }
                                       //N_SET  MESSAGE

                                        else if(i==3)
                                        {
                                         
                                         printf("\n Sorry, pls Enter the valid id");
                                      
                                         sbuf.mtext.choice=4;
                                         if(msgsnd(msqidcl,&sbuf,(sizeof(sbuf)-sizeof(long)),0)==-1)
                                         perror("msgsnd");
                                        } 
                        }
                         break;	
            
        }
    sleep(20);
}
return 0;
}
void shut(int w)
{
	long msqids;
	FILE *fp3;
	fp3=fopen("f1","r+");
	if(fp3)
	fscanf(fp3,"%ld",&msqids);
	fclose(fp3);
	printf("%ld",msqids);
        if(msgctl(msqids,IPC_RMID,0)<0)
	{
		printf("errorno= %d",errno);
		exit(1);
		}
	printf("\n server message queue deleted");
        
        int j=10; 
       sbuf.mtype=2;
       sbuf.mtext.choice=j;
	printf("\n client msqidcl=%d",msqidcl);
        if(msgsnd(msqidcl,&sbuf,(sizeof(sbuf)-sizeof(long)),0)==-1)
	{
        	printf("\nmsgsnd %d",errno);
		exit(1);
	}
        printf("\n shut signal sent");

}




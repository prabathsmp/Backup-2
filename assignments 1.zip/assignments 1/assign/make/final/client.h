#ifndef CLIENT_H

#define CLIENT_H

#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<sys/shm.h>
#include<sys/sem.h>
#include<sys/wait.h>
#include<signal.h>
#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<stdlib.h>
#include<pthread.h>
#include<errno.h>
#include"header.h"
#define MSGSZ 256
#define SIZE 30
#if defined(__GNU_LIBRARY__) && !defined(_SEM_SEMUN_UNDEFINED)
#else
union semun
{       int val; \
	  struct semid_ds *buf;   
	 unsigned short int *array; 
	 struct seminfo *__buf;  
};
#endif

//key_t keya = 1010;
int semid;


static struct sembuf acquire = {0,-1,0},release = {0, 1,0};
union semun arg;
/*struct msg
{
        int empid;
        long msqidc;
        int choice;
};
struct msgbuf
{
        long mtype;
        struct msg mtext;

};

struct msgbuf sbuf,rbuf;*/
//int buffer;
//int msqid;
int sh_id;
int d;
int u;
int s1,m1,s2,m2;
void* get(void *);
void* set(void *);
void cleanup(int);
//void shutdown(int,int);
void file(int,int);
int sharedcontrol(int sh);
int sharedmem(key_t key);
int messagecontrol(int msqidqq);
int messagesnd(int msqids);
//int messagesend(int msqids);
int messagerceive(int msqida);
int messagerceive1(int msqida);
//int messagereceive(int msqidss);
int messagereceive1(int msqidss);
//int messageget(key_t key,int flag);
int semophorecreate(key_t );
int semocontrol(int semid);
int semopcontrol(int semid);
#endif

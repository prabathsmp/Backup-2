#include"header.h"
void database()
{
	/*	strcpy(e1[0].name,"arjun");
		e1[0].empid=1;
		strcpy(e1[1].name,"karti");
		e1[1].empid=2;
		strcpy(e1[2].name,"ram");
		e1[2].empid=3;
		strcpy(e1[3].name,"raju");
		e1[3].empid=4;*/
	FILE *fp;
	//char cha;
	int i=0;
	char fil[]="database";
	fp=fopen(fil,"r");
	while(!feof(fp))
	{
		fscanf(fp,"%s\t%d\n",&u_empname,&u_empid);
		struct Node *temp=createNode(u_empname,u_empid);
		if(!head)
			head=temp;
		else
			tail->next=temp;
		tail=temp;

	}

	printf("The contents of %s file Before modification are :- \n\n", fil);
	/*fseek(fp,0,SEEK_SET);
	  while((cha = fgetc(fp))!= EOF)
	  printf("%c",cha);*/
	for(temp=head;temp;temp->next)
	{
		printf("%s\t%d\n",temp->empname[],temp->empid);
	}
	fclose(fp);
	printf("\nDB closed");
}


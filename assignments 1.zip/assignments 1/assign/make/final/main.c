#include"header.h"
char u_empname[10];
int u_empid;

//struct msgbuf sbuf,rbuf;
struct Node
{
	int empid;
	char empname[10];
	struct Node *next; 
};
struct Node *head=NULL,*tail=NULL;


struct Node * createNode(char *empname,int empid)
{

	struct Node *temp=(struct Node *)malloc(sizeof(struct Node));
	strcpy(temp->empname,empname);
	temp->empid=empid;
	temp->next=NULL;
	return temp;
}
//struct Node *temp;
//struct msgbuf sbuf,rbuf;
//struct emp e1[4];
main()
{
	struct Node *temp;
	signal(SIGINT,shut);
	// database();
	FILE *fp;
	char fil[]="database";
	fp=fopen(fil,"r");
	if(fp==NULL)
          printf("error in opening file\n");
	while(!feof(fp))
	{
		fscanf(fp,"%s\t%d\n",&u_empname,&u_empid);
		struct Node *temp=createNode(u_empname,u_empid);
		if(!head)
			head=temp;
		else
			tail->next=temp;
		tail=temp;

	}
	printf("The contents of %s file Before modification are :- \n\n", fil);
	for(temp=head;temp!=tail;temp=temp->next)
	{
		printf("%s\t%d\n",temp->empname,temp->empid);
	}
	fclose(fp);
	printf("\nDB closed");


	key_t key1;
	key1 =ftok("/home/prabath/data",23);
	int flag;
	int msqid;
	msqid= messageget(key1,flag);
	qidms=msqid;
	printf("\nServer Message queue created\n");
	FILE *fp1;

	fp1=fopen("/tmp/servermq","w");
	printf("\nFile opened\n");
	fprintf(fp1,"%d",msqid);
	printf("\nservermsqid=%d\n",msqid);
	fclose(fp1);
	while(1)
	{
		int flag;
		//int a= messagereceive(msqid,sbuf,sizeof(sbuf),flag);
		int a=messagereceive(msqid);
		printf("\n\n");
		printf("\nclient msqidc1=%d\tEmpid=%d\tChoice=%d", sbuf.mtext.msqidc,sbuf.mtext.empid1,sbuf.mtext.choice);

		FILE *fp2;
		int shmid,shmid1;

		int msqic,msqidcl;

		fp2=fopen("f2","r");
		while(!feof(fp2))
		{
			fscanf(fp2,"%d",&shmid);
			fscanf(fp2,"%d",&msqic);
			if(sbuf.mtext.msqidc==msqic)
			{
				shmid1=shmid;
				msqidcl=msqic;
			}


		}

		int c=sbuf.mtext.choice;
		sbuf.mtype=1;
		printf("msqidcl= %d",msqidcl);
		printf("\nshmid= %d",shmid1);

		int id1=sbuf.mtext.empid1;
		char *addr;
	 
		printf("\nchoice=%d",c);
		//	char nam[10];
		switch(c)
		{
			case 100:
				printf("\nGET FUN() ENCOUNTERED");
			
				for(temp=head;temp;temp=temp->next)
				{

					if(temp->empid==id1)
					{
						printf("\nID MATCH FOUND");

						addr=(char *)shmat(shmid1,(char *)0,0);

						if(addr==(void *)-1)
						{
							printf("\n error:%d",errno);
							exit(1);
						}
						strncpy(addr,(char *)temp->empname,10);
						printf("\n THE CORRESPONDING EMP NAME WRITTEN IN SHARED MEMORY:%s\t%s",addr,temp->empname);
						//	sleep(10);
						sbuf.mtext.choice=1;
						//		int W=messagesend(msqidcl,sbuf,(sizeof(sbuf)-sizeof(long)),0);
						int W=messagesend(msqidcl);
						break;


					}      
					else if(temp==tail)
					{
						printf("\n Sorry, pls Enter the valid id");
						sbuf.mtext.choice=2;
						//	sleep(10);

						//   int yq= messagesend(msqidcl,sbuf,(sizeof(sbuf)-sizeof(lon)),0);
						int yq= messagesend(msqidcl);			

					}

				}


				break;






			case 200:

				printf("\nSET Encountered");
				
				for(temp=head;temp;temp=temp->next)
				{
					if(temp->empid==id1)
					{
						printf("\nMatched id found");
						addr=(void *)shmat(shmid1,(void*)0,0);
						if(addr==(void*)-1)
							printf("\n error");

						strncpy(temp->empname,addr,10);
						shmdt(addr);
						printf("\nid=%d\tnam=%s",temp->empid,temp->empname);
						//	sleep(10);
						sbuf.mtext.choice=3;
						//		int ms=messagesend(msqidcl,sbuf,(sizeof(sbuf)-sizeof(long)),0);
						int ms=messagesend(msqidcl);

						FILE * fptr;
						fptr=fopen("backup","a+");
						if(fptr==NULL)
						{
							printf("error\n");
							exit(1);
						}
						fprintf(fptr,"%d \t %s\n",temp->empid,temp->empname);
						fclose(fptr);
						break;
					}
					else if(temp==tail)
					{

						printf("\n Sorry, pls Enter the valid id");
						//	sleep(10);
						sbuf.mtext.choice=4;
						//	int sm=messagesend(msqidcl,sbuf,(sizeof(sbuf)-sizeof(long)),0);
						int sm=messagesend(msqidcl);
					}
				}
				break;

		}

	}

	return 0;
}



void writeback()
{
	FILE *tr;
	tr=fopen("database","w+");
	if(tr==NULL)
		printf("\n error");
	struct Node *temp=head;
	for(;temp;temp=temp->next)
	{
		fprintf(tr,"%s\t%d\n",temp->empname,temp->empid);
	}
	fclose(tr);
	exit(1);
}

void shut(int w)
{
	int msqids,shm,sd;
	int msqidcc;
	printf("\nserver QUEUE ID=%d\n",qidms);
	int xcv=messagecontrol(qidms);

	printf("\n server message queue deleted\n");

	FILE *fp3;
	fp3=fopen("f2","r");
	if(!fp3)
	{
		printf("\n error in opening file,%d\n",errno);
		//		exit(1);
	}
	/*fscanf(fp3,"%d",&shm);
	  fscanf(fp3,"%d",&msqids);
	  fscanf(fp3,"%d",&sd);
	  fscanf(fp3,"%d",&msqidcc);*/

	while(!feof(fp3))
	{
		fscanf(fp3,"%d",&shm);
		fscanf(fp3,"%d",&msqids);
		fscanf(fp3,"%d",&sd);
		fscanf(fp3,"%d",&msqidcc);
		int j=10;
		sbuf.mtype=1;
		sbuf.mtext.choice=j;
		printf("\n client msqidcl=%d\n",msqids);
		//	int df=messagesend(msqids,sbuf,(sizeof(sbuf)-sizeof(long)),0);
		int df=messagesend(msqids);
		printf("\n shut signal sent to thread\n");
		printf("\n client msqidcl-2=%d\n",msqidcc);
		sbuf.mtype=1;
		//  int sw=messagesend(msqidcc,sbuf,(sizeof(sbuf)-sizeof(long)),0);
		int sw=messagesend(msqidcc);
		printf("\n shut signal sent to thread2\n");
		/*fscanf(fp3,"%d",&shm);
		  fscanf(fp3,"%d",&msqids);
		  fscanf(fp3,"%d",&sd);
		  fscanf(fp3,"%d",&msqidcc);*/

	}
	fclose(fp3);
	writeback();
	exit(1);	
}

//#include"header.h"
#include"client.h"
int messageget(key_t key,int flag)   
{
int msqid11;
flag=0666 | IPC_CREAT;
 if((msqid11 = msgget(key,0666 | IPC_CREAT))==-1)
        {
                perror("msgget");
                printf("%ld",msqid);
                //exit(1);
        }
return msqid11;
}




//int messagereceive(long msqid,msgbuf sbuf,int(sizeof(sbuf)-sizeof(long)),int msgflg)
int messagereceive(int msqidss)
{

 if(msgrcv(msqidss,&sbuf,(sizeof(sbuf)-sizeof(long)),0,0) < 0)
                {
                        printf("\n%d",msqid);
                        printf("\nerrno =[%x][%d]",errno,errno);
                        perror("\nmsgrcv");
                        

                }
		return 0;
  }
int messagereceive1(int msqidss)
{

 if(msgrcv(msqidss,&sbuf,(sizeof(sbuf)-sizeof(long)),0,IPC_NOWAIT) < 0)
                {
                        printf("\n%d",msqid);
                        printf("\nerrno =[%x][%d]",errno,errno);
                        perror("\nmsgrcv");
                       

                }
                return 0;
  }

int messagerceive(int msqida)
{
 if(msgrcv(msqida,&rbuf,(sizeof(rbuf)-sizeof(long)),0,0) < 0)
                {
                        printf("\n%d",msqid);
                        printf("\nerrno =[%x][%d]",errno,errno);
                        perror("\nmsgrcv");
                       

                }
                //return 0;
}
int messagerceive1(int msqida)
{
 if(msgrcv(msqida,&rbuf,(sizeof(rbuf)-sizeof(long)),0,IPC_NOWAIT) < 0)
                {
                        printf("\n%d",msqid);
                        printf("\nerrno =[%x][%d]",errno,errno);
                        perror("\nmsgrcv");
                        
                      }
                return 0;
}





//int messagesend(long msqids,msgbuf sbuf,int(sizeof(sbuf)-sizeof(long)),int mtyp)

int messagesend(int msqids)
{
sbuf.mtype=1;
 if(msgsnd(msqids,&sbuf,(sizeof(sbuf)-sizeof(long)),0)==-1)
                {
                        printf("\nmsgsnd %d",errno);
                        //exit(1);
                }
                return 0;
   }
int messagesnd(int msqids)
{
rbuf.mtype=1;
 if(msgsnd(msqids,&rbuf,(sizeof(rbuf)-sizeof(long)),0)==-1)
                {
                        printf("\nmsgsnd %d",errno);
                        //exit(1);
                }
                return 0;
   }


/*int msgsnd(msqidcc,&sbuf,(sizeof(sbuf)-sizeof(long)),0)
{
 if(msgsnd(msqidcc,&sbuf,(sizeof(sbuf)-sizeof(long)),0)==-1)
                {
                        printf("\nmsgsnd %d",errno);
                        exit(1);
                }
                return 0;
   }

int msgsnd(msqidcl,&sbuf,(sizeof(sbuf)-sizeof(long)),0)
{
 if(msgsnd(msqidcl,&sbuf,(sizeof(sbuf)-sizeof(long)),0)==-1)
                {
                        printf("\nmsgsnd %d",errno);
                        exit(1);
                }
                return 0;
   }*/
//int messagecontrol(ng msqid,int cmd,0)
int messagecontrol(int msqidqq)
{
 
 if(msgctl(msqidqq,IPC_RMID,0)<0)
        {
                printf("errorno= %d",errno);
                //exit(1);
         }
 return 0;
}
int sharedmem(key_t key)
{
int sh_iid;
	 sh_iid=shmget(key,SIZE,0666 | IPC_CREAT);
        if(sh_iid==-1)
                printf("error\n");
return sh_iid;
}

int sharedcontrol(int sh)
{
 if(shmctl(sh,IPC_RMID,0)<0 )
        {
                printf("\nError in shmctl,errno=%d",errno);
                //exit(1);
        }
return 0;
}



int semophorecreate(key_t keya)
{
 if((semid=semget(keya,1,IPC_CREAT | 0666))==-1)
    printf("error=%d\n",errno);
     
return semid;
}


int semopcontrol(int semid)
{
 if (semctl(semid,0,SETVAL,arg)== -1)
        {
                perror("semctl-initialization\n");
                //exit(1);
        }
return 0;
}
int semocontrol(int semid)
{
if((semctl(semid,1,IPC_RMID,0))==-1)
                {
                        perror("\n semctl() initialization failed..");
                        //exit(1);
                }
return 0;
}

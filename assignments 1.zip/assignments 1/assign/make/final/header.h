#ifndef HEADER_H

#define HEADER_H

#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<sys/shm.h>
#include<stdio.h>
#include<stdlib.h>
#include<signal.h>
#include<pthread.h>
#include<errno.h>
#include<string.h>
#define MSGSZ 256
#define NUMSEMS 1
struct msg
{
        int empid1;
        int msqidc;
        int choice;
};
struct msgbuf
{
        long mtype;
        struct msg mtext;
};

struct msgbuf sbuf,rbuf;
/*struct Node
{
        int empid;
	char empname[10];
        struct Node *next;
};
struct Node *head=NULL,*tail=NULL;


struct Node * createNode(char empname[],int empid )
{

        struct Node *temp=(struct Node *)malloc(sizeof(struct Node));
        temp->empname=u_empname;
	temp->empid=u_empid;
        temp->next=NULL;
        return temp;
}*/
//char *sbuf1;
//struct msgbuf sbuf;
int msqid;
int qidms;
void database();
void shut(int);
void writeback();
int messageget(key_t key,int flag);
//int messagereceive(long msqid,struct msgbuf sbuf,int sbuf2,int flag);
int messagereceive(int);
//int messagesend(long msqids,struct msgbuf sbuf,int sbuf1,int flag);
int messagesend(int);
//int messagesnd(int);
int messagecontrol(int);
#endif 

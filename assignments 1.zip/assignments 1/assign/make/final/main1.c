#include"client.h"
int main()
{
 FILE *pfile;
   
        pfile = fopen("/tmp/servermq","r");

        printf("\nFile open success");
        if(pfile!=NULL)

        {
                if(feof(pfile))
                        exit(1);
                fscanf(pfile,"%ld",&msqid);
                printf("\n Received servermsqid=%ld\n",msqid);
		u=msqid;
        }

        else
        {
                printf("\n file not exist\n");
                exit(1);
        }

        fclose (pfile);
        printf("\nFile close success");
	 pthread_t thread1;
        pthread_t thread2;
        signal(SIGINT,cleanup);
	char vh;
  while(1)
        {
                printf("Enter the 'g'or 's':\n");
                scanf("%c",&vh);
                switch(vh)
                {
                        case 'g':
				 pthread_create(&thread1,NULL,&get,NULL);
                                pthread_join(thread1,NULL);
                                break;
                        case 's':
                                pthread_create(&thread2,NULL,&set,NULL);
                                pthread_join(thread2,NULL);
                                break;
                }
        }
return 0;
}
void * get(void *q)
{
        printf("\n currently in thread1\n");
        //struct msgbuf sbuf;
        int sh_id;
        key_t  key1=6670;
	int flag;
	printf("Before msqid %d\n",msqid);
        sbuf.mtext.msqidc= messageget(key1,flag);
 	printf("\nthread1 messageQ id:%ld\n",sbuf.mtext.msqidc);
	printf("After  msqid %d\n", msqid);
        int temp2=sbuf.mtext.msqidc;
         m1=sbuf.mtext.msqidc;
	key_t key=5671;
	sh_id=sharedmem(key); 

        printf("\nshm id(t1) =%ld\n",sh_id);
        s1=sh_id;
	key_t keyd=1010;
	 semid=semophorecreate(keyd);
	 printf("semid =%d",semid);

        arg.val = 0 ;
	int exz=semopcontrol(semid);

	 semop(semid, &acquire, 0) ;
 	FILE *s;
        s=fopen("f2","a");
        if(s==NULL)
        {
                printf("File error");
                exit (1);
        }
        printf("\nIN file msqidc(t1):%d\n",sbuf.mtext.msqidc);
        fprintf(s,"%d\n",sh_id);
        fprintf(s,"%d\n",sbuf.mtext.msqidc);
        fclose(s);
        semop(semid,&release,0);
	char km;
        while(1)
        {
                printf("p->multiple GET e->single GET\n");
                scanf("%s",&km);
                printf("choice entered\n");
		printf("\nT1-> Enter the employee id:\n");
                scanf("%d",&sbuf.mtext.empid1);
                printf("\n T1-> user i/p read\n");
                sbuf.mtext.choice=100;
                sbuf.mtype=1;
		 int qd=messagesend(msqid);
		  printf("Message: %d\t%d\t%d Sent from CLIENT sdfd %d \n",sbuf.mtext.msqidc,sbuf.mtext.empid1,sbuf.mtext.choice,u);
		  int asw=messagereceive(sbuf.mtext.msqidc);
		 printf("\n bufc.mtext.choice=%d",sbuf.mtext.choice);
                switch(sbuf.mtext.choice)
                {
                        case 1:
                                printf("\n T_GET RECEIVED");
                                break;
                        case 2:
                                printf("\n N_get RECEIVED");
                                break;
                        case 10:

                                printf("\nFOR T1..shutsig received...");
			 printf("\nT1 shut down fun() called");
                                cleanup(d);
			 break;
                }
                printf("\n waiting t1");
		 sleep(10);
		int ac;
	
		ac=messagereceive1(sbuf.mtext.msqidc);
		
		 printf("\n bufc.mtext.choice=%d",sbuf.mtext.choice);
                switch(sbuf.mtext.choice)
                {
                        case 1:
                                printf("\n T_GET RECEIVED");
                                break;
                        case 2:
                                printf("\n N_get RECEIVED");
                                break;
                        case 10:

                                printf("\nFOR T1..shutsig received...");
			 printf("\nT1 shut down fun() called");
                               cleanup(d);
			 break;
                }
	  if(km=='e')
                        break;

        }
}
void * set(void *msqid)
{
        char *addr;
        char nam[7];
        int sh_id2;
       // struct msgbuf rbuf;
        key_t key2=6550;
        printf("\n currently in thread2\n");
        int flag;
        rbuf.mtext.msqidc= messageget(key2,flag);
	printf("\nthread1 messageQ id:%d\n",rbuf.mtext.msqidc);
	int temp1=rbuf.mtext.msqidc;
        m2=rbuf.mtext.msqidc;
      
	key_t key=5679;
        sh_id2=sharedmem(key);
	printf("\nshm id(t2) =%d\n",sh_id2);
        s2=sh_id2;
	FILE *z;
        z=fopen("f2","a");
        if(z==NULL)
        {
                printf("File error");
                exit (1);
        }
        printf("\nIN file msqidc(t2):%d\n",rbuf.mtext.msqidc);
	 fprintf(z,"%d\n",sh_id2);
        fprintf(z,"%d\n",rbuf.mtext.msqidc);
        fclose(z);
	 char bh;
	 while(1)
        {
                printf("\np->multiple SET e->single SET\n");
                scanf("%s",&bh);
                printf("choice entered\n");
		printf("\nT2->Enter the id to be SET:\n");
                scanf("%d",&rbuf.mtext.empid1);
                printf("\n thread2 i/p id read\n");
                printf("\nT2->Enter the name to be SET:\n");
                scanf("%s",&nam);
                printf("\nthread2 i/p name read\n");
                rbuf.mtype=1;

                addr=(void *)shmat(sh_id2,(void *)0,0);

                if(addr==(void *)-1)
                {
                        printf("\n error in =%d,errno");
                        exit(1);
                }
                strncpy(addr,(char *)nam,7);
                printf("\nNAME STORED IN SHARED MEMORY:%s\n",addr);
                shmdt(addr);
                rbuf.mtext.choice=200;
		printf("u=%d",u);
		int yq= messagesnd(u);
		printf("Message: %d\t%d\t%d Sent from CLIENT dfgfdg %d\n",rbuf.mtext.msqidc,rbuf.mtext.empid1,rbuf.mtext.choice,u);
		
		int ka=messagerceive(rbuf.mtext.msqidc);
		 printf("\nrbuf.mtext.choice=%d",rbuf.mtext.choice);
                switch(rbuf.mtext.choice)
                {
                        case 3:
                                printf("\n T_SET RECEIVED");
                                break;
                        case 4:
                                printf("\n N_Set RECEIVED");
                                break;
                        case 10:
                                printf("\nFOR T2..shutsig received...");
			 printf("\nT2 shut down fun() called");
				cleanup(d);
                               break;
			}
			 printf("\n waiting");
                sleep(10);
		int al=messagerceive1(rbuf.mtext.msqidc);
		 printf("\nrbuf.mtext.choice=%d",rbuf.mtext.choice);
                switch(rbuf.mtext.choice)
                {
                        case 3:
                                printf("\n T_SET RECEIVED");
                                break;
                        case 4:
                                printf("\n N_Set RECEIVED");
                                break;
                        case 10:
                                printf("\nFOR T2..shutsig received...");
			 printf("\nT2 shut down fun() called");
                                cleanup(d);
                                break;
                }
	if(bh=='e')
        break;

        }
}
/*void shutdown(int sh,int msq)
{
        static int n=0;
        printf("shmid:%d\n",sh);
        printf("msqid:%d\n",msq);
 int xcg=sharedcontrol(sh);
 printf("\n client SHARED MEMORY DELETED\n");

int xcj=messagecontrol(msq);
 printf("\n CLIENT MESSAGE QUEUE DELETED\n");
        printf("semaphore id=%d\n",semid);
        if(n<=0)
        {
	int xnv=semocontrol(semid);
	printf("\n semaphore deleted..");
                n++;
        }
        file(sh,msq);

        pthread_exit(NULL);
}
void file(int sh,int msq)
{
        int s,q;
        FILE *w;
        w=fopen("f3","w+");
        if(w==NULL)
        printf("\n ERROR");
 FILE *f;
        f=fopen("f2","r");
        if(f==NULL)
        printf("\n ERROR");
        while(!feof(f))
        {
        fscanf(f,"%d",&s);
        fscanf(f,"%d",&q);
        if(sh!=s && msq!=q)
        {
                        fprintf(w,"%d\n",s);
                        fprintf(w,"%d\n",q);
         }
        }
        fclose(w);
        fclose(f);
        rename("f3","f2");
printf("\n corresponding entries deleted in f2");
}*/
void cleanup(int d)
{
        int shmid,msgid;
	key_t keyd=1010;
        arg.val = 0 ;
	 //int semid=semophorecreate(keyd);
         printf("semid =%d",semid);
	 int pxz=semopcontrol(semid);
         semop(semid, &acquire, 0) ;
	  FILE *x;
        x=fopen("f2","r");
        if(x==NULL)
        {
                printf("\n Error in opening file,%d\n",errno);
                exit(1);
        }
        while(!feof(x))
        {
                fscanf(x,"%d",&shmid);
                fscanf(x,"%d",&msgid);
        //        printf("shmid:%d",shmid);
          //      printf("msqid:%d",msgid);
                if((s1==shmid || m1==msgid)||(s2==shmid || m2==msgid))
                {
		 int zcv=sharedcontrol(shmid);
		  printf("\n client SHARED MEMORY DELETED\n");
		int fcv=messagecontrol(msgid);
		 printf("\n CLIENT MESSAGE QUEUE DELETED\n");
                }
        }
        printf("semaphore id1=%d\n",semid);
	int xcv=semocontrol(semid);
        printf("\n semaphore deleted..");
	 fclose(x);
        semop(semid,&release,0);
     //   printf("semaphore id2=%d\n",semid);
//	int ycv=semocontrol(semid);
  //      printf("\n semaphore2 deleted..");
	 FILE *j;
        j=fopen("f4","w+");
        if(j==NULL)
        printf("\n ERROR");

         FILE *y;
        y=fopen("f2","r");
        if(y==NULL)
        {
                printf("\n Error in opening file,%d\n",errno);
                exit(1);
        }

        while(!feof(y))
        {
                fscanf(y,"%d",&shmid);
                fscanf(y,"%d",&msgid);
	//	printf("\n S1=%d",s1);
	//	printf("\n M11=%d",m1);
	//	printf("\n S2=%d",s2);
	//	printf("\n M2=%d",m2);
	 if((s1!=shmid && m1!=msgid)&&(s2!=shmid && m2!=msgid))
                {
                         fprintf(j,"%d\n",shmid);
                         fprintf(j,"%d\n",msgid);
                 }
        }
        fclose(j);
        fclose(y);
        rename("f4","f2");
        printf("\nCLEAN-UP: corresponding entries deleted in f2");
      exit(1);
}

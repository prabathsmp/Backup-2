#include<iostream>
using namespace std;

void print_hello();
int factorial(int n);

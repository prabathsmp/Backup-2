#include "functions.h"
int main()
{
	int fact ;
    print_hello();
    cout << endl;
	cout<<"Enter the number to find factorial "<<endl;
	cin>>fact;
    cout << "The factorial of  " << fact << "\t is " << factorial(fact) << endl;
    return 0;
}

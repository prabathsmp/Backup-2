#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<sys/shm.h>
#include<sys/sem.h>
#include<sys/wait.h>
#include<signal.h>
//#include<cstdio.h>
#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<stdlib.h>
#include<pthread.h>
#include<errno.h>
#define MSGSZ 256
#define SIZE 30
#if defined(__GNU_LIBRARY__) && !defined(_SEM_SEMUN_UNDEFINED)
// definition in <sys/sem.h>
#else
union semun 
{                          // We define:
	int val;                             // value  for SETVAL
	struct semid_ds *buf;                // buffer for IPC_STAT, IPC_SET
	unsigned short int *array;           // array  for GETALL, SETALL
	struct seminfo *__buf;               // buffer for IPC_INFO
};
#endif 

key_t key = 1014;
int semid;


static struct sembuf acquire = {0,-1,0},release = {0, 1,0};
union semun arg;

/*if((semid=semget(key,1,IPC_CREAT | 0666))==-1)
  {
  printf("error=%d\n",errno);
  }
// printf("semid =%d",semid);*/



struct msg
{
	int empid;
	long msqidc;
	int choice;
};
struct msgbuf
{
	long mtype;
	struct msg mtext;

} sbuf,rbuf;


long msqid;
long s1,m1,s2,m2;
void* get(void *);
void* set(void *);
void cleanup(int);
void shutdown(long,long);
void file(long,long);
int main()
{
	FILE *pfile;

	pfile = fopen("/tmp/servermq","r");

	printf("\nFile open success");
	if(pfile!=NULL)

	{
		if(feof(pfile))
			exit(1);
		fscanf(pfile,"%ld",&msqid);
		printf("\n Received servermsqid=%ld\n",msqid);
	}

	else
	{
		printf("\n file not exist\n");
		exit(1);
	}

	fclose (pfile);
	printf("\nFile close success");

	/*

	   nt semid,rc;
	   key_t semkey;
	   struct sembuf operations;
	   semkey=ftok(".",'z');
	   if(semkey==(key_t)-1)
	   perror("\n ftok() failed...");
	   semid=semget(semkey,NUMSEMS,0666);
	   semaphore_id=semid;
	   if(semid==-1)
	   perror("\n semget() failed..");
	   printf("\n semid:%d",semid);
	   operations.sem_num=0;
	   operations.sem_op=1;
	   operations.sem_flg=0;
	   rc=semop(semid,&operations,1);
	   if(rc==-1)
	   {
	   perror("\n semop() failed...");
	   }*/

	pthread_t thread1;
	pthread_t thread2;
	signal(SIGINT,cleanup);

	//   SEND DATA TO SERVER
	pthread_create(&thread1,NULL,&get,NULL);

	pthread_create(&thread2,NULL,&set,NULL);

	pthread_join(thread1,NULL); 
	pthread_join(thread2,NULL);
	//	 pthread_join(thread1,NULL);                          
	return 0;
}

void * get(void *q)
{                      
	printf("\n currently in thread1\n");
	struct msgbuf sbuf;
	long sh_id;
	key_t  keyc=6270;
	//keyc =ftok("/home/prabath/data",12);   key_t keyc=6669;
	if((sbuf.mtext.msqidc=msgget(keyc,0666|IPC_CREAT))==-1)
	{
		perror("msgget");
		exit(1);
	}

	printf("\nthread1 messageQ id:%ld\n",sbuf.mtext.msqidc);
	long temp2=sbuf.mtext.msqidc;
	 m1=sbuf.mtext.msqidc;
	//key_t ikey;
	sh_id=shmget(7671,SIZE,0666 | IPC_CREAT);
	if(sh_id==-1)
		printf("error\n");

	printf("\nshm id(t1) =%ld\n",sh_id);
	s1=sh_id;
	//  	union semun arg;
	if((semid=semget(key,1,IPC_CREAT | 0666))==-1)
	{
		printf("error=%d\n",errno);
	}
	printf("semid =%d",semid);
	
	arg.val = 0 ;
	if (semctl(semid,0,SETVAL,arg)== -1) 
	{  
		printf("semctl-initialization\n");
		exit(1);
	}

	semop(semid, &acquire, 0) ; 
	FILE *s;
	s=fopen("f2","a");
	if(s==NULL)
	{
		printf("File error");
		exit (1);
	}
	printf("\nIN file msqidc(t1):%ld\n",sbuf.mtext.msqidc);
	fprintf(s,"\n%ld",sh_id);
	fprintf(s,"\n%ld",sbuf.mtext.msqidc);
	fclose(s);
	semop(semid,&release,0);
	while(1)
	{
		printf("\nT1-> Enter the employee id:\n");
		scanf("%d",&sbuf.mtext.empid);
		printf("\n T1-> user i/p read\n");
		sbuf.mtext.choice=100;
		sbuf.mtype=1;
		//	sleep(5);
		if(msgsnd(msqid,&sbuf,(sizeof(sbuf)-sizeof(long)),0)==-1)
		{
			printf("%ld,%d,%d,%d\n", msqid,sbuf.mtype,sizeof(sbuf),errno);
			perror("msgsnd");
			exit(1);
		}

		else
		{
			printf("Message: %ld\t%d\t%d Sent from CLIENT\n",sbuf.mtext.msqidc,sbuf.mtext.empid,sbuf.mtext.choice);

		}




		if(msgrcv(sbuf.mtext.msqidc,&sbuf,(sizeof(sbuf)-sizeof(long)),0,0)==-1)
		{
			perror("msgrcv");
			exit(1);
		}

		printf("\n bufc.mtext.choice=%d",sbuf.mtext.choice);
		switch(sbuf.mtext.choice)
		{
			case 1:
				printf("\n T_GET RECEIVED");
				break;
			case 2:
				printf("\n N_get RECEIVED");
				break;
			case 10:

				printf("\nFOR T1..shutsig received...");
				//	sleep(7);
				printf("\nT1 shut down fun() called");
				shutdown(sh_id,temp2);
				//	int d;
				//	cleanup(d);
				break;
		}
		printf("\n waiting t1");
		sleep(10);
		if(msgrcv(sbuf.mtext.msqidc,&sbuf,(sizeof(sbuf)-sizeof(long)),0,IPC_NOWAIT)==-1)
		{
			perror("msgrcv");

		}

		printf("\n bufc.mtext.choice=%d",sbuf.mtext.choice);
		switch(sbuf.mtext.choice)
		{
			case 1:
				printf("\n T_GET RECEIVED");
				break;
			case 2:
				printf("\n N_get RECEIVED");
				break;
			case 10:

				printf("\nFOR T1..shutsig received...");
				//	sleep(7);
				printf("\nT1 shut down fun() called");
				shutdown(sh_id,temp2);
				//	int d;
				//	cleanup(d);
				break;
		}

	}
}



void * set(void *e)
{ 
	char *addr;
	char nam[7];
	long sh_id2;
	struct msgbuf rbuf;
	key_t key2=6520;
	printf("\n currently in thread2\n");
	if((rbuf.mtext.msqidc=msgget(key2,0666|IPC_CREAT))==-1)
	{
		perror("msgget");
		exit(1);
	}

	printf("\nmsq-2=%ld\n",rbuf.mtext.msqidc);
	long temp1=rbuf.mtext.msqidc;
	m2=rbuf.mtext.msqidc;
	sh_id2=shmget(5639,SIZE,0666 | IPC_CREAT);
	if(sh_id2==-1)
		printf("error\n");

	printf("\nshm id(t2) =%ld\n",sh_id2);
	s2=sh_id2;
	FILE *z;
	z=fopen("f2","a");
	if(z==NULL)
	{
		printf("File error");
		exit (1);
	}
	printf("\nIN file msqidc(t2):%ld\n",rbuf.mtext.msqidc);
	//	printf("\n pid =%ld",getpid());
	//	fprintf(z,"%ld",getpid());
	fprintf(z,"\n%ld",sh_id2);
	fprintf(z,"\n%ld",rbuf.mtext.msqidc);
	fclose(z);
	//	sleep(20);
	while(1)
	{


		printf("\nT2->Enter the id to be SET:\n");
		scanf("%d",&rbuf.mtext.empid);
		printf("\n thread2 i/p id read\n");
		printf("\nT2->Enter the name to be SET:\n");
		scanf("%s",&nam);
		printf("\nthread2 i/p name read\n");
		rbuf.mtype=1;

		addr=(void *)shmat(sh_id2,(void *)0,0);

		if(addr==(void *)-1)
		{
			printf("\n error in =%d,errno");
			exit(1);
		}
		strncpy(addr,(char *)nam,7);
		printf("\nNAME STORED IN SHARED MEMORY:%s\n",addr);
		shmdt(addr);
		rbuf.mtext.choice=200;
		// sleep(5);
		if(msgsnd(msqid,&rbuf,(sizeof(rbuf)-sizeof(long)),0)==-1)
		{
			printf("%ld,%d,%s,%d,%d\n", msqid,rbuf.mtype,rbuf.mtext,sizeof(rbuf),errno);
			perror("msgsnd");
			exit(1);
		}

		else
		{
			printf("Message: %ld\t%d\t%d Sent from CLIENT\n",rbuf.mtext.msqidc,rbuf.mtext.empid,rbuf.mtext.choice);

		}


		if(msgrcv(rbuf.mtext.msqidc,&rbuf,(sizeof(rbuf)-sizeof(long)),0,0)==-1)
		{
			perror("msgrcv");
			exit(1);
		}

		printf("\nrbuf.mtext.choice=%d",rbuf.mtext.choice);
		switch(rbuf.mtext.choice)
		{
			case 3:
				printf("\n T_SET RECEIVED");
				break;
			case 4:
				printf("\n N_Set RECEIVED");
				break;
			case 10:
				printf("\nFOR T2..shutsig received...");


				//	printf("\nrbuf.mtext.msqidc=%ld",rbuf.mtext.msqidc);
				//	sleep(1);
				printf("\nT2 shut down fun() called");
				shutdown(sh_id2,temp1);
				//	int d;
				//	cleanup(d);
				break;

		}
		printf("\n waiting");
		sleep(10);
		if(msgrcv(rbuf.mtext.msqidc,&rbuf,(sizeof(rbuf)-sizeof(long)),0,IPC_NOWAIT)==-1)
		{
			perror("msgrcv");

		}


		printf("\nrbuf.mtext.choice=%d",rbuf.mtext.choice);
		switch(rbuf.mtext.choice)
		{
			case 3:
				printf("\n T_SET RECEIVED");
				break;
			case 4:
				printf("\n N_Set RECEIVED");
				break;
			case 10:
				printf("\nFOR T2..shutsig received...");


				//	printf("\nrbuf.mtext.msqidc=%ld",rbuf.mtext.msqidc);
				//	sleep(1);
				printf("\nT2 shut down fun() called");
				shutdown(sh_id2,temp1);
				//	int d;
				//	cleanup(d);
				break;

		}

	}
}

void shutdown(long sh,long msq)
{       
	static int n=0;
	printf("shmid:%ld\n",sh);
	printf("msqid:%ld\n",msq);
	if(shmctl(sh,IPC_RMID,0)<0 )
	{
		printf("\nError in shmctl,errno=%d",errno);
		exit(1);
	}
	printf("\n client SHARED MEMORY DELETED\n");

	if(msgctl(msq,IPC_RMID,NULL)<0)
	{
		printf("\n error in msgctl,errno=%d",errno);
		exit(1);
	}
	printf("\n CLIENT MESSAGE QUEUE DELETED\n");
	printf("semaphore id=%d\n",semid); 
	if(n<=0)
	{
		if((semctl(semid,0,IPC_RMID,0))==-1)
		{
			printf("\n semctl() initialization failed..");
			exit(1);
		}
		printf("\n semaphore deleted..");
		n++;
	} 
	file(sh,msq);

	pthread_exit(NULL);
}
void file(long sh,long msq)
{
	long s,q;
	FILE *w;
	w=fopen("f3","w+");
	if(w==NULL)
	printf("\n ERROR");
	FILE *f;
	f=fopen("f2","r");
	if(f==NULL)
	printf("\n ERROR");
	while(!feof(f))
	{
	fscanf(f,"%ld",&s);
	fscanf(f,"%ld",&q);
	if(sh!=s && msq!=q)
	{
			fprintf(w,"%ld\n",s);
			fprintf(w,"%ld\n",q);
         }
	}
	fclose(w);
	fclose(f);
     	rename("f3","f2");
printf("\n corresponding entries deleted in f2");
}
void cleanup(int d)
{
	long shmid,msgid;
	arg.val = 0 ;
	if((semid=semget(key,1,IPC_CREAT | 0666))==-1)
	{
		printf("error=%d\n",errno);
	}

	if(semctl(semid,0,SETVAL,arg)==-1) 
	{  
		printf("semctl-initialization\n");
		exit(1);
	}
	semop(semid,&acquire,0);
	FILE *x;
	x=fopen("f2","r");
	if(x==NULL)
	{
		printf("\n Error in opening file,%d\n",errno);
		exit(1);
	}
	while(!feof(x))
	{
		fscanf(x,"%ld",&shmid);
		fscanf(x,"%ld",&msgid);
		printf("shmid:%ld",shmid);
		printf("msqid:%ld",msgid);
		if((s1==shmid && m1==msgid)||(s2==shmid && m2==msgid))
		{
		if(shmctl(shmid,IPC_RMID,0)<0 )
		{
			printf("\nError in shmctl,errno=%d",errno);
			exit(1);
		}
		printf("\n client SHARED MEMORY DELETED\n");
		if(msgctl(msgid,IPC_RMID,NULL)<0)
		{
			printf("\n error in msgctl,errno=%d",errno);
			exit(1);
		}
		printf("\n CLIENT MESSAGE QUEUE DELETED\n");
		}
	} 
	printf("semaphore id1=%d\n",semid);
	if((semctl(semid,0,IPC_RMID,0))==-1)
		printf("\n semctl() initialization failed..");
	printf("\n semaphore1 deleted..");

	fclose(x);
	semop(semid,&release,0);
	printf("semaphore id2=%d\n",semid);
	if((semctl(semid,0,IPC_RMID,0))==-1)
		printf("\n semctl() initialization failed..");
	printf("\n semaphore2 deleted..");


	FILE *j;
        j=fopen("f4","w+");
        if(j==NULL)
        printf("\n ERROR");

	 FILE *y;
        y=fopen("f2","r");
        if(y==NULL)
        {
                printf("\n Error in opening file,%d\n",errno);
                exit(1);
        }  

        while(!feof(y))
        {
                fscanf(y,"%ld",&shmid);
                fscanf(y,"%ld",&msgid);
               // printf("shmid:%ld",shmid);
               // printf("msqid:%ld",msgid);
                if((s1!=shmid && m1!=msgid)&&(s2!=shmid && m2!=msgid))
                {
 			 fprintf(j,"%ld\n",shmid);
                         fprintf(j,"%ld\n",msgid);
                 }
	}
        fclose(j);
        fclose(y);
        rename("f4","f2");
	printf("\nCLEAN-UP: corresponding entries deleted in f2");
	//pthread_exit(NULL);
	exit(1);
}








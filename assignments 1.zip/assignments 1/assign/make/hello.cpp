

#include "functions.h"

void print_hello(){
   cout << "Hello World!"<<endl;
}


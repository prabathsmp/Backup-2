#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<sys/shm.h>
#include<stdio.h>
#include<stdlib.h> 
#include<signal.h>
#include<pthread.h>
#include<errno.h>
#include<string.h>
#define MSGSZ 256 
#define NUMSEMS 1
struct msg
{
	int empid;
	long msqidc;
	int choice;
};
struct msgbuf
{
	long mtype;
	struct msg mtext;
}sbuf,rbuf;
struct emp
{
	char name[10];
	int empid;

}e1[4];
long msqid;
void shut(int);
void writeback();
main()
{
	//  CR3EAING DATABASE
	signal(SIGINT,shut);      
	//struct emp e1[4];
	strcpy(e1[0].name,"arjun");
	e1[0].empid=1;
	strcpy(e1[1].name,"karti");
	e1[1].empid=2;
	strcpy(e1[2].name,"ram");
	e1[2].empid=3;
	strcpy(e1[3].name,"raju");
	e1[3].empid=4;






	FILE *fp;
	//	char ch;//choice
	char cha;
	int i=0;
	//filename
	char fil[]="database";
	fp=fopen(fil,"w+");
	if(fp!=NULL) 

		for(;i<4;i++)
		{
			fprintf(fp,"%s\t%d\n",e1[i].name,e1[i].empid);
		}
	//{
	/*printf("1) data entry 2)exit\n");
	  scanf("%c",&ch);
	  if(ch=='1')
	  {
	  printf("Enter the emp name and id details:\n");
	  for(;i<4;i++)
	  {
	  scanf("%s%d",&e1[i].name,&e1[i].empid);
	  fprintf(fp,"%d\t%s\n",e1[i].empid,e1[i].name);

	  }
	  }	 
	//break;
	// }*/ 
	printf("The contents of %s file are :- \n\n", fil);
	fseek(fp,0,SEEK_SET);
	while((cha = fgetc(fp))!= EOF)
		printf("%c",cha);

	fclose(fp);
	printf("\nDB closed");

	/*int semid,rc;
	  key_t semkey;
	  struct sembuf operations;
	  short sarray[NUMSEMS];
	  semkey=ftok(".",'z');
	  if(semkey==(key_t)-1)
	  perror("\n ftok() failed..");
	  if((semid=semget(semkey,NUMSEMS,0666|IPC_CREAT))==-1)
	  perror("\n semget failed..");
	  printf("\n semid:%d",semid);
	  int semaphore_id=semid;
	  sarray[0]=0;
	  operations.sem_num=0;
	  operations.sem_op=1;
	  operations.sem_flg=SEM_UNDO;
	  rc=semop(semid,&operations,1);
	  if(rc==-1)
	  {
	  perror("\n semop() failed...");
	  }
	  */
	//CREATING MSQ
	struct msgbuf sbuf;
	key_t key;
	key =ftok("/home/prabath/data",23);


	if((msqid = msgget(key,0666 | IPC_CREAT))==-1)
	{
		perror("msgget");
		printf("%ld",msqid);
		exit(1);
	}

	else
	{   


		// WRITING MSQID IN FILE
		printf("\nServer Message queue created\n");
		FILE *fp1;

		fp1=fopen("/tmp/servermq","w");
		printf("\nFile opened\n");
		fprintf(fp1,"%ld",msqid);
		printf("\nservermsqid=%ld\n",msqid);
		fclose(fp1);
	}	// RECEIVING CHOICE FROM THREAD1
	while(1)
	{
		if(msgrcv(msqid,&sbuf,sizeof(sbuf),0,MSG_NOERROR) < 0)
		{	
			printf("\n%d",msqid);
			printf("\nerrno =[%x][%d]",errno,errno);
			perror("\nmsgrcv");
			exit(1);

		}
		printf("\n\n");	
		printf("\nclient msqidc1=%ld\tEmpid=%d\tChoice=%d", sbuf.mtext.msqidc,sbuf.mtext.empid,sbuf.mtext.choice);

		FILE *fp2;
		long shmid,shmid1;

		long msqic,msqidcl;

		fp2=fopen("f2","r");
		while(!feof(fp2))
		{ 
			fscanf(fp2,"%ld",&shmid);
			fscanf(fp2,"%ld",&msqic);
			//	printf("\n s1 -%ldm1- %ld sbuf.mtext.msqidc-%ld\n",shmid,msqic,sbuf.mtext.msqidc);
			if(sbuf.mtext.msqidc==msqic)
			{
				shmid1=shmid;
				msqidcl=msqic;
			}


		}
		int c=sbuf.mtext.choice;
		sbuf.mtype=1;
		printf("msqidcl= %ld",msqidcl);
		printf("\nshmid= %ld",shmid1);

		int id1=sbuf.mtext.empid;
		char *addr;

		i=0; 
		printf("\nchoice=%d",c);              
		char nam[10];
		switch(c)
		{
			case 100:
				printf("\nGET FUN() ENCOUNTERED");
				for(i=0;i<4;i++)
				{

					if(e1[i].empid==id1)
					{
						printf("\nID MATCH FOUND");

						addr=(char *)shmat(shmid1,(char *)0,0);

						if(addr==(void *)-1)
						{
							printf("\n error:%d",errno);
							exit(1);
						}
						strncpy(addr,(char *)e1[i].name,10);
						printf("\n THE CORRESPONDING EMP NAME WRITTEN IN SHARED MEMORY:%s\t%s",addr,e1[i].name);
						sleep(10);
						sbuf.mtext.choice=1;
						// T__GET MESSAGE
						if(msgsnd(msqidcl,&sbuf,(sizeof(sbuf)-sizeof(long)),0)<0)
							perror("\nmsgsnd");
						break;	


					}       // N_GET MESSAGE
					else if(i==3)
					{ 
						printf("\n Sorry, pls Enter the valid id");
						sbuf.mtext.choice=2;
						sleep(10);

						if(msgsnd(msqidcl,&sbuf,(sizeof(sbuf)-sizeof(long)),0)==-1)
							perror("\nmsgsnd");

					}                                           

				}


				break;






			case 200:                

				printf("\nSET Encountered");
				for(;i<4;i++)
				{
					if(e1[i].empid==id1)
					{
						printf("\nMatched id found");
						addr=(void *)shmat(shmid1,(void*)0,0);
						if(addr==(void*)-1)
							printf("\n error");  

						strncpy(e1[i].name,addr,10);
						shmdt(addr);
						printf("\nid=%d\tnam=%s",e1[i].empid,e1[i].name);

						//T_SET MESSAGE  
						sleep(10);
						sbuf.mtext.choice=3;
						if(msgsnd(msqidcl,&sbuf,(sizeof(sbuf)-sizeof(long)),0)==-1)
							perror("\nmsgsnd");

						FILE * fptr;
						fptr=fopen("backup","a+");
						if(fptr==NULL)
						{
							printf("error\n");
							exit(1);
						}
						fprintf(fptr,"%d \t %s\n",e1[i].empid,e1[i].name);
						fclose(fptr);
						break;
					}

					//N_SET  MESSAGE

					else if(i==3)
					{

						printf("\n Sorry, pls Enter the valid id");
						sleep(10);
						sbuf.mtext.choice=4;
						if(msgsnd(msqidcl,&sbuf,(sizeof(sbuf)-sizeof(long)),0)==-1)
							perror("\nmsgsnd");
					} 
				}
				break;	

		}

	}

	return 0;
}
void writeback()
{
	FILE *tr;
	tr=fopen("database","w+");
	if(tr==NULL)
		printf("\n error");
	int i=0;
	for(;i<4;i++)
	{
		fprintf(tr,"%s\t%d\n",e1[i].name,e1[i].empid);
	}
	fclose(tr);
}

void shut(int w)
{

	long msqids,shm,sd;
	long msqidcc;
	printf("\nserver QUEUE ID=%ld\n",msqid);
	if(msgctl(msqid,IPC_RMID,0)<0)
	{
		printf("errorno= %d",errno);
		exit(1);
	}
	printf("\n server message queue deleted\n");

	FILE *fp3;
	fp3=fopen("f2","r");
	if(!fp3)
	{	
		printf("\n error in opening file,%d\n",errno);
		exit(1);
	}
	while(!feof(fp3))
	{
		fscanf(fp3,"%ld",&shm);
		fscanf(fp3,"%ld",&msqids);
		fscanf(fp3,"%ld",&sd);
		fscanf(fp3,"%ld",&msqidcc);


		/*        printf("\n shmid1=%ld",shm);
			  printf("\n msq11=%ld",msqids);
			  printf("\n shmid2=%ld",sd);
			  printf("\n msq2=%ld",msqidcc);*/
		int j=10; 
		sbuf.mtype=1;
		sbuf.mtext.choice=j;
		printf("\n client msqidcl=%ld\n",msqids);
		if(msgsnd(msqids,&sbuf,(sizeof(sbuf)-sizeof(long)),0)==-1)
		{
			printf("\nmsgsnd %d",errno);
			exit(1);
		}
		printf("\n shut signal sent to thread\n");
		printf("\n client msqidcl-2=%ld\n",msqidcc);
		sbuf.mtype=1;
		if(msgsnd(msqidcc,&sbuf,(sizeof(sbuf)-sizeof(long)),0)==-1)
		{
			printf("\nmsgsnd %d",errno);
			exit(1);
		}
		printf("\n shut signal sent to thread2\n"); 
	}
	fclose(fp3); 
	writeback();
	sleep(5);
	/*     if((semctl(semaphore_id,1,IPC_RMID,0))==-1)
	       perror("\n semctl() initialization failed..");
	       printf("\n semaphore deleted..");
	       */
}      


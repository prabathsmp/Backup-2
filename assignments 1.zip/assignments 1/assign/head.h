#include<iostream>
#include<malloc.h>
using namespace std;
struct Node
{
        int value;
        struct Node *next;
        struct Node *prev;
};
struct Node *head=NULL,*tail=NULL;

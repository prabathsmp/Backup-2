#include<pthread.h>
#include<stdio.h>
#include<sys/ipc.h>
#include<stdlib.h>
#include<ctype.h>
#include<sys/types.h>
#include<errno.h>
#include<malloc.h>
#include<sys/msg.h>
static int buf=0;
//LINKED LIST CREATION
struct node
{
        int val1,val2;
        int ch;
       // int buf;
        struct node *next;
};
struct node *head=NULL,*tail=NULL;
struct node * createnode(int val1,int val2,int ch)
{
        struct node *temp=(struct node *)malloc(sizeof(struct node));
        temp->val1=val1;
        temp->val2=val2;
        temp->ch=ch;
       // temp->buf=0;
        temp->next=NULL;
        return temp;
}
void append(int val1,int val2,int ch)
{


        struct node *temp=createnode(val1,val2,ch);
        if(!head)//if(head==NULL)
                head=temp;
        else
                tail->next=temp;
        tail=temp;
}

pthread_mutex_t job_queue_mutex = PTHREAD_MUTEX_INITIALIZER;
//THREAD1 FUNCTION
void* add(void* a)
{
        int add;
        FILE *fp;
        char fname[10];
        struct node *p=head;
       // buf=0;
        pthread_mutex_lock(&job_queue_mutex);
        add=(p->val1)+(p->val2);
        printf("add:%d",add);
        printf("\n enter the filename");
        scanf("%s",fname);
        fp=fopen(fname,"a+");
        fprintf(fp,"%d+%d=%d\n",p->val1,p->val2,add);
        buf++;
        printf("\nBuffer value:%d",buf);
        if(buf==2)
                deletenode();


        pthread_mutex_unlock(&job_queue_mutex);
        return NULL;
}

void* sub(void* b)
{
        int sub;
        FILE *fp;
        char fname[10];
        struct node *p=head;
        pthread_mutex_lock(&job_queue_mutex);
        sub=(p->val1)-(p->val2);
        printf("sub:%d",sub);
        printf("\n enter the file name");
        scanf("%s",fname);
        fp=fopen(fname,"a+");
        fprintf(fp,"%d-%d=%d\n",p->val1,p->val2,sub);
        buf++;
        printf("\nBuffer value:%d",buf);
        if(buf==2)
                deletenode();
        pthread_mutex_unlock(&job_queue_mutex);
        return NULL;
}

void deletenode()
{
        struct node *trav1;
        trav1=head;
        head=head->next;
        if(!head)
                tail=NULL;
        free(trav1);
}


int main()
{
        pthread_t thread1;
        pthread_t thread2;
        int a,b;
        int ch;
 while(1)
        {
                printf("\n1.Computation \n2.Exit\nEnter your choice:");
                scanf("%d",&ch);
                switch(ch)
                {
                        case 1:
                                printf("\nEnter the two numbers for node");
                                scanf("%d%d",&a,&b);
                                append(a,b,ch);
                                struct node *trav1=head;
                              
                                {
                                        printf("\ncreated linked list");
                                        pthread_create(&thread1,NULL,&add,NULL);
                                        printf("\ncreated thread");
                                        pthread_create(&thread2,NULL,&sub,NULL);
                              
                               
                                }
                             
                                break;
                        case 2:
                                exit(1);
                }
                 pthread_join(thread1,NULL);
                                pthread_join(thread2,NULL);
        }
        return 0;
}







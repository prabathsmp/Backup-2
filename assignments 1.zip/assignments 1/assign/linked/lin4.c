#include<stdio.h>
#include<malloc.h>
#include<stdlib.h>

struct Node
{
        int value;
        struct Node *next;
};
struct Node *head=NULL,*tail=NULL;

struct Node * createnode(int val)
{
        struct Node *temp=(struct Node *)(malloc(sizeof(struct Node)));
        temp->value=val;
        temp->next=temp;
        return temp;
}
void append()
{
	struct Node *trav1=NULL;
        int val;
        printf("\n Enter the Value:");
        scanf("%d",&val);
        struct Node* temp=createnode(val);
        if(!head)
                head=temp;
	else
	{
		for(trav1=head;trav1->next!=head;trav1=trav1->next);
		trav1->next=temp;
		temp->next=head;
	}
}
void deletenode()
{
	int pos,i;
        printf("\n Enter the position of the node to be deleted:");
        scanf("%d",&pos);
        struct Node* temp=NULL;
        struct Node *trav1=NULL,*trav2=NULL;
        if(pos<1 || !head)
                printf("\nPosition error\n");
        else if(pos==1)   
	{
                if(head->next==head)
		{
			head->next=NULL;
	free(head);
			head=NULL;
		}
		else
		{
		for(trav1=head;trav1->next!=head;trav1=trav1->next);
                head=head->next;
		trav1->next->next=NULL;
                free(trav1->next);
		trav1->next=head;
		}
		
        }
	else
	{
		trav1=trav2=head;
                for(i=1;i<pos;i++)
                {
                        trav2=trav1;
                        trav1=trav1->next;
                }
                if(trav1)
                {
                        if(trav1->next==head)
                        {
                                trav2->next=head;
				trav1->next=NULL;
                                free(trav1);
                        }
                        else
                        {
                        trav2->next=trav1->next;
                        free(trav1);
                        }
                }
                else
                        printf("\n Position Error..");
	}
}
void list()
{
	if(head)
	{
        	struct Node *temp=head;
        	for(;temp->next!=head;temp=temp->next)
        	        printf("\n%d",temp->value);
		printf("\n%d",temp->value);
	}
}
void freememory()
{
	if(head)
	{
		struct Node*temp=head;
        	for(;temp && temp->next!=head;temp=temp->next)
			free(temp);
		free(temp);
	}
}

int main()
{
        int c;
         printf("\n1->append 2->deletenode 3->list 4->exit \n Enter Choice:");
        scanf("%d",&c);
        while(1)
        {
                switch(c)
                {
                        case 1:append();
                                break;
                        case 2:deletenode();
                                break;
                        case 3:list();
                                break;
                        case 4:freememory();
				exit(1);
                }
                 printf("\n1->append 2->deletenode 3->list 4->exit \n Enter Choice:");
                scanf("%d",&c);
        }
        return 0;
}

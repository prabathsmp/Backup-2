#include<stdio.h>
#include<malloc.h>
#include<ncurses.h>
//#include<conio.h>
struct Node
{
	int value;
	struct Node *next;
};
struct Node *head=NULL,*tail=NULL;


struct Node * createNode(int value)
{

	struct Node *temp=(struct Node *)malloc(sizeof(struct Node));
	if(temp)
	{
	temp->value=value;
	temp->next=NULL;
	return temp;
	}
}
void append()
{
	int value;
	printf("\n Enter a value .. ");
	scanf("%i",&value);
	struct Node *temp=createNode(value);
	if(temp && !head)
		head=temp;
	else
		tail->next=temp;
	tail=temp;
	display();
}
void delete()
{
	int pos,i;
	struct Node *trav1;
	struct Node *trav2;
	printf("Enter the position to be deleted:\n");
	scanf("%d",&pos);
	if(pos<1 ||!head)
		printf("position error\n");
	else if(pos==1)
	{
		trav1=head;
		head=head->next;
		if(head==NULL)
			tail=NULL;
		free(trav1);
//	display();
	}
	else
	{
		trav2=trav1=head;
		for(i=1;i<pos;i++)
		{
			trav2=trav1;
			trav1=trav1->next;
			if(!trav1)
			{
			printf("\n Enter the valid position");
			break;
			}
		}
		if(trav1)
		{
			trav2->next=trav1->next;
			if(trav1==tail)
				tail=trav2;
			free(trav1);
		}
//		display();	
	}
}
void t()
{
int val;
printf("Enter the element to be deleted:\n");
	scanf("%d",&val);
struct Node *trav1;
	struct Node *trav2;
	struct Node *temp;
	trav2=trav1=head;
		for(temp=head;temp->value!=val;temp=temp->next)
		{
			trav2=trav1;
			trav1=trav1->next;
			if(!trav1)
			{
			printf("\n Enter the valid position");
			break;
			}
		}
		if(trav1)
		{ 
			if(trav1==head)
			{
			head=head->next;
			if(head==NULL)
			tail=NULL;
			free(trav1);
				}
			else
			{
			trav2->next=trav1->next;
			if(trav1==tail)
				tail=trav2;
			free(trav1);
			}	
		}
//		display();	
	}


void insert()
{
 int value,pos;
struct Node *trav1;
struct Node *trav2;
        printf("\n Enter a value .. ");
        scanf("%i",&value);
        struct Node *temp=createNode(value);
 	printf("Enter the position to be inseted:\n");
        scanf("%d",&pos);
        if(pos<1 ||!head)
                printf("position error\n");
 	else
        {
                trav2=trav1=head;
		int i;
                for(i=1;i<pos && trav1;i++)
                {
                        trav2=trav1;
                        trav1=trav1->next;
			if(!trav1)
			{
			printf("\n Enter the valid position");
			break;
			}
                }
                if(trav2)
		{
		trav2->next=temp;
		temp->next=trav1;
		}
	}
}
void freememory()
{
        if(head)
        {
                struct Node*temp=head;
                for(;temp!=NULL;temp=temp->next)
                        free(temp);
                //free(temp);
        }
}

		
void display()
{
	struct Node *temp;
	for(temp=head;temp;temp=temp->next)
		printf("%d\t",temp->value);
	
}

void menu()
{
printf("1->APPEND\n");
printf("2->DELETE\n");
printf("3->INSERT\n");
printf("4->LIST\n");
printf("5->EXIT\n");
}
main()
{
 int ch;
	menu();

	while(1)
	{
	printf("Enter the choice:\n");
	scanf("%d",&ch);
	switch(ch)
		{
		case 1:
			append();
			break;
		case 2:
				t();
			//delete();
			break;
		case 4:
			display();
			break;
		case 3:
			insert();
			break;
		case 5:
			 freememory();
			exit(1);
		}
          menu();
	}
//getch();
}
  



































#include<stdio.h>
#include<malloc.h>
#include<ncurses.h>
//#include<conio.h>
struct Node
{
	int value;
	struct Node *next;
	struct Node *prev;
};
struct Node *head=NULL,*tail=NULL;


struct Node * createNode(int value)
{

	struct Node *temp=(struct Node *)malloc(sizeof(struct Node));
	if(temp)
	{
	temp->value=value;
	temp->next=NULL;
	temp->prev=NULL;
	return temp;
	}
}
void append()
{
	int value;
	printf("\n Enter a value .. ");
	scanf("%i",&value);
	struct Node *temp=createNode(value);
	if(temp)
	{
	if(!head)
	{
		head=temp;
		head->prev=NULL;
		head->next=NULL;
	}	
	else
	{	
		tail->next=temp;
		temp->prev=tail;	
		//	temp->next=NULL;
	}	
	tail=temp;

	display();
	}	
}
void deletep()
{
	int pos,i,c=0;
	struct Node *trav1;
	struct Node *trav2;
	struct Node *trav3;
	printf("Enter the position to be deleted:\n");
	scanf("%d",&pos);
	if(pos<1 ||!head)
	{
		printf("position error\n");
	
	}
	else if(pos==1)
	{
		trav1=head;
		head=head->next;
		head->prev=NULL;
		if(head==NULL)
		{
			head->next=NULL;
			head->prev=NULL;
			tail=NULL;
		}
		free(trav1);
		//	display();
	}
	else
	{
		trav2=trav1=head;
		for(i=1;i<pos;i++)
		{
			trav2=trav1;
			trav1=trav1->next;
			if(!trav1)
			{
			printf("\n Enter the valid position");
			c==1;
			}
		/*	if(trav1==tail)
			{
				c=1;
				tail=trav2;
				trav2->next=NULL;
				free(trav1);
			}*/
			if(c==1)
				break;
		}
		
		
			trav3=trav1->next;
			if(!trav3)
			{
			trav2->next=NULL;
			tail=trav2;
			free(trav1);
			}
			if(trav1 && trav2 && trav3)
			{
				trav2->next=trav3;
				trav3->prev=trav2;

				if(trav1==tail)
					tail=trav2;
				free(trav1);
			}
			
		}	//		display();	
	
}
void t()
{
int val,c=0;
struct Node *trav1;
	struct Node *trav2;
	struct Node *trav3;
	struct Node *temp;
	printf("Enter the value to be deleted:\n");
	scanf("%d",&val);
	/*if(pos<1 ||!head)
	{
		printf("position error\n");
		append();
	}
	else if(pos==1)
	{
		trav1=head;
		head=head->next;
		head->prev=NULL;
		if(head==NULL)
		{
			head->next=NULL;
			head->prev=NULL;
			tail=NULL;
		}
		free(trav1);
}
	else
	{*/
		trav2=trav1=head;
		for(temp=head;temp->value!=val;temp=temp->next)
		{
			trav2=trav1;
			trav1=trav1->next;
			if(!trav1)
			{
			printf("\n Enter the valid position");
			c=1;
			}
		if(c==1)
		break;
		}
		
			trav3=trav1->next;
			if(!trav3)
			{
			trav2->next=NULL;
			tail=trav2;
			free(trav1);
			}
			if(trav1==head)
			{
			trav1=head;
			head=head->next;
			head->prev=NULL;
				if(head==NULL)
				{
				head->next=NULL;
				head->prev=NULL;
				tail=NULL;
				}
			free(trav1);
			
			}
			if(trav1 && trav2 && trav3)
			{
				trav2->next=trav3;
				trav3->prev=trav2;

				if(trav1==tail)
					tail=trav2;
				free(trav1);
			}
			
			//		display();	
	
}
			
			
			
			
void insert()
{
	int value,pos;
	struct Node *trav1;
	struct Node *trav2;
	printf("\n Enter a value .. ");
	scanf("%i",&value);
	struct Node *temp=createNode(value);
	if(temp)
	{
	printf("Enter the position to be inseted:\n");
	scanf("%d",&pos);
	if(pos<1 ||!head)
		printf("position error\n");
	else
	{
		trav2=trav1=head;
		int i;
		for(i=1;i<pos && trav1;i++)
		{
			trav2=trav1;
			trav1=trav1->next;
		}
		if(trav1 && trav2)
		{
			trav2->next=temp;
			temp->prev=trav2;
			temp->next=trav1;
			trav1->prev=temp;
		}
	}
	}
}
void display()
{
	struct Node *temp;
	for(temp=head;temp;temp=temp->next)
		printf("%d\t",temp->value);

}
void freedown()
{
struct Node * temp;
	for(temp=head;temp;temp=temp->next)
		free(temp);
		free(temp);
}
void menu()
{
	printf("1->APPEND\n");
	printf("2->DELETE\n");
	printf("3->INSERT\n");
	printf("4->LIST\n");
	printf("5->EXIT\n");
}
main()
{
	int ch;
	menu();

	while(1)
	{
		printf("Enter the choice:\n");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				append();
				break;
			case 2:
				deletep();
				break;
			case 4:
				display();
				break;
			case 3:
				insert();
				break;
			case 5:
				freedown();
				exit(1);
		}
		menu();
	}
	//getch();
}




































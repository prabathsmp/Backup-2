//#include<iostream>
//#include<malloc.h>
//using namespace std;
#include<head.h>
class base
{
public:
virtual struct Node * createnode(int)=0;
virtual operaotr+()=0;
virtual operator-()=0;
virtual operator*()=0;
virtual freedown ()=0; 
};
class sl:public base
{
public:

	
 

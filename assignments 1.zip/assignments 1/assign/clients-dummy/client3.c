#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<sys/shm.h>
#include<signal.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<pthread.h>
#include<errno.h>
#define MSGSZ 256
#define SIZE 30
struct msg
{
        int empid;
        long msqidc;
        int choice;
};
struct msgbuf
{
        long mtype;
        struct msg mtext;
        
} sbuf,bufc;
        key_t keyc;

        keyc=6763;

        long int sh_id;
        void shared();
        void shutdown(int);
int main()
{
        signal(SIGINT,shutdown);
        long msqid;
        int msgflg = 0666 | IPC_CREAT;
        struct msgbuf sbuf;
        size_t buf_length;
while(1)
{
 FILE *pfile;

        pfile = fopen("f1","r+");
        printf("\nFile open success");
        if(pfile!=NULL)
         {
                     fscanf(pfile,"%ld",&msqid);
                     printf("\n Received servermsqid=%ld\n",msqid);
         }


        fclose (pfile);
        printf("\nFile close success");

        shared();



    //   SEND DATA TO SERVER
              sbuf.mtype=1;              
              printf("\nEnter the emp id to be tested:\n");
              scanf("%d",&sbuf.mtext.empid);
              printf("\n Menu\n 10->C_GET 20->C_SET 30->EXIT"); 
	      scanf("%d",&sbuf.mtext.choice);

              switch(sbuf.mtext.choice)
                {
                case 10:
                case 20:


                        printf("%d%d",sbuf.mtext.choice,sbuf.mtext.empid);

                        if((sbuf.mtext.msqidc=msgget(keyc,0666|IPC_CREAT))==-1)
                        {
                                perror("msgget");
                                exit(1);
                           }

                        printf("%ld",sbuf.mtext.msqidc);


        		FILE *t;
        		t=fopen("f2","w");
        		if(t==NULL)
       			{
                	fputs("File error",stderr);
                	exit (1);
       			}
                	printf("msqidc:%ld",sbuf.mtext.msqidc);
			printf("\n pid =%ld",getpid());
			fprintf(t,"\n%ld",getpid());
                	fprintf(t,"\n%ld",sh_id);
                	fprintf(t,"\n%ld",sbuf.mtext.msqidc);
                	fclose(t);


                        sleep(2);

                        if(msgsnd(msqid,&sbuf,sizeof(sbuf),0)==-1)
                        {
                        printf("%ld,%d,%s,%d,%d\n", msqid,sbuf.mtype,sbuf.mtext,sizeof(sbuf),errno);
                        perror("msgsnd");
                        exit(1);
                        }

                        else
                        {
                        printf("Message: %ld\t%d\t%d Sent from CLIENT\n",sbuf.mtext.msqidc,sbuf.mtext.empid,sbuf.mtext.choice);

                        }
                        break;
		case 30:
			exit(1);
              }
			sleep(5);


        	if(msgrcv(sbuf.mtext.msqidc,&bufc,sizeof(bufc),1,0)==-1)
        	{
                perror("msgrcv");
                exit(1);
        	}
            
        	printf("\n bufc.mtext.choice=%d",bufc.mtext.choice);
        	switch(bufc.mtext.choice)
        	{
                case 1:
                        printf("\n T_GET RECEIVED");
                        break;
                case 2:
                        printf("\n N_get RECEIVED");
                        break;
                case 3:
                        printf("\n T_SET RECEIVED");
                        break;
                case 4:
                        printf("\n N_set RECEIVED");
                      
       		}		
        	sleep(4);
        	         	        		
        	printf("\nshutsig received...");
        			
		if(msgrcv(sbuf.mtext.msqidc,&bufc,sizeof(bufc),2,0)==-1)
                {
                perror("msgrcv");
                exit(1);
                }
		 printf("\n bufc.mtext.choice=%d",bufc.mtext.choice);
        	if(bufc.mtext.choice==10)
        	{
                int d;
                printf("\n shut down fun() called");
  		shutdown(d);
        	}
    }

return 0;

}



void shared()
{
        key_t ikey;
        sh_id=shmget(ikey=5651,SIZE,0666 | IPC_CREAT);
        if(sh_id==-1)
        printf("error\n");

        printf("shm id =%ld",sh_id);
}

void shutdown(int a)
{       
	long shmid;
        long msqid;
	long pid1=getpid();
	long pid;
        FILE *fp1;
        fp1=fopen("f2","r+");
       // printf("\nFile open successful"); 
        while(!feof(fp1))
	{
	fscanf(fp1,"%ld",&pid);
	fscanf(fp1,"%d",&shmid);
	fscanf(fp1,"%ld",&msqid);
        
	if(pid1==pid)
           {
            sh_id=shmid;
	   sbuf.mtext.msqidc=msqid;
	}
	break;
	}
	fclose(fp1);
	printf("shmid:%d",sh_id);
        printf("msqid:%ld",sbuf.mtext.msqidc);
	if(shmctl(sh_id,IPC_RMID,0)<0 )
        {
        printf("\nError in shmctl,errno=%d",errno);
        exit(1);
        }
        printf("\n client SHARED MEMORY DELETED");
     //   fscanf(fp1,"%ld",&msqid);
       // fclose(fp1);
       //  printf("msqid:%ld",sbuf.mtext.msqidc);

        if(msgctl(sbuf.mtext.msqidc,IPC_RMID,NULL)<0)
        {
         printf("\n error in msgctl,errno=%d",errno);
        exit(1);
        }
        printf("\n CLIENT MESSAGE QUEUE DELETED");
       
}
                                                   

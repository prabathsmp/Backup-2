#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<sys/shm.h>
#include<signal.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<pthread.h>
#include<errno.h>
#define MSGSZ 256
#define SIZE 30
struct msg
{
	int empid;
	long msqidc;
	int choice;
};
struct msgbuf
{
	long mtype;
	struct msg mtext;

} sbuf,rbuf;
//struct msgbuf bufc;
//long int sh_id;
long msqid;
void* get(void *);
void* set(void *);
void cleanup(int);
void shutdown(long,long);

int main()
{
	FILE *pfile;

	pfile = fopen("/tmp/servermq","r");

	printf("\nFile open success");
	if(pfile!=NULL)

	{
		if(feof(pfile))
			exit(1);
		fscanf(pfile,"%ld",&msqid);
		printf("\n Received servermsqid=%ld\n",msqid);
	}

	else
	{
		printf("\n file not exist\n");
		exit(1);
	}

	fclose (pfile);
	printf("\nFile close success");





	pthread_t thread1;
	pthread_t thread2;
	signal(SIGINT,cleanup);
	//	long msqid;
	//struct msgbuf sbuf;
	// size_t buf_length;
	//   SEND DATA TO SERVER
	pthread_create(&thread1,NULL,&get,NULL);

	pthread_create(&thread2,NULL,&set,NULL);

	pthread_join(thread1,NULL); 
	pthread_join(thread2,NULL);
	//	 pthread_join(thread1,NULL);                          
	return 0;
}

void * get(void *q)
{                      
	printf("\n currently in thread1\n");
	struct msgbuf sbuf;
	long sh_id;
	key_t  keyc=6670;
	//keyc =ftok("/home/prabath/data",12);   key_t keyc=6669;
	if((sbuf.mtext.msqidc=msgget(keyc,0666|IPC_CREAT))==-1)
	{
		perror("msgget");
		exit(1);
	}

	printf("\nthread1 messageQ id:%ld\n",sbuf.mtext.msqidc);

	//key_t ikey;
	sh_id=shmget(5671,SIZE,0666 | IPC_CREAT);
	if(sh_id==-1)
		printf("error\n");

	printf("\nshm id(t1) =%ld\n",sh_id);
      //sleep(30);
	FILE *s;
	s=fopen("f2","a");
	if(s==NULL)
	{
		printf("File error");
		exit (1);
	}
	printf("\nIN file msqidc(t1):%ld\n",sbuf.mtext.msqidc);
	fprintf(s,"\n%ld",sh_id);
	fprintf(s,"\n%ld",sbuf.mtext.msqidc);
	fclose(s);
	while(1)
	{
		printf("\n Enter the employee id:\n");
		scanf("%d",&sbuf.mtext.empid);
		sbuf.mtext.choice=100;
		sbuf.mtype=0;
		if(msgsnd(msqid,&sbuf,(sizeof(sbuf)-sizeof(long)),0)==-1)
		{
			printf("%ld,%d,%s,%d,%d\n", msqid,sbuf.mtype,sbuf.mtext,sizeof(sbuf),errno);
			perror("msgsnd");
			exit(1);
		}

		else
		{
			printf("Message: %ld\t%d\t%d Sent from CLIENT\n",sbuf.mtext.msqidc,sbuf.mtext.empid,sbuf.mtext.choice);

		}




		if(msgrcv(sbuf.mtext.msqidc,&sbuf,(sizeof(sbuf)-sizeof(long)),0,0)==-1)
		{
			perror("msgrcv");
			exit(1);
		}

		printf("\n bufc.mtext.choice=%d",sbuf.mtext.choice);
		switch(sbuf.mtext.choice)
		{
			case 1:
				printf("\n T_GET RECEIVED");
				break;
			case 2:
				printf("\n N_get RECEIVED");
				break;

			case 10:

				printf("\nshutsig received...");
				int d;
				printf("\n shut down fun() called");
				shutdown(sh_id,sbuf.mtext.msqidc);
				break;

		}
	}
}



void * set(void *e)
{ 
	char *addr;
	char nam[7];
	long sh_id2;
	struct msgbuf rbuf;
	key_t key2=6550;
	printf("\n currently in thread2\n");
	if((rbuf.mtext.msqidc=msgget(key2,0666|IPC_CREAT))==-1)
	{
		perror("msgget");
		exit(1);
	}

	printf("\nmsq-2=%ld\n",rbuf.mtext.msqidc);

	sh_id2=shmget(5679,SIZE,0666 | IPC_CREAT);
	if(sh_id2==-1)
		printf("error\n");

	printf("\nshm id(t2) =%ld\n",sh_id2);
        // sleep(15);
	FILE *z;
	z=fopen("f2","a");
	if(z==NULL)
	{
		printf("File error");
		exit (1);
	}
	printf("\nIN file msqidc(t2):%ld\n",rbuf.mtext.msqidc);
	//	printf("\n pid =%ld",getpid());
	//	fprintf(z,"%ld",getpid());
	fprintf(z,"\n%ld",sh_id2);
	fprintf(z,"\n%ld",rbuf.mtext.msqidc);
	fclose(z);
//	sleep(20);
	while(1)
	{
		printf("\nEnter the id to be SET:\n");

		scanf("%d",&rbuf.mtext.empid);
		printf("\nEnter the name to be SET:\n");
		scanf("%s",&nam);
		rbuf.mtype=0;

		addr=(void *)shmat(sh_id2,(void *)0,0);

		if(addr==(void *)-1)
		{
			printf("\n error in =%d,errno");
			exit(1);
		}
		strncpy(addr,(char *)nam,7);
		printf("\nNAME STORED IN SHARED MEMORY:%s\n",addr);
		shmdt(addr);
		rbuf.mtext.choice=200;

		if(msgsnd(msqid,&rbuf,(sizeof(rbuf)-sizeof(long)),0)==-1)
		{
			printf("%ld,%d,%s,%d,%d\n", msqid,rbuf.mtype,rbuf.mtext,sizeof(rbuf),errno);
			perror("msgsnd");
			exit(1);
		}

		else
		{
			printf("Message: %ld\t%d\t%d Sent from CLIENT\n",rbuf.mtext.msqidc,rbuf.mtext.empid,rbuf.mtext.choice);

		}


		if(msgrcv(rbuf.mtext.msqidc,&rbuf,(sizeof(rbuf)-sizeof(long)),0,0)==-1)
		{
			perror("msgrcv");
			exit(1);
		}

		printf("\nrbuf.mtext.choice=%d",rbuf.mtext.choice);
		switch(rbuf.mtext.choice)
		{
			case 3:
				printf("\n T_SET RECEIVED");
				break;
			case 4:
				printf("\n N_Set RECEIVED");
				break;
			case 10:
				printf("\nshutsig received...");

				printf("\n shut down fun() called");
				shutdown(sh_id2,rbuf.mtext.msqidc);
				break;
		}
	}
}

void shutdown(long sh,long msq)
{       
	printf("shmid:%ld\n",sh);
	printf("msqid:%ld\n",msq);
	if(shmctl(sh,IPC_RMID,0)<0 )
	{
		printf("\nError in shmctl,errno=%d",errno);
		exit(1);
	}
	printf("\n client SHARED MEMORY DELETED\n");

	if(msgctl(msq,IPC_RMID,NULL)<0)
	{
		printf("\n error in msgctl,errno=%d",errno);
		exit(1);
	}
	printf("\n CLIENT MESSAGE QUEUE DELETED\n");

}
void cleanup(int d)
{
	long shmid,msgid;
	FILE *x;
	x=fopen("f2","r");
	if(x==NULL)
	{
		printf("\n Error in opening file,%d\n",errno);
		exit(1);
	}
	while(!feof(x))
	{
		fscanf(x,"%ld",&shmid);
		fscanf(x,"%ld",&msgid);
		printf("shmid:%ld",shmid);
		printf("msqid:%ld",msgid);
		if(shmctl(shmid,IPC_RMID,0)<0 )
		{
			printf("\nError in shmctl,errno=%d",errno);
			exit(1);
		}
		printf("\n client SHARED MEMORY DELETED\n");
		if(msgctl(msgid,IPC_RMID,NULL)<0)
		{
			printf("\n error in msgctl,errno=%d",errno);
			exit(1);
		}
		printf("\n CLIENT MESSAGE QUEUE DELETED\n");
	}
	fclose(x);
}









/*  Using shared memory */

#include <iostream>
#include <cstdio>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <sys/sem.h>


#define SHM_SIZE 30
using namespace std;

#if defined(__GNU_LIBRARY__) && !defined(_SEM_SEMUN_UNDEFINED)
                                         // definition in <sys/sem.h>
 #else
 union semun 
 {                          // We define:
	int val;                             // value  for SETVAL
	struct semid_ds *buf;                // buffer for IPC_STAT, IPC_SET
	unsigned short int *array;           // array  for GETALL, SETALL
	struct seminfo *__buf;               // buffer for IPC_INFO
};
#endif 

key_t key = 1010;
int semid ;


static struct sembuf acquire = {0, -1, 0}, release = {0,  1, 0};


int main( ) 
{
	int    shmid;
	char   c, *shm, *s;
	char *buffer;
    int Age;
    char FileName[20];
	int fie_size ,i;
	union semun	arg;
	FILE *fp_ip ;
	
	if ((semid = semget(key, 1, IPC_CREAT | 0666)) == -1)
	{
		cerr << "semget: IPC_CREAT | 0666" << endl;
	}
	
	if( (fp_ip = fopen ( "text2.txt" , "r+" )) == NULL )
	{
		perror("File creation failed :");
		return 5;
	}
	buffer = (char *)malloc(SHM_SIZE * sizeof(char));
	fread(buffer,1,SHM_SIZE, fp_ip);	
	cout << "\n Data from the file is : " << buffer;
    cout << "\n\n";


	if ((shmid=shmget(IPC_PRIVATE,SHM_SIZE,IPC_CREAT|0660))< 0) // creating a shared memory 
	{
		perror("shmget fail");
		return 1;
	}
	if ((shm = (char *)shmat(shmid, 0, 0)) == (char *) -1) // attching a process to shared memory 
	{
		perror("shmat : parent");
		return 2;
	}
	cout << "Addresses in parent"  << endl;
	cout << "shared mem: " << hex << int(shm) << endl;
	
	s = shm;                             // s now references shared mem
	arg.val = 0 ;
	if (semctl(semid, 0, SETVAL,arg) == -1) 
	{  
		perror("semctl-initialization");
		return 2;
	}
	
	semop(semid, &acquire, 0) ;   /*  Acquring semaphore for writing data to shared memory */
	
	memcpy(s,buffer,SHM_SIZE); // copying data to shared memory 
	
	semop(semid, &release, 0);   // Relesing semaphore after writting 
	
	cout << "In parent before fork, memory is: " << shm << endl;
	switch (fork( )) 
	{
		case -1:
			perror("fork");
			return 3;
		default:
			sleep(2);                          
			cout << "In parent after fork, memory is : " << shm << endl;
			semop(semid, &acquire, 0); 
			
			for ( i = 0 ; i < SHM_SIZE ; i++ )              // modify shared memory
				*(shm+i) += 5;
				
			semop(semid, &release, 0);
			wait(0);
			fseek ( fp_ip , 0 , SEEK_SET ); 				// writing back to the file 
			fwrite (shm , 1 , sizeof(SHM_SIZE) , fp_ip );
			fclose(fp_ip);
			cout << "\nParent removing shared memory" << endl;
			shmdt(shm);
			shmctl(shmid, IPC_RMID, (struct shmid_ds *) 0);
			break;
		case 0:
			cout<<"child part";
			semop(semid, &acquire, 0); 
			cout << "In child after fork, memory is  : " << shm << endl;
			semop(semid, &release, 0);
			sleep(5);
			semop(semid, &acquire, 0) ;
			cout << "In child after modifying data in parent, memory is  : " << shm << endl;
			semop(semid, &release, 0);
			
			shmdt(shm);
			break;
	}
return 0;
 }

// Copyright 2008 TOSHIBA TEC CORPORATION All rights reserved //

/**************************************************************************************************************************
 * $Workfile: boproxy.h$
 * $Revision: 1 $
 * $Date: 03/08/2006$
 * Author: Sankarshana M
 * 
 * Description: Defines BOProxy interface which acts as the proxy for the BO server.
 *****************************************************************************************************************************/
#ifndef __AL_UICONTROLLER_BOPROXY_H__
#define __AL_UICONTROLLER_BOPROXY_H__

#include "CI/OperatingEnvironment/ref.h"
#include "CI/OperatingEnvironment/interface.h"
#include "CI/OperatingEnvironment/moniker.h"
#include "CI/HierarchicalDB/DOM/node.h"
#include "CI/HierarchicalDB/DOM/element.h"
#include "status.h"
#include "msgdefs.h"
#include <map>

//Security Infrastructure's headers.
#include "CI/SI/ssdkusertokeninterface.h"
#include "CI/LogManager/loginterface.h"

// namespace
namespace al
{
namespace uicontroller
{

	enum eValueType
	{
		eValueTypeNone = 0,
		eLastSavedValue,
		eDefaultValue
	};
	enum eViewType{eTOPACCESS, eSTAGE2};

	enum eDOMType
	{
		eAutoSelectType,
		eSessionDOMType,
		eOriginalDOMType
	};

	struct stStatusAndValue
	{
		Status statusOfOperation;
		ci::operatingenvironment::CString valueOfDocument;
		stStatusAndValue()
		{
			statusOfOperation = STATUS_FAILED;
			valueOfDocument = "";
		}
	};

	class BOProxy;
	typedef ci::operatingenvironment::Ref<BOProxy> BOProxyRef;

	class BOProxy:public ci::operatingenvironment::Interface
	{
		public:
			virtual ~BOProxy()
			{
			}

			/**
			 * Send a command to BO server. This is the overloaded version of 
			 * the deprectaed ExecuteCommand. Clients should use this API.
			 * Panel should set the appropriate parameters(whereever applicable) in BO's
			 * repository before  sending a command.
			 * @Param: const char *xml Description of the command and related parameters in XML format.
			 * @Param: For a detailed description of the list of commands refer to BOCOMMANDS.XSD
			 * @Param: 
			 * @Param: [OUT] CString & sResponseXML. Response of the Command such as statusOfOperation,
			 * @Param: response details if any (return values) will be returned in this OUT parameter.
			 * @Param: User can also provide an XPath in this parameter.When an XPath is specified in sResponseXML,
			 * @Param: UIController,deserializes the Command response XML at this XPath instead of returning 
			 * @Param: it in sResponseXML.
			 * @Param: For a detailed description of the Command response XML, refer to bocommands.xsd
			 * @Param: or the Applications Command XSD.
			 * @Param: 
			 * @Param: [IN] Ref<SSDKUserTokenInterface> pUserToken
			 * @Param: User can send the token specified by this parameter to other plugin, if user set the token in this parameter.
			 * @Param: 
			 * @Return: status of operation. This is the command submission status ONLY.
			 * @Return: This does not represent the command execution status.
			 * @Return: Command Execution Status will be in the sResponseXML.
			 */
			virtual Status ExecuteCommand(const char *xml,ci::operatingenvironment::CString & sResponseXML,ci::operatingenvironment::Ref<ssdk::SSDKUserTokenInterface> pUserToken = NULL) = 0;

			/**
			 * Send a command to BO server asynchronously.
			 * 
			 * This API submits the command and returns immedietly without waiting for the command response.
			 * Command response will be sent to the port that is supplied as the second parameter of
			 * this API.
			 * @Param: const char *xml Description of the command and related parameters in XML format.
			 * @Param: For a detailed description of the list of commands refer to BOCOMMANDS.XSD
			 * @Param: 
			 * @Param: const MsgPortId portIDForCommandResponse 
			 * @Param: Response of the Command such as statusOfOperation,response details if any (return values) 
			 * @Param: will be sent to this message port.
			 * @Param: For a detailed description of the Command response XML, refer to bocommands.xsd
			 * @Param: or the Applications Command XSD.
			 * @Param: 
			 * @Param: [IN] Ref<SSDKUserTokenInterface> pUserToken
			 * @Param: User can send the token specified by this parameter to other plugin, if user set the token in this parameter.
			 * @Param: 
			 * @Return: status of operation. This is the command submission status ONLY.
			 * @Return: This does not represent the command execution status.
			 * @Return: Command Execution Status will be in the sResponseXML.
			 */
			virtual Status ExecuteCommandASynch(const char *xml,const MsgPortId portIDForCommandResponse,ci::operatingenvironment::Ref<ssdk::SSDKUserTokenInterface> pUserToken = NULL) = 0;
			virtual Status ExecuteCommandASynch(const char *xml,const MsgPortId portIDForCommandResponse,ci::operatingenvironment::CString& sUUID) = 0;
#if 0
			/**
			 * Lock a portion for exclusive access by the caller.
			 * The portion is determined based on the parameter passed to this function.
			 * This needs to be done before a user starts to edit values on the UI.
			 * @Param: const char *xml: An XML of the form shown below
			 * @Param: <Lock>
			 * @Param:  <path>path of the subtree</path>0..n
			 * @Param: </Lock> 
			 * 
			 * @Return: status of operation
			 */
			virtual Status Lock(const char *xml) = 0;

			/**
			 * Unlock a previously locked portion of the BO tree.
			 * The portion is determined based on the parameter passed to this function.
			 * @Param: const char *xml: An XML of the form shown below
			 * @Param: <Unlock>
			 * @Param:  <path>path of the subtree</path>0..n
			 * @Param: </Unlock> 
			 * 
			 * @Param: bool bRollBack. If this is set to FALSE, the values that are modified under this
			 * @Param: subtree will be restored back to original values. Default value for this parameter 
			 * @Param: is TRUE which means changes are preserved after unlock.
			 * @Return: status of operation
			 */
			virtual Status Unlock(const char *xml,bool bRollBack = false) = 0;
#endif
			/**
			 * Indicate to BO server to SET a new value in its repository. Note that
			 * this will not be committed to the device. To commit the value to the device,
			 * this call should be followed by the delivery of appropriate command.
			 * @Param: const char *xml: XML of this form containing the path and the value to be set.
			 * @Param: There are 2 ways to specify the XML .
			 * @Param: 1. <SetValue sendNotification="true/false"><Payload XMLPayLoad = "false" overrideDelta = "false"><path/><value/></Payload>[0..N]</SetValue>			 
			 * @Param: 2. <SetValue sendNotification="true/false"><Payload XMLPayLoad = "true" overrideDelta = "true">
			 * @Param:    <Payload><path>XPath under which the value needs to be SET (Deserialized)</path>
			 * @Param:    <value><Queues><Copy><PrintExecutionParams>
			 * @Param:    <duplex>1</duplex></PrintExecutionParams></Copy></Queues></value></Payload></SetValue>
			 * @Param: 
			 * @Param: overrideDelta flag,if set to true,means that the contents of the current delta document indicated by the root 
			 * @Param: node i,e "Queues" under the <path> node,should be discarded and the XML given as the payload should be DESERIALIZED 
			 * @Param: under the <path> node in Delta Document.
			 * @Param: The attribute "sendNotification" on SetValue node if set to true, means that notfication should be sent to
			 * @Param: subscribers after doing SetValue. If it's flase,notifications will not be sent to subscribers.
			 * @Param: This is true by default.
			 * @Return: status of operation
			 */
			virtual Status SetValue(const char *xml) = 0;

			//VIRESH ADD
			virtual Status GetDLParamsSHMID(ci::operatingenvironment::CString &szDLSHMID)=0;
			//VIRESH ADD

			/**
			 * Indicate to BO server to RESET the value of a particular node to its
			 * original value. 
			 * The enum value (second parameter ) determines the type of RESET to be done.
			 * If (eTypeOfValue == eLastSavedValue), values will be reset to the last saved value.
			 * This case happens when users change few values in a screen and decide to
			 * cancel those changes and return back. 
			 *
			 * If (eTypeOfValue == eDefaultValue),values will be reset to the Default value(as came during installation.)
			 *
			 * Panel can call this function by passing the XPath of the root node
			 * of the subtree or XPaths of individual leaf nodes.
			 * 
			 * If the Xpath of root node of a subtree is passed, then all the nodes under that will be reset.
			 * If the XPath of leaf node is passed, then only the value of that leaf node will be reset.
			 *
			 * @Param: const char *xml: XML of this form containing the path(s).
			 * @Param: eValueType eTypeOfValue:Type of RESET requested.
			 * @Param: <ResetValue><path/>1..N</ResetValue>
			 * @Return: status of operation
			 */
			virtual Status ResetValue(const char *xml,eValueType eTypeOfValue) = 0;

			/**
			 * Indicate to BO server to SAVE the value of a node to its ultimate destination.
			 * This case happens when users change few values in a screen and after changing these values, they
			 * hit the "ENTER" button for example. In this case, for every change in value, UI  calls SetValue,
			 * and finally when "ENTER" is pressed, SaveValue() can be called to commit these values to the device.
			 *
			 * In this case, panel, can call this function, by passing the XPath of the root node
			 * of the subtree or XPaths of individual leaf nodes.
			 * Note that there is no need to pass the actual value to this function. Values would have been
			 * passed already while calling SetValue(). This function only expects XPaths .
			 * 
			 * If the Xpath of root node of a subtree is passed, then values of all the nodes under that will be SAVED.
			 * If the XPath of leaf node is passed, then only the value of that leaf node will be SAVED.
			 *
			 * @Param: const char *xml: XML of this form containing the path(s).
			 * @Param: <SaveValue><path/>1..N</SaveValue>
			 * @Return: status of operation
			 */
			virtual Status SaveValue(const char *xml) = 0;

			/**
			 * Get the value of the node indicated by the xml from BO's  repository. 
			 * @Param: const char *pPath: Path from where data is to be read.
			 * The single value under this path will be returned.
			 *
			 * @Param: Ref<Node> &pNodeValueReturned.
			 * @Param: if pPath points to a leaf node of the document, pNodeValueReturned will be of type "dom::TextNodeRef".
			 * @Param: if pPath points to an ELEMENT node of the document, pNodeValueReturned will be of type "dom::ElementNodeRef".
			 * @Return: status of operation
			 */
			virtual Status GetValue(const char *pPath,ci::operatingenvironment::Ref<dom::Node> &pNodeValueReturned) = 0;
			virtual Status GetValue(const char *pPath,ci::operatingenvironment::CString &sNodeValueReturned) = 0;
			virtual Status GetValueForPanel(const char *pPath,ci::operatingenvironment::CString &sNodeValueReturned) = 0;

			/**
			 * Get values of the node(s) indicated by the parameter from BO's  repository.
			 *
			 * @Param: std::map<CString,Ref<Node> > &pMapOfPath2Node.
			 * @Param: The first element at each index of the map contains the path of the node which is to be retrieved.
			 * @Param: The second element will be filled by this function with the node representing that path.
			 * @Param: Callers can send NULL for the second element.
			 * @Return: status of operation
			 */
			virtual Status GetValues(std::map<ci::operatingenvironment::CString,ci::operatingenvironment::Ref<dom::Node> > & pMapOfPath2Node) = 0;

			/**
			 * Subscribe for notifications. Clients can subscribe for notifications
			 * on BO repository or session destruction. Clients can subscribe for notifications on any sub node of the repository.
			 * If subscription request is sent for an already subscribed path with same port No,
			 * the subscription ID of the currently existing subscription will be returned and the old context
			 * will be replaced with the new one.
			 * The subscription for BO repository needs to set <path>.  The subscription for session destruction needs to set <sessionID>.
			 *
			 * @Param: const char *pRequestXML. A Request XML of the following format.
			 * @Param: <?xml version="1.0" encoding="UTF-8"?>
			 * @Param: <Subscribe>
			 * @Param:		<Information model="push/pull">
			 * @Param:			<path>
			 * @Param:				Path to a subtree in BO repository.Notifications will be sent
			 * @Param:				when any of the values under this subtree is modified.
			 * @Param:			</path>
			 * @Param:			<sessionID>
			 * @Param:				Clients can give the sessionID of the session here. In this case, 
			 * @Param:				clients will be sent a Session-Destroy warning when this session 
			 * @Param:				is about to get Destroyed. This warning can be used by plugins or 
			 * @Param:				other clients to perform any cleanup activity or to clear some cached data 
			 * @Param:				specific to this session.
			 * @Param:				If "*" is supplied as the sessionID here,
			 * @Param:				then Session-Destruction Warning/Due/Done will be sent out to this port for all UIController sessions.
			 * @Param:              If bAutoDestroySession set to true (i.e. session destruction by boproxy ref count == 0), 
			 * @Param:              the notification message format will be <Notification type="sessionDestructionWarning">.
			 * @Param:              If bAutoDestroySession set to false (i.e. session destruction by session timer expiration),
			 * @Param:              two notification messages are sent - one for due and another for done.
			 * @Param:              The done notification message means that the session has been destroyed.
			 * @Param:              The notification due message format will be <Notification type="sessionDestructionDue">.
			 * @Param:              The notification done message format will be <Notification type="sessionDestructionDone">.
			 * @Param:			</sessionID>
			 * @Param:			<context>Any context information that should be returned along with notifications.
			 * @Param:				Clients can use this to supply some identifier while registering and when notification
			 * @Param:				Msg is delivered by BO, they can use the context for purposes of identification.
			 * @Param:			</context>
			 * @Param:			<portNo>Local Msg port number at which the NOTIFICATIONS should be sent</portNo>
			 * @Param:		</Information>0..N
			 * @Param: </Subscribe>
			 * @Param: If the attribute "model=push", modified value will be  sent as part of notification message
			 * @Param: If the attribute "model=pull", modified value will not be part of the notification message, instead,
			 * @Param: clients need to read the modified value from DIM(Device Information Model) Repository.
			 * @Param:
			 * @Param: CString sSubscriptionResponse: An XML of this form will be returned in this OUT Parameter.
			 * @Return: An XML of this form.
			 * @Param: <?xml version="1.0" encoding="UTF-8"?>
			 * @Param: <Subscribe>
			 * @Param:		<Information>
			 * @Param:			<path>
			 * @Param:				Path to a subtree in BO repository.Notifications will be sent
			 * @Param:				when any of the values under this subtree is modified.
			 * @Param:			</path>
			 * @Param:			<context>Any context information that should be returned along with notifications.
			 * @Param:				Clients can use this to supply some identifier while registering and when notification
			 * @Param:				Msg is delivered by BO, they can use the context for purposes of identification.
			 * @Param:			</context>
			 * @Param:			<portNo>Local Msg port number at which the NOTIFICATIONS should be sent</portNo>
			 * @Param:			<statusOfOperation>status of operation</statusOfOperation>
			 * @Param:			<subscriptionID>Unique subscription ID corresponding to this subscription.</subscriptionID> 
			 * @Param:		</Information>0..N
			 * @Param: </Subscribe>
			 *			 
			 * @Return: status of operation
			 */
			virtual Status Subscribe(const char *pRequestXML,ci::operatingenvironment::CString & sSubscriptionResponse) = 0;

			/**
			 * Unsubscribe previously subscribed notifications.
			 *
			 * @Param: const char *pRequestXML. A Request XML of the following format.
			 * @Param: <?xml version="1.0" encoding="UTF-8"?>
			 * @Param: <UnSubscribe>
			 * @Param:		<Information>
			 * @Param:			<path>
			 * @Param:				Path to a subtree in BO repository at which subscription request was made earlier.
			 * @Param:			</path>
			 * @Param:			<subscriptionID>Unique subscription ID got during Subcribe Operation.</subscriptionID>
			 * @Param:		</Information>0..N
			 * @Param: </UnSubscribe>
			 * @Param:
			 * @Param: CString sSubscriptionResponse: An XML of this form will be returned in this OUT Parameter.
			 * @Return: An XML of this form.
			 * @Param: <?xml version="1.0" encoding="UTF-8"?>
			 * @Param: <UnSubscribe>
			 * @Param:		<Information>
			 * @Param:			<path>
			 * @Param:				Path to a subtree in BO repository at which subscription request was made earlier.
			 * @Param:			</path>
			 * @Param:			<subscriptionID>Unique subscription ID got during Subcribe Operation.</subscriptionID> 
			 * @Param:			<statusOfOperation>status of Unsubscribe operation</statusOfOperation>
			 * @Param:		</Information>0..N
			 * @Param: </UnSubscribe>
			 * @Return: status of operation
			 */
			virtual Status UnSubscribe(const char *pRequestXML,ci::operatingenvironment::CString & sUnSubscriptionResponse) = 0;

			/**
			 * Generate Notification to registered Clients thro' BOSERVER.
			 * This API can be used to generate Notifications in cases, where a number of nodes
			 * have been modified and instead of sending notification on all such nodes,
			 * a single notification can be sent on the root node of such nodes to indicate that
			 * everything under the root node has changed.
			 *
			 * @Param: const char *xml: XML of this form containing the path(s) on which notification should be sent.
			 * @Param: <GenerateNotification><path/>1..N</GenerateNotification>
			 * @Return: status of operation
			 */
			virtual Status GenerateNotification(const char *xml, const bool bSynchronous = true) = 0;


			/**
			 * Acquire an instance of BOProxy.
			 * Using this API,Clients can create a new UIController's session or 
			 * ATTACH to an existing UIController's session.
			 * @Param: CString &sSessionID -- Session ID of the UIcontroller.
			 * @Param: If this is supplied as "", UIController creates a new session.
			 * @Param: If sSession ID is not "", UIController tries to create a new session
			 * @Param  with this session ID. If there is already a session with this ID, then
			 * @Param: UIController attaches this client to the existing session.
			 * @Param: If there is no Session with the supplied Session ID, then a new session will be created.
			 * @Param: Returns either the supplied session ID or the newly created Session ID 
			 * @Param: in the [OUT] Parameter "sSessionID".
			 * @Param:
			 * @Param: bool bAutoDestroySession -- If this is true, session will be destroyed when this 
			 * @param: instance of BOProxy goes out of reference.
			 * @Param: If this is false, session will NOT BE destroyed automatically. Instead,
			 * @Param: clients need to call BOProxy->Destroy() to destroy this session.
			 * @Param:
			 * @Param: int32 iExpirationThreshold in seconds: If bAutoDestroySession is false, then this parameter
			 * @Param: indicates the maximum duration of session inactivity after which the BOServer 
			 * @Param: can destroy this session. This parameter is to take care of cases where clients have marked 
			 * @Param: bAutoDestroySession false and forgot to call Destroy() later. In this case, BOServer automatically
			 * @Param: destroys the session if there was no activity on the session for the interval iExpirationThreshold.
			 * @Param: iExpirationThreshold will be renewed once some activity happens on this session. 
			 * @Param: 
			 * @Param: iExpirationThreshold = -1 indicates that BOServer should never destroy this session even if the session is
			 * @Param: inactive for infinite interval of time. Clients should not use this option unless absolutely necessary.
			 * @Param: 
			 * @Param: Default value for iExpirationThreshold is (2 * 24 * 60 * 60).
			 * @Param:
			 * @Return: BOProxyRef if successful or NULL in case of failure.
			 */
			static BOProxyRef Acquire(ci::operatingenvironment::CString & sSessionID,bool bAutoDestroySession = true,int32 iExpiresIn = 2 * 24 * 60 * 60);

			/**
			 * Destroy this session. This should be called to 
			 * explicitly destroy this session when bAutoDestroySession in Acquire is flagged false.
			 * @Param: None
			 * @Return: status of operation
			 */
			virtual Status Destroy() = 0;

			/**
			 * Get the value of the node indicated by the xml from BO's  repository. 
			 * @Param: const char *pPath: Path from where data is to be read.
			 * The single value under this path will be returned.
			 *
			 * @Param: 
			 * @Return: status of operation
			 */
			virtual Status GetValues(const char *sDocumentName) = 0;

			/**
			 * Set the values of the node indicated by the xml from BO's  repository. 
			 * @Param: const char *pPath: Path from where data is to be read.
			 * <SetValue><Network><Protocols>...</SetValue>
			 * @Return: status of operation
			 */
			virtual Status SetValues(const char *sSetXML) = 0;

			/**
			 * Get the Session ID string of this UIController Session.
			 * @Param: None
			 * @Return: Session ID
			 */
			virtual ci::operatingenvironment::CString getSessionID() const = 0;

			/**
			 * Get the Session Data Folder of this UIController Session.
			 * @Param: None
			 * @Return: Fully qualified path to Session Data Folder.
			 */
			virtual ci::operatingenvironment::CString getSessionDataStoragePath() const = 0;


			//Security related Note:
			/** When a user logs in (by sending a Login Command),the UserToken object is set on this session and 
			 * the session is flaged to be an Authenticated Session.
			 * This stores the token as part of this Session's Data and also creates a User specific Area
			 * for this logged-in User.
			 *
			 * When eBx system is running in SECURE mode, users (clients of BOProxy) may need to authenticate themselves
			 * before performing actions using BOProxy interface.
			 * In SECURE MODE,UIController will use this userToken to authorize if the requested operation can be performed
			 * by this user/client (identified by the session ID).
			 * For ex,if a client tries to submit a JOB,UIController uses the UserToken to check if this client
			 * has permissions to submit this kind of JOB.
			 *
			 * This userToken will be stored as part of Session information of this client of UIController.
			 * Due to this,clients of UIController need not set the user token multiple times.
			 * When a client reattaches to this session,the userToken that was previously set (if any was set) 
			 * will be retrieved from the SESSION data maintained by BOServer.

			 * Release a previously SET user token (Logoff).
			 * This LogOff Operation has the effect of destroying the Serialised Token and to delete the
			 * User Specific Data Area created during "LogIn".
			 * This happens when the user logs off because of which the authenticated UserToken becomes 
			 * invalid.
			 * Please note that clients can still keep the UIController session ALIVE even after
			 * "RELAEASING (Loggingoff)" the User Token.
			 */

			/**
			 * Get the UserToken object that was previously SET on this session.
			 * 
			 * @Param: [OUT] UserTokenInterfaceRef & pUserToken: User Token will be returned in this OUT Param.
			 * @Return: status of operation
			 */
			virtual Status GetUserToken(ci::operatingenvironment::Ref<ssdk::SSDKUserTokenInterface> & pUserToken) = 0;


			/**
			 * Get the UserToken that was previously SET on this session.
			 * User Token will be returned in Serialised form.
			 * @Param: [OUT] ci::operatingenvironment::CString & sUserToken: User Token will be returned in this OUT Param.
			 * @Return: status of operation
			 */
			virtual Status GetUserToken(ci::operatingenvironment::CString & sUserToken) = 0;

			/**
			 * Set the UserToken on this session.
			 * 
			 * @Param: [IN] UserTokenInterfaceRef pUserToken: User Token that user want to set for this session.
			 * @Return: status of operation
			 */
			virtual Status SetUserToken(ci::operatingenvironment::Ref<ssdk::SSDKUserTokenInterface> pUserToken) = 0;


			/**
			 * Set the UserToken on this session.
			 * 
			 * @Param: [IN] CI::OperatingEnvironment::CString & sUserToken: User Token that user want to set for this session.
			 * @Return: status of operation
			 */
			virtual Status SetUserToken(ci::operatingenvironment::CString & sUserToken) = 0;

			/**
			 * Given an Xpath (can be root node name alone), this function returns the
			 * HDB document monikers for original document and delta document corresponding 
			 * to this session of UIController.
			 * The returned monikers can be directly used on HDB APIs to open these documents.
			 * The literal name of the document can be got using GetResourceID() call on the Moniker Object.
			 * @Param: [IN] const ci::operatingenvironment::CString sXPath: XPath or name of the root node nto BORepository.
			 * @Param: [OUT] ci::operatingenvironment::MonikerRef & pOrgDocumentMoniker -- Moniker to 
			 *			     Original Document corresponding to sXPath.
			 * @Param: [OUT] ci::operatingenvironment::MonikerRef & pDeltaDocumentMoniker -- Moniker to 
			 *			     Delta Document corresponding to sXPath.
			 * @Return: status of operation
			 *
			 */
			virtual Status getDocumentMonikers(const ci::operatingenvironment::CString sXPath,
											  ci::operatingenvironment::MonikerRef & pOrgDocumentMoniker,
											  ci::operatingenvironment::MonikerRef & pDeltaDocumentMoniker) = 0;


			/**
			 * Renew timeout for UIC session timer with the new timer value.
			 * @Param: [IN] newTimerValue new timer value in seconds
			 * @return Status
			 * Note that the default value 0 for newTimerValue means to reset the timer with the original timer value.
			 */
			virtual Status Session_Timer_Reset(int32 newTimerValue = 0) = 0;  // reset by the new timer value

			/**
			 * Return the remaining time before session expiration (time to live).
			 * @param[out] timerTTL remaining timeout value in seconds
			 * @return Status
			 */
			virtual Status Session_Timer_TTL(int32 &timerTTL) = 0;

			/**
			 * Check whether the session exists or not.
			 * Note that it cannot check whether the session is timed out or never existed.
			 * @param[in] sessionID UIC session ID to check
			 * @param[out] bSessionExist session exists if true
			 * @return Status
			 */
			virtual Status Session_SessionExist(const ci::operatingenvironment::CString sessionID, bool &bSessionExist) = 0;

			/**
			 * Stop timer for UIC session
			 * Note that Session_Timer_Restart() must be called , if timer is restarted.
			 * @return Status
			 */
			virtual Status Session_Timer_Stop() = 0;

			/**
			 * Restart stopped timer for UIC session
			 * Note that it is used when timer is stopped with Session_Timer_Stop().
			 * @return Status
			 */
			virtual Status Session_Timer_Restart() = 0;

			/**
			 * Backup the session data
			 * Note that old backup data is deleted, if it has backed up the data already.
			 * @return Status
			 */
			virtual Status Session_Data_Backup() = 0;

			/**
			 * Remove current session data and restore the session data
			 * Note that user must call Session_Data_Backup(), before the data is restored.
			 * @return Status
			 */
			virtual Status Session_Data_Restore() = 0;

			/**
			 * Remove current session data
			 * @return Status
			 */
			virtual Status Session_Data_Clear() = 0;


			/**
			 * Get Application typefor MessageLog or JobLog
			 * @return OperationApplicationType
			 */
			virtual ci::logmanager::LogInterface::OperationApplicationType GetApplicationType() const=0;

			/**
			 * Get Application information(Type, IP Address) for MessageLog or JobLog
			 * @param[out] type Application type
			 * @param[out] sIPAddress IP Address of Application
			 * @return Status
			 */
			virtual Status GetApplicationInformation(ci::logmanager::LogInterface::OperationApplicationType& type, ci::operatingenvironment::CString& sIPAddress) const=0;
			/**
			 * Set Application information(Type, IP Address) for MessageLog or JobLog
			 * @param[in] type Application type
			 * @param[in] sIPAddress IP Address of Application
			 * @return Status
			 */
			virtual Status SetApplicationInformation(const ci::logmanager::LogInterface::OperationApplicationType type, const ci::operatingenvironment::CString sIPAddress) =0;

			virtual bool IsViewSessionExist(const eViewType eTypeOfView) const=0;

			/**
			 * Get values of the node(s) indicated by the key of map.
			 *
			 * @Param: std::map<CString,stStatusAndValue> &pMapOfPath2Value.
			 * @Param: The first element at each index of the map contains the path of the node.
			 * @Param: The second element will be filled by this function with the status and value representing that path.
			 * @Param: Callers can send initialized object for the second element.
			 * @Param: Status in stStatusAndValue will be STATUS_NG if represented path is none, is node which has no value, or getting value is failed.
			 * @Return: status of operation STATUS_OK, STATUS_FAILED or STATUS_INCOMPLETE_DOCUMENT (if partial success, return STATUS_INCOMPLETE_DOCUMENT).
			 */
			virtual Status GetValuesByMap(std::map<ci::operatingenvironment::CString,stStatusAndValue>& pMapOfPath2Value) = 0;

			/**
			 * Get values of the node(s) recursively indicated by argument.
			 *
			 * @Param: [in]ci::operatingenvironment::CString & rootPath
			 * @Param: XPath of root node where to start to search.
			 * @Param:
			 * @Param: Note: if the XPath is root node, attributes of root node will be omitted.
			 * @Param:
			 * @Param: Note: if there are multiple elements which are hit the XPath, function will search only first element.
			 * @Param: ex) XPath "sample/test" for following XML, searched only "sample/test[@id=1]".
			 * @Param:     If required to search all <test> elements, use XPath "sample" (the result includes <other> element).
			 * @Param: <sample>
			 * @Param:   <test id="1">...</test>
			 * @Param:   <test id="2">...</test>
			 * @Param:   <test id="3">...</test>
			 * @Param:   <other>...</other>
			 * @Param: </sample>
			 * @Param:
			 * @Param: [out]std::map<CString,std::vector<CString> > &pMapOfPath2Values
			 * @Param: The first element at each index of the map contains the path of the node.
			 * @Param: The second element at each value of the map contains value(s) of the path.
			 * @Param: Callers can send initialized object or not for the second argument.
			 * @Param: This function does not clear second argument (only add element(s)).
			 * @Param: [in]eDOMType
			 * @Param: Only session DOM, original DOM or auto select(session DOM first if auto select)
			 * @Return: status of operation STATUS_OK, STATUS_FAILED (if partial success, also return STATUS_FAILED).
			 */
			virtual Status GetValuesRecursively(const ci::operatingenvironment::CString & rootPath,std::map<ci::operatingenvironment::CString,std::vector<ci::operatingenvironment::CString> > & pMapOfPath2Values, eDOMType type) = 0;

			/**
			 * Impersonate to the anonymous token.
			 * Thereby, GetUserToken function comes to return the anonymous token.
			 * If it has already impersonated to anonymous token, this function returns STATUS_OK without doing anything.
			 * @return Status
			 */
			virtual Status ImpersonateToAnonymousToken() = 0;

			/**
			 * Undo a impersonation.
			 * Thereby, GetUserToken function comes to return the original token.
			 * If it has not impersonated token, this function returns STATUS_OK without doing anything.
			 * @return Status
			 */
			virtual Status UndoImpersonation() = 0;


#if 0
			/* The followin Interfaces is for PluginManager */
			virtual Status Register(const char* xml) = 0;

			virtual Status Unregister(const char* xml) = 0;

			virtual Status GetCommandSequence(const char* xml, ci::operatingenvironment::CString& sResponseString) = 0;

			virtual Status SetCommandSequence(const char* xml) = 0;

			virtual Status GetScreen(int iScreenID, ci::operatingenvironment::CString sLocale, ci::operatingenvironment::CString& sResponseString) = 0;

			virtual Status GetEventHandler(int iWidgetID, ci::operatingenvironment::CString sEventName, ci::operatingenvironment::CString& sResponseString) = 0;
#endif
	};//end of class


// namespaces
}; //namespace BO
}; //namespace AL

#endif //__AL_UICONTROLLER_BOCONTRACTS_H__

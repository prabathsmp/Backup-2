#include<iostream.h>
class CA
{
  public:
      int x;
      CA()
      {
          x=100;
      }
};

class CB:virtual public CA
{
public:
    int y;
    CB()
    {
        y=200;
    }
};

class CC:virtual public CA
{
public:
    int z;
    CC()
    {
        z=300;
    }
};

class CD:public CB,public CC
{
public:
    int a;
    CD()
    {
        a=400;
    }
};

void main()
{
   // cout<<endl<<sizeof(CD)<<endl;
    CD obj;
    long * vp=(long*)&obj;
    long * off=(long*)*vp;
    cout<<endl<<"\t\t"<<off[1]<<endl;
    vp++;
    cout<<endl<<*vp<<endl;
    vp++;
    off=(long*)*vp;
    cout<<endl<<"\t\t"<<off[1]<<endl;
    vp++;
    cout<<endl<<*vp<<endl;
    vp++;
    cout<<endl<<*vp<<endl;
    vp++;
    cout<<endl<<*vp<<endl;
}

#include<iostream.h>

void libFun(int x)
{
    cout<<endl<<"hi i will work"<<endl;
    try
    {
        if(x==10)
            throw 1000;
        else if(x==20)
            throw 3.14f;
        else if(x==30)
            throw "sachin";
    }
    catch(int i)
    {
         cout<<endl<<"integer exception ...libFun"<<endl;
    }

    cout<<endl<<"hi i wont work if exception is thrown "<<endl;
}

void main()
{
    try
    {
        libFun(30);
    }
    catch(int i)
    {
        cout<<endl<<"integer exception ...main"<<endl;
    }
    catch(float f)
    {
        cout<<endl<<"Float exception ...main"<<endl;
    }
    catch(...)
    {
        cout<<endl<<"General Exception Caught ...main"<<endl;
    }
    cout<<endl<<"I will work from main .."<<endl;
}
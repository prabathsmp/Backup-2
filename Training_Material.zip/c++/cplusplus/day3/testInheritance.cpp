#include<iostream.h>

class Base
{
public:

    Base()
    {
    }
  virtual  void fun1()
    {
        cout<<endl<<"fun1 Base "<<endl;
    }
   virtual void fun2()
    {
        cout<<endl<<"fun2 Base "<<endl;
    }
};

class CA:public Base
{
public:
    CA()
    {
    }
    void fun11()
    {
        cout<<endl<<"fun1 CA "<<endl;
    }
    void fun2()
    {
        cout<<endl<<"fun2 CA"<<endl;
    }
};

class CB:public Base
{
public:
    CB()
    {

    }
    void fun1()
    {
        cout<<endl<<"fun1 CB "<<endl;
    }
    void fun2()
    {
        cout<<endl<<"fun2 CB"<<endl;
    }
};

void do_Work(Base *ptr)
{
    cout<<endl<<"task 111 done ..."<<endl;
    ptr->fun1();//vptr->vtable[0]();
    ptr->fun2();//vptr->vtable[1]();
    cout<<endl<<"task 222 done ..."<<endl;
}

void main()
{
    CB *ptrCB=new CB();
    ptrCB->Base::Base();
    do_Work(ptrCB);
    /*CA *ptrCA=new CA();
    do_Work(ptrCA);*/
}













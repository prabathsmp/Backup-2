#include<iostream.h>
#include<typeinfo.h>
template<typename type=char *> 
class CA
{
    type i;
    type j;
public:
    CA()
    {
        cout<<endl<<"CA constructed ..."<<typeid(type).name()<<endl;
    }
    void fun()
    {
        cout<<endl<<"CA fun called ...."<<typeid(type).name()<<endl;
    }
    void funX();
    ~CA()
    {
     //   cout<<endl<<"CA Des-structed ..."<<typeid(type).name()<<endl;
    }
};
template<class T>
void CA<T>::funX()
{
    cout<<endl<<"CA funXcalled ...."<<typeid(type).name()<<endl;
}

template<>
class CA<int>
{
    int i;
    int j;
public:
    CA()
    {
        cout<<endl<<"CA constructed ...Specialized for integer"<<endl;
    }
    void fun()
    {
        cout<<endl<<"CA fun called ....Specialized for integer"<<endl;
    }
    void funX();
    ~CA()
    {
        cout<<endl<<"CA Des-structed ...Specialized for integer"<<endl;
    }
};
template<>
void CA<int>::funX()
{
    cout<<endl<<"CA funXcalled ....Specialized for integer"<<endl;
}



void main()
{
    CA<int> obj;
    CA<> obj1;
    CA<double> obj2;
   
}
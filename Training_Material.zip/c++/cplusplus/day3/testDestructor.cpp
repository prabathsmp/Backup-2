#include<iostream.h>

class CA
{
public:
   virtual ~CA()
    {
        cout<<endl<<"CA Destructed ...."<<endl;
    }
};

class CB:public CA 
{
public:
    ~CB()
    {//setvptr
        cout<<endl<<"CB Destructed ...."<<endl;
    }//call base destructor
};

void main()
{
    CA *ptr=new CB();
    delete ptr;
}
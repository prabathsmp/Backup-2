#include<iostream.h>
#include<typeinfo.h>

//--------------LIBRARY----------
template<typename type>
void fun(type x)
{
    cout<<endl<<"Hi : fun generated for "<<typeid(x).name()<<endl;
}

//--------------End of LIBRARY----------
/*
template<>
void fun<>(int y)
{
       cout<<endl<<"Hi : fun specialized for integer"<<endl;
}
*/
void fun(int y)
{
       cout<<endl<<"Hi : fun specialized for integer"<<endl;
}

void main()
{
    fun(10);
    fun(3.14f);
    fun(45.78);
    fun("sachin");
    fun(3.14f);
}
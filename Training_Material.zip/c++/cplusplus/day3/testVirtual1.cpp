#include<iostream.h>

class CA
{
public:
    virtual void fun1()
    {
        cout<<endl<<"fun 111 CA called ..."<<endl;
    }
    virtual void fun2()
    {
        cout<<endl<<"fun 222 CA called ..."<<endl;
    }
};
class CB:public CA
{
public:
    void fun2()
    {
        cout<<endl<<"fun 222 CB called ..."<<endl;
    }
    virtual void fun3()
    {
        cout<<endl<<"fun 333 CB called ..."<<endl;
    }
};

void main()
{
    CB *pt=new CB();
    ((void (*)())*( (long*)*( (long*)(pt) )+0 ))();
    ((void (*)())*( (long*)*( (long*)(pt) )+1 ))();
    ((void (*)())*( (long*)*( (long*)(pt) )+2 ))();
}

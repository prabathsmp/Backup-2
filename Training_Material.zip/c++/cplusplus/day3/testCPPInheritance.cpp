#include<iostream.h>

class CBase
{
public:
    void funBase()
    {
        cout<<endl<<"funBase Called ..."<<endl;
    }
    void funDerived()
    {
        cout<<endl<<"funDerived from Base Called ..."<<endl;
    }
};
class CDerived :public CBase
{
public:
    void funDerived()
    {
        cout<<endl<<"funDerived from Derived Called ..."<<endl;
    }
    void fun()
    {
        cout<<endl<<"fun CDerived "<<endl;
    }
};

CBase * create_Obj()
{
        return new CDerived();
}
//-------------------------------------------------
void main()
{
    CBase *ptr =create_Obj();   
    ptr->funBase();
    ptr->funDerived(); 
}
#include<iostream.h>




class CA
{
public:
    virtual void fun()
    {
        cout<<endl<<"fun CA called ..."<<endl;
    }
    virtual void funX()=0;//pure virtual function
};

class CB:public CA
{
public:
    void fun()
    {
        cout<<endl<<"fun CB called ..."<<endl;
    }
    void funX()
    {
        cout<<endl<<"funX called from CB ..."<<endl;
    }
};

void main()
{
    CA *ptr=new CB();
    ptr->fun(); 
    ptr->funX(); 
}
#include<iostream.h>

int k=1000;
void main()
{
    int k=100;
    cout<<endl<<"k="<<::k<<endl;
    
}

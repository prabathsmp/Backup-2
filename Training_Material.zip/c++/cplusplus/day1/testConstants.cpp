#include<iostream.h>

class CA
{
    const int c;
public:
    CA(int x):c(x)
    {
    }
    void disp()
    {
        cout<<endl<<"Disp c="<<c<<endl;
    }
};

void main()
{
    CA obj(90);
    
    obj.disp();
    obj.CA::CA(9000);//constructor call
    obj.disp();
}
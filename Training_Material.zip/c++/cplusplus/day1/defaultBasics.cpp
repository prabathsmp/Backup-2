#include<iostream.h>
/*
void DFun(int,int,int,int=1000);//declaration
void DFun(int,int,int=2000,int);//declaration
void DFun(int,int=3000,int,int);//declaration
void DFun(int=4000,int,int,int);//declaration
*/
void DFun(int a=10,int b=20,int c=30,int d=40)//definition
{
    cout<<endl<<"a="<<a<<endl;
    cout<<endl<<"b="<<b<<endl;
    cout<<endl<<"c="<<c<<endl;
    cout<<endl<<"d="<<d<<endl;
}

void main()
{
    DFun();    
}

#include<iostream.h>

class CA
{
    int x;
    mutable int y;
public:
    CA(int i):y(i),x(i)//initialization        //inline function
    {
        //x=10;//assignments
        //y=20;
        cout<<endl<<"Resource Alloted "<<endl;
    }
    void disp_Data();
    void myDisplay() const
    {
        cout<<endl<<"From My Display "<<endl;
        cout<<endl<<"x="<<x<<endl;
        y++;
        cout<<endl<<"y="<<y<<endl;
    }
    ~CA()//destructor
    {
        cout<<endl<<"Resource De-Alloted "<<endl;
    }
};

void CA::disp_Data()//non inline 
{
     cout<<endl<<"x="<<x<<endl;
     cout<<endl<<"y="<<y<<endl;
}
    

void main()
{
    const CA obj(1000);
    obj.myDisplay();
}












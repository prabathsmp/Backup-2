#include<iostream.h>

class CA
{
public:
   virtual void fun()
    {
        cout<<endl<<"fun called "<<endl;
    }
};


void main()
{
    //cout<<endl<<sizeof(CA)<<endl;
     CA obj;
     /*long* vptr=(long*)&obj;
     long* vtable=(long*)*vptr;
     typedef void (__stdcall *FPTR)();
     FPTR fp=(FPTR)vtable[0];
     fp();   
     */
            ((void (__stdcall *)())*(long*)*(long*)&obj)();

}
#include<iostream.h>
void fun(int x)
{
    cout<<endl<<"Fun for integer called "<<endl;
}
void fun(float x)
{
    cout<<endl<<"Fun for float called "<<endl;
}
void fun(double x)
{
    cout<<endl<<"Fun for double called "<<endl;
}

void  main()
{
    fun(10);
    fun(3.14f);
    fun(678.88);
}
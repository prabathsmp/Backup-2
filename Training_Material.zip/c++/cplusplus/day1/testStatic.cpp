#include<iostream.h>
class CA
{
    
    
public:
    int h;
    static int s;
    CA():h(10){}
    static void statFun()
    {
        cout<<endl<<"s="<<s<<endl;
    }
    void disp()
    {
           cout<<endl<<"s="<<s<<endl;
           cout<<endl<<"h="<<h<<endl;
    }
};
int CA::s=100;
void main()
{
    CA obj;
    obj.disp();
    obj.statFun();
    CA::statFun(); 
    cout<<endl<<"s="<<CA::s<<endl;
    cout<<endl<<"s="<<obj.s<<endl;
    cout<<endl<<"h="<<obj.h<<endl;
}

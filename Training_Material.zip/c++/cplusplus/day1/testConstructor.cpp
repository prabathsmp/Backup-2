#include<iostream.h>

class CA
{
    int x;
    const int c;
public:
    CA():x(10),c(10)
    {
        cout<<endl<<"CA Default constructor ..."<<endl;
    }
    explicit  CA(int i):x(i),c(30)
    {
        cout<<endl<<"CA one param constructor ..."<<endl;
    }
    CA(int x,int j):c(90)
   {
         this->x=x; 
         cout<<endl<<"CA parameterized constructor ..."<<endl;
    }
    CA(CA& o):c(80)
   {
         x=o.x;
         cout<<endl<<"CA Copy constructor ..."<<endl;
   }
};

void main()
{
    CA obj(100,200);
    //CA obj1=200;
    //obj1=500;
    CA obj1(obj);
}










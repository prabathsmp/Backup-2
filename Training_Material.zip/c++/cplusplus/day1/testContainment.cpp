#include<iostream.h>

class CA
{
public:
    CA()
    {
        cout<<endl<<"CA Constructor called ..."<<endl;
    }
    ~CA()
    {
        cout<<endl<<"CA Destructor called ..."<<endl;
    }
};

class CB
{
CA ob;
public:
    CB()
    {
        cout<<endl<<"CB Constructor called ..."<<endl;
    }
    ~CB()
    {
        cout<<endl<<"CB Destructor called ..."<<endl;
    }
};
void main()
{
    CB obj;
}
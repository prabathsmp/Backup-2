#include<iostream.h>

int i=10;
int * getI()
{
    return &i;
}
int & getICPP()
{
        return i;
}

void main()
{
/*int x=10;//1
int *ptr=&x;//2
*ptr=100;//3
*/
    /*
    int x=10;//1
    int & ptr=x;//2
    ptr=100;//3
    */
    //*getI()=1000;
    int & u=getICPP();
    u=2222;
    //*getI()=1000;
    //(*(&i))=9000;
    cout<<endl<<"i="<<i<<endl;
}

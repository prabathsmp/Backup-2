


#include<iostream.h>


void main()
{
    int i=10;
    int j=20;
    //-------------------
    //const int *ptr=&i;
    //const *int ptr=&i;
    //int const * ptr=&i;
    //------------------
    //int  * const ptr=&i;
    int const * const ptr=&i;

    //ptr=&j;
    //*ptr=670;
    cout<<endl<<"i="<<i<<endl;
    cout<<endl<<"j="<<j<<endl;
    cout<<endl<<"*ptr="<<*ptr<<endl;
}
#include<iostream.h>
class Single;
class Double
{
   
public:
     int d;
    Double()
    {
        d=0;
    }
    Double(int x):d(x)
    {
    }
    void Disp()
    {
        cout<<endl<<"d="<<d<<endl;
    }
    Double & operator=(Single&);
};

class Single
{
   
public:
     int i;
    Single()
    {
        i=0;
    }
    Single(int j)
    {
        i=j;
    }
    void Disp()
    {
        cout<<endl<<"i="<<i<<endl;
    }
    Single & operator=(Double & m_Right);
    
};
Double & Double::operator=(Single& m_Right)
 {
        this->d=m_Right.i*2; 
        return *this;
 }

Single & Single::operator=(Double & m_Right)
{
        this->i=m_Right.d/2;        
        return *this;
}

void main()
{
    Double objd(20);
    Single objs(15);
    objd=objs;
    objs=objd;
    objd.Disp();
    objs.Disp(); 
}
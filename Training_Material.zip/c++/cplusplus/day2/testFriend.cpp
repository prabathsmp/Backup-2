#include<iostream.h>

class CA;
class CB
{
public:
    void dispX(CA & obj);
    void fun1()
    {
    }
    void fun2()
    {
    }
    void fun3()
    {
    }
};

class CA
{
    int x;
public:
    CA()
    {
        x=10;
    }
    void Disp()
    {
        cout<<endl<<"x="<<x<<endl;
    }
    friend void CB::dispX(CA&); 
    friend class CC;
};
void CB::dispX(CA & obj)
    {
          obj.x=100;   
    }


class CC
{
public:
    void fx1(CA & m)
    {
        m.x=1000; 
    }
    void fx2(CA & m)
    {
        m.x=1001; 
    }
    void fx3(CA & m)
    {
        m.x=1002; 
    }
};

void main()
{
    CA objCA;
    CB objCB;
    objCB.dispX(objCA);
    objCA.Disp(); 
    
}



#include<iostream.h>


class CA
{
public:
    void fun1(int x)
    {
        cout<<endl<<"fun one param called "<<endl;
    }
    void fun1(int x,int y)
    {
        cout<<endl<<"fun two param called "<<endl;
    }
    void doFun()
    {
        cout<<endl<<"doFun Called from CA"<<endl;
    }
};

class CB:public CA
{
public:
    /*void fun1(int x)
    {
        CA::fun1(x); 
    }
    void fun1(int x,int y)
    {
        CA::fun1(x,y); 
    }
    */
    //using
    using CA::fun1; 
    void fun1(int x,int y,int z)
    {
         cout<<endl<<"fun three param called "<<endl;
    }
    void doFun()
    {
        cout<<endl<<"doFun Called from CB"<<endl;
    }
};

void main()
{
   CB obj;
   obj.fun1(10);
   obj.fun1(10,20);
   obj.fun1(10,20,30);
   obj.doFun(); 
}
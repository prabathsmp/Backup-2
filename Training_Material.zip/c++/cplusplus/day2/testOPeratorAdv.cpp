#include<iostream.h>


class CA;

typedef void (CA::*FPTR)();

void do_Job(CA & ob,FPTR fp)//void (*fp)()
{
    cout<<endl<<"task 111 done "<<endl;
    (ob.*fp)();//call back
    cout<<endl<<"task 222 done "<<endl;
}

void do_Job(CA * ob,FPTR fp)//void (*fp)()
{
    cout<<endl<<"task 111 done "<<endl;
    //((*ob).*fp)();//call back
    (ob->*fp)();
    cout<<endl<<"task 222 done "<<endl;
}


//-------------------------------
class CA
{
    int i;
    int j;
public:
        CA(int x,int y)
        {
            i=x;
            j=y;
        }
        void fun1()
        {
            cout<<endl<<"fun111"<<endl;
            cout<<endl<<"i="<<i<<endl;
            cout<<endl<<"j="<<j<<endl;
        }
        void fun2()
        {
            cout<<endl<<"fun222"<<endl;
            cout<<endl<<"i="<<i<<endl;
            cout<<endl<<"j="<<j<<endl;
        }
        void fun3()
        {
            cout<<endl<<"fun333"<<endl;
            cout<<endl<<"i="<<i<<endl;
            cout<<endl<<"j="<<j<<endl;
        }
        void fun4()
        {
            cout<<endl<<"fun444"<<endl;
            cout<<endl<<"i="<<i<<endl;
            cout<<endl<<"j="<<j<<endl;
        }
};

void main()
{
    CA obj1(100,200);
    CA obj2(400,500);
    CA obj3(600,700);
    do_Job(&obj2,CA::fun4);
}



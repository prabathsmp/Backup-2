#include<iostream.h>




class CA
{
    int x;
public:
    CA():x(10)    {    }
    operator int()    {        return x;    }
    operator float()    {        return 3.14f;    }
    operator void*()    {        return NULL;    }
};

void main()
{
    CA obj;
    int x=obj;
    float f=obj;
    void *p=obj;
}
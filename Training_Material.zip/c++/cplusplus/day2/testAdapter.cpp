#include<iostream.h>
class CA
{
public:
    CA()
    {
        cout<<endl<<"CA constructed ..."<<endl;
    }
    void Fun1()
    {
        cout<<endl<<"Fun 111"<<endl;
    }
    void Fun2()
    {
        cout<<endl<<"Fun 222"<<endl;
    }
    void Fun3()
    {
        cout<<endl<<"Fun 333"<<endl;
    }
    ~CA()
    {
        cout<<endl<<"CA Des-tructed ..."<<endl;
    }
};

class Wrapper
{
    CA *pt;
public:
    Wrapper():pt(new CA())
    {
    }
    /*void Fun1()
    {
        pt->Fun1();
    }
    void Fun2()
    {
        pt->Fun2();
    }
    void Fun3()
    {
        pt->Fun3();
    }
    */
    CA * operator->()
    {
        return pt;
    }
    ~Wrapper()
    {
        delete pt;
    }
};
void main()
{
    Wrapper w1;
 /* w1.Fun1();
    w1.Fun2();
    w1.Fun3();
 */
    w1->Fun1();     //w1.operator->()->Fun1();
    w1->Fun2();    //w1.operator->()->Fun2();
    w1->Fun3();   //w1.operator->()->Fun3();
}
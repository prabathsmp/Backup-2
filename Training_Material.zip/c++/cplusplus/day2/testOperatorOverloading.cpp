#include<iostream.h>

class Complex
{
int real;
int imag;
public:
    Complex():real(0),imag(0)
    {
    }
    Complex(int r,int i):real(r),imag(i)
    {
    }
    Complex operator+(Complex & m_Right)
    {
        return Complex(this->real+m_Right.real,imag+m_Right.imag);
    }
    Complex & operator=(Complex & m_Right)
    {
        this->real=m_Right.real;
        this->imag=m_Right.imag;
        return *this;
    }
    void operator++(int)
    {
        imag++;
    }
    void operator++()
    {
        real++;
    }
    operator int()
    {
         return real;
    }
    Complex operator+(int x)
    {
        return Complex(real,imag+x); 
    }
    friend  Complex operator+(int x,Complex & m_Right)
    {
        return Complex(m_Right.real+x,m_Right.imag); 
    }
    friend ostream & operator<<(ostream &,Complex &);
};

ostream & operator<<(ostream & os,Complex & m_Right)
{
    os<<endl<<m_Right.real<<(m_Right.imag>=0?"+":"")<<m_Right.imag<<"i"<<endl; 
    return os;
}

void main()
{
    Complex c1(100,20);
    Complex c2(10,-40);
    Complex c3=c1+c2;        //Complex c3=c1.operator+(c2);            
    cout<<c1;              //operator<<(cout,c1);
    cout<<c2;             //operator<<(cout,c2);
    cout<<endl<<"____________________"<<endl;
    cout<<c3;            //operator<<(cout,c3);
    c2=c3;              //c2.operator=(c3);
    c1++;              //c1.operator++(0);
    ++c1;              //c1.operator++();
    cout<<c1;          //operator<<(cout,c1);
    int result=c3;         //int result=c3.operator int();
    cout<<endl<<"result="<<result<<endl;
    c3=c1+10;
    c3=10+c2;
}

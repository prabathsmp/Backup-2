#include<iostream.h>
class Single;
class Double
{
   
public:
     int d;
    Double()
    {
        d=0;
    }
    Double(int x):d(x)
    {
    }
    void Disp()
    {
        cout<<endl<<"d="<<d<<endl;
    }
   operator Single();
};

class Single
{
   
public:
     int i;
    Single()
    {
        i=0;
    }
    Single(int j)
    {
        i=j;
    }
    void Disp()
    {
        cout<<endl<<"i="<<i<<endl;
    }
    operator Double();
    
};
    Double::operator Single() 
    {
        return Single(d/2);
    }

    Single::operator Double() 
    {
       return Double(i*2);
    }

void main()
{
    Double objd(20);
    Single objs(15);
    objd=objs;
    objs=objd;
    objd.Disp();
    objs.Disp(); 
}
#include<iostream.h>

class BaseClass
{
int i;
protected:
    int j;
public:
    int k;
    void BaseFun()
    {
        cout<<endl<<"BaseFun Called "<<endl;
    }
};

class DerivedClass:public BaseClass
{
public:
    void DerivedFun()
    {
        j=10;
        k=100;
        cout<<endl<<"DerivedFun  Called "<<endl;
    }
};

void main()
{
    DerivedClass obj;
    obj.k=700;
    obj.BaseFun();
    obj.DerivedFun(); 
}
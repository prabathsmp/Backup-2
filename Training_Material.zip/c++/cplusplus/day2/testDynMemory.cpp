#include<iostream.h>
class CB
{
int *ip;
public:
    CB():ip(new int(10))
    {
        cout<<endl<<"CB constructed ..."<<endl;
    }
    CB(CB& m_Right)
    {
            ip=new int(*m_Right.ip);
            cout<<endl<<"CB copied "<<endl;
    }
    ~CB()
    {
        cout<<endl<<"CB Des-structed ..."<<endl;
        delete ip;
    }
};

class CA
{
    CB *pt;
public:
    CA():pt(new CB())    {    }
    
    CA(CA & mm)    {        pt=new CB(*mm.pt);     }
    
    ~CA()    {       delete pt;    }
};

void main()
{
     CA obj1;
     CA obj2(obj1);
}
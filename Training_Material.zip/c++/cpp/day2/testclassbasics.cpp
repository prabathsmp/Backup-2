#include<iostream.h>
//#include<ostream.h>

class Complex
{
	int real;
	int imag;
public:
	Complex():real(0),imag(0)
	{
	}
	Complex(int r, int i):real(r),imag(i)
	{
	}
	Complex AddComplex(Complex & m_Right)
	{
		Complex temp;
		temp.real=this->real+m_Right.real;
		temp.imag=imag+m_Right.imag;
		return temp;
	}
	Complex & AssignComplex(Complex & m_Right)
	{
		this->real=m_Right.real;
		this->imag=m_Right.imag;
		return *this;
	}

	void post_increment()
	{
		imag++;
	}
	void pre_increment()
	{
		real++;
	}
	int CastToInteger()
	{
		return real;
	}
friend ostream & Display_Complex(ostream &,Complex &);
};

ostream& Display_Complex(ostream &os,Complex &m_Right)
{
	os<<endl<<m_Right.real<<(m_Right.imag>=0?"+":"")<<m_Right.imag<<"i"<<endl;
	return os;
}

void main()
{
	Complex c1(100,-20);
	Complex c2(10,-40);
	Complex c3=c1.AddComplex(c2);
	Display_Complex(cout,c1);
	Display_Complex(cout,c2);
	cout<<endl<<"......................"<<endl;
	Display_Complex(cout,c3);
	c2.AssignComplex(c3);
	Display_Complex(cout,c2);
	c1.post_increment();
	c1.pre_increment();
	Display_Complex(cout,c1);
	int result=c3.CastToInteger();
	cout<<endl<<"result="<<result<<endl;
}

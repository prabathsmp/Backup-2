#include<iostream.h>

class BaseClass
{
	int i;
protected:
	int j;
public:
	int k;
	void BaseFun()
	{
		cout<<endl<<"BaseFun called"<<endl;
	}
};

class DerivedClass:public BaseClass
{
	
public:
	void DerivedFun()
	{
		j=10;
		//k=20;
		cout<<endl<<"DerivedFun called"<<endl<<j<<endl<<endl;
	}
 
};

void main()
{
	DerivedClass obj;
	obj.BaseFun();
	obj.DerivedFun();
	obj.k=10;
	
}

#include<iostream.h>

class Single;

class Double
{
	
public:
	int d;	
	Double(int i):d(i)
	{
	}
	Double& operator=(Single &);
	void Display()
	{
		cout<<endl<<"d="<<d<<endl;
	}
//	operator Double(Single &);
};


class Single
{
	
public:
	int s;
	Single(int j):s(j)
	{
	}
	Single& operator=(Double &);
	void Display()
	{
		cout<<endl<<"s="<<s<<endl;
	}
//	operator Single(Double &);

};

//typedef Double& operator= operator;
//typedef Single& operator= 
//Double& Double::operator=(Single & m_Right)
Double & Double::operator=(Single & m_Right)
{
		this->d=m_Right.s*2;
		return *this;
}

Single & Single::operator=(Double & m_Right)
{
		this->s=m_Right.d/2;
		return *this;
}
	

void main()
{
	Double objd(10);
	Single objs(20);
	objd=objs;
	objs=objd;
	objd.Display();
	objs.Display();
	
}
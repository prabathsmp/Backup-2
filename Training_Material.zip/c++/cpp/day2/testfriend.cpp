#include<iostream.h>

class CA;
class CB
{
public:
	void CB::disp(CA &);
	//friend class CA::Disp();
};

class CA
{
	int x;
	CA()
	{
		x=0;
	}
	void Disp()
	{
		cout<<endl<<"x="<<x<<endl;
	}
	friend void CB::disp(CA &);
	friend class CC:
};

void CB::disp(CA & obj)
	{
	obj.x=100;
	}
	
class CC
{
public:
	void fx1(CA & m)
	{
		m.x=1001;
	}
};

void main()
{
	CA objCA;
	CB objCB;
	objCB.disp(objCA);
	objCA.Disp();
}
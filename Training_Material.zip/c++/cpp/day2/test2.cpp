#include<iostream.h>

class CA
{
	int x;
	int y;
public:
	CA()
	{
		//x=10;
		//y=20;
	cout<<endl<<"CA constructor called"<<endl;
	}
	void fun1()
	{
		cout<<endl<<"fun1 called"<<endl;
	}
	void fun2()
	{
		cout<<endl<<"fun2 called"<<endl;
	}
	void fun3()
	{
		cout<<endl<<"fun3 called"<<endl;
	}
	~CA()
	{
		cout<<endl<<"CA destructor called"<<endl;
	}
	
};

class wrapper
{
	CA *pt;
public:
	wrapper():pt(new CA())
	{
	}
/*void Fun1()
	{
		pt->fun1();
	}
	void Fun2()
	{
		pt->fun2();
	}
	void Fun3()
	{
		pt->fun3();
	}
*/
	CA * operator->()
	{
		return pt;
	}
	~wrapper()
	{
		delete pt;
	}
};
void main()
{
	wrapper w1;	
	//w1.operator->()->fun1();
	w1.operator->()->fun2();
	w1.operator->()->fun3();
	w1->fun1();
	//w1.Fun2();
	//w1.Fun3();

}
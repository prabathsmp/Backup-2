#include<iostream.h>

class CA
{
public:
	//int k;
	void fun()
	{
		cout<<"CA fun called"<<endl;
	}
	

};

class CB:public CA
{
private:
	int k;

	void fun()
	{
		cout<<"CB fun called"<<endl;
	}

};


/*class CC:public CA,CB
{
public:
	int k;

	fun()
	{
		cout<<"CB fun called"<<endl;
	}

};*/

void main()
{
	//CA obj1;
	CB obj;
	obj.CB::fun();
	
}
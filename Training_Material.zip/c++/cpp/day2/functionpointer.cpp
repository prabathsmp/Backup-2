#include<iostream.h>

class CA;
typedef void(CA::*FPTR)();

void do_Job(CA & ob,FPTR fp)
{
	cout<<"task 111 done"<<endl;
//	cout<<"task 222 done"<<endl;
	(ob.*fp)();
	cout<<"task 333 done"<<endl;
}


class CA
{
	int i; 
	int j;

public: 
    CA(int x, int y) 
	{
		i=x;
		j=y;
	}
void fun1()
{
	cout<<endl<<"fun111"<<endl;

}

void fun2()
{
cout<<endl<<"fun222"<<endl;
}

void fun3()
{
	cout<<endl<<"fun3"<<endl;
}
};

void main()
{

	CA obj1(100, 200);
	CA obj2(400, 500);
	CA obj3(600, 700);	
	do_Job(obj1,CA::fun3);
}


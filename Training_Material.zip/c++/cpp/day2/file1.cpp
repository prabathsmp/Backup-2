#include<iostream.h>

class CB
{
	int *ip;
public:
	CB():ip(new int(10))
	{
		cout<<endl<<"CB consturctor"<<endl;
	}
	CB(CB & m_Right)
	{
		//ip=new int(*m_Right.ip);
		ip=new int(*m_Right.ip);
	}
	~CB()
	{
		cout<<endl<<"CB destructor"<<endl;
		delete ip;
	}
};

class CA
{

	CB *pt;
public:
	CA():pt(new CB())
	{
		cout<<endl<<"CA constructor called"<<endl;
		//x=y=0;
	}

	CA(CA &mm)
	{
		pt=new CB(*mm.pt);
		cout<<endl<<"CA copy constructor called"<<endl;
	}
		
	void myfun()
	{
		cout<<endl<<"MyFun Called"<<endl;
	}

	~CA()
	{
	cout<<endl<<"CA destructor called"<<endl;
	delete pt;
	}

};


void main()
{
	CA obj1;
	CA obj2(obj1);
}

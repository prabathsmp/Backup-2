#include<iostream.h>

class CA
{
public:
	void fun1(int x)
	{
		cout<<endl<<"fun1 1 parameter called"<<endl;
	}
	void fun1(int x,int y)
	{
		cout<<endl<<"fun1 2 parameter called"<<endl;
	}
	void dofun()
	{
		cout<<endl<<"dofun called from CA"<<endl;
	}
};

class CB:public CA
{
public:
/*	void fun1(int x)
	{
		CA::fun1(x);
	}
	void fun1(int x,int y)
	{
		CA::fun1(x,y);
	}
*/
	using CA::fun1;	//vertical access control
		void fun1(int x,int y,int z)
	{
		cout<<endl<<"fun1 3 parameter called"<<endl;
	}
	void dofun()
	{
		cout<<endl<<"dofun called from CB"<<endl;
	}	

};

void main()
{
	CB obj;
	obj.fun1(1);
	obj.fun1(1,2);
	obj.fun1(1,2,3);
	obj.dofun();
}
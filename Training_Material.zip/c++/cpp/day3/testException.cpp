#include<iostream.h>

void libFun(int x)
{
	cout<<endl<<"hi i will work "<<endl;
	try
	{
	if(x==10)
		throw 1000;
	else if(x==20)
		throw 3.14f;
	else if(x==30)
		throw "sachin";
	}
	catch(int i)
	{
		cout<<endl<<"integer exception main"<<endl;
	}
	cout<<endl<<"hi i wont work if exception is thrown"<<endl;
}

void main()
{
	try
	{
		libFun(20);
	}
	catch(int i)
	{
		cout<<endl<<"integer exception"<<endl;
	}
	catch(float f)
	{
		cout<<endl<<"float exception"<<endl;
	}
	catch(...)//ellipse
	{
		cout<<endl<<"General exception"<<endl;
	}
	cout<<endl<<"hi i wont work from main"<<endl;

}
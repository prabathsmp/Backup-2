#include<iostream.h>

class CA
{
public:
	CA()
	{
		fun();
	}
	virtual void fun()
	{
		cout<<endl<<"Hello"<<endl;
	}
	~CA()
	{
		fun();
	}
};

class CB:public CA
{
public:
	CB()
	{
	}
		void fun()
	{
		cout<<endl<<"Hi"<<endl;
	}
	~CB()
	{
	}
};


void main()
{
/*	CB obj;//
	CA *ptr=&obj;
	pt->fun();
*/
	CB obj;//
	CA *pt=&obj;
	//pt->~CA();
	obj.CB::CB();
	pt->fun();

	
}
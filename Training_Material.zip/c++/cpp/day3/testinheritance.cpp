#include<iostream.h>

class Base
{
public:
		virtual void fun1()
		{
			cout<<endl<<"fun1 Base"<<endl;
		}	
		virtual void fun2()
		{
			cout<<endl<<"fun2 Base called"<<endl;
		}
		
};

class CA:public Base
{
public:
	void fun1()
	{
		cout<<endl<<"fun1 CA called"<<endl;
	}
	void fun2()
	{
		cout<<endl<<"fun2 CA"<<endl;
	}
};

class CB:public Base
{
public:
	void fun1()
	{
		cout<<endl<<"fun1 CB called"<<endl;
	}
	void fun2()
	{
		cout<<endl<<"fun2 CB"<<endl;
	}
};

void do_Work(Base *ptr)
{
		cout<<endl<<"task 1111 done"<<endl;
		ptr->fun1();
		ptr->fun2();
		cout<<endl<<"task 2222 done"<<endl;
}


void main()
{
	CB *ptrCB=new CB();
	do_Work(ptrCB);
	CA *ptrCA=new CA();
	do_Work(ptrCA);
}
#include<iostream.h>

class CBase
{
public:
		void funBase()
		{
			cout<<endl<<"funBase called"<<endl;
		}
		void funDerived()
		{
			cout<<endl<<"funDerived called"<<endl;
		}
};

class CDerived:public CBase
{
public:
	void funDerived()
	{
		cout<<endl<<"funDerived from Derived called"<<endl;
	}
	void fun()
	{
		cout<<endl<<"fun Cderived"<<endl;
	}
};

CBase * create_Obj()
{
		return new CDerived();
}
//...........................................



void main()
{
	CBase *ptr=create_Obj();
	ptr->funBase();
	ptr->funDerived();
	ptr
}
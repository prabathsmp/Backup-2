#include<iostream.h>

class CA
{
	
public:
	int x;
	CA()
	{
	x=100;		

	}

};

class CB:virtual public CA
{
public:
	int y;
	CB()
	{
		y=200;
	}
};

class CC:virtual public CA
{
public:
	int z;
	CC()
	{
		z=300;
	}

};

class CD:public CB,public CC
{
public:
	int a;
	CD()
	{
		a=400;
	}
};

void main()
{
	/*CD obj;
	obj.CC::x=1000;
	long* pt=(long*)(&obj);
	cout<<endl<<*pt;
	pt++;
	cout<<endl<<*pt;
	pt++;
	cout<<endl<<*pt;
	pt++;
	cout<<endl<<*pt;
	*/
	CD obj;
	cout<<endl<<sizeof(CD);
	long *vp=(long*)(&obj);
	long * off=(long*)*vp;
	cout<<endl<<"\t\t"<<off[1];
	vp++;
	cout<<endl<<*vp<<endl;
	//long * off=(long*)*vp;
	//cout<<endl<<"\t\t"<<off[2];

	
	//long * off=(long*)*vp;
	//cout<<endl<<"\t\t"<<off[2]<<endl;
	//vp++;
	cout<<endl<<*vp;
	//off=(long*)*vp;
	//cout<<endl<<"\t\t"<<off[2]<<endl;
	//vp++;
	//cout<<endl<<*vp;
	//vp++;

}

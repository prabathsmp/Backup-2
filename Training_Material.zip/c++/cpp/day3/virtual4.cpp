#include<iostream.h>
#include<typeinfo.h>

//...........................LIBRARY........
/*void fun(int x)
{
	cout<<endl<<"fun for int called"<<endl;
}

void fun(float f)
{
	cout<<endl<<"fun for float called"<<endl;
}

void fun(char c)
{
	cout<<endl<<"fun for char called"<<endl;
}

void fun(double d)
{
	cout<<endl<<"fun for double called"<<endl;
}

*/

template<typename type,typename T>

void fun(type x,T y)
{
	cout<<endl<<" :fun generated for "<<typeid(x).name()<<" and "<<typeid(y).name()<<endl;
}


template<typename type>
void fun(type x)
{
	cout<<endl<<" :fun generated for "<<typeid(x).name()<<endl;
}

template<>
//void fun<>(int y)
void fun(int y)
{
	cout<<endl<<" :fun generated specialised for integer "<<endl;
}


//.............EOL............................

void main()
{
/*	fun(10,12.7);
	fun(3.14f,56);
	fun(45.78,890.8);
	fun("a",1);
*/
fun(10);
fun(3.14);
fun(3.14f,56);

}
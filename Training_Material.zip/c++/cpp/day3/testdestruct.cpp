#include<iostream.h>

class CA
{
public:
	virtual ~CA()
	{
		cout<<endl<<"CA Destructed.."<<endl;
	}
};

class CB:public CA
{
public:
	~CB()
	{
		cout<<endl<<"CB Destructed.."<<endl;
	}
};


void main()
{
	CA *ptr=new CB();
	delete ptr;
}
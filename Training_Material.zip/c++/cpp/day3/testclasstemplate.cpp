#include<iostream.h>
#include<typeinfo.h>

template<typename type>
class CA
{
public:
	CA()
	{
		cout<<endl<<"CA constructed."<<typeid(type).name()<<endl;
	}
	void fun()
	{
		cout<<endl<<"CA fun called."<<typeid(type).name()<<endl;
	}
	void funX();
	~CA()
	{
		cout<<endl<<"CA destructed."<<typeid(type).name()<<endl;
	}

};

template<class T>
void CA<T>::funX()
{
		cout<<endl<<"CA funX called."<<typeid(type).name()<<endl;
}

void main()
{
	CA<int> obj;
	//obj.fun();
	//obj.funX();
	CA<float> obj1;
	//obj1.fun();
	//obj1.funX();
}
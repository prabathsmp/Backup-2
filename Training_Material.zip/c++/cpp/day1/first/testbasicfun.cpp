#include<iostream.h>

void fun(int x)
{
	cout<<endl<<"Fun for integer called"<<endl;
}//stack unwinding

void fun(float x)
{
	cout<<endl<<"Fun for float called"<<endl;
}//stack unwinding

void fun(double x)
{
	cout<<endl<<"Fun for double called"<<endl;
}//stack unwinding

void main()
{
	fun(10);
	fun(10.2);
	fun(678.33);
}

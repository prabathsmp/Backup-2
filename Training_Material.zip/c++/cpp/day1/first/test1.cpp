

#include<iostream.h>


void main()
{
    int i=10;
	int j=20;
    //const *int ptr=&i;
    //*ptr=1000;
     //int *const ptr=&i;
      
	int  const *const ptr=&i;                 //const address and const value
	 //*ptr=740;
	//ptr =&j;
	++i;
	 cout<<endl<<"i="<<*ptr<<endl;                //try ++i
	 cout<<endl<<"j="<<j<<endl;
	 cout<<endl<<"*ptr="<<*ptr<<endl;
}
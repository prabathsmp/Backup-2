

#include<iostream.h>

class CA
{
public:
		virtual void fun()
		{
			cout<<endl<<"fun called"<<endl;
		}
		virtual void fun1()
		{
			cout<<endl<<"fun1 called"<<endl;
		}
};

void main()
{

	//cout<<endl<<sizeof(CA)<<endl;
	CA obj;
	long* vptr=(long*)&obj;
	long* vtable=(long*)*vptr;
	typedef void (_stdcall *FPTR)();
	FPTR fp=(FPTR) vtable[0];
	fp();
}



#include<iostream.h>

class CA
{
	int x;
	const int c;
public:
	CA():x(10),c(10)
	{
		cout<<endl<<"CA constructor"<<endl;
	}
	explicit CA(int i):x(i),c(20)
	{
		cout<<endl<<"CA one param constructor"<<endl;
	}
	CA(int x,int j):c(50)
	{
		this->x=x;
		cout<<endl<<"CA two parameter constructor"<<endl;
		cout<<"x="<<x<<endl;
	}
	CA(CA& o):c(1000)
	{
		this->x=o.x;       //i altered
		cout<<"the cosnt value is"<<c<<endl;
		cout<<"the cosnt value is o.x"<<this->x<<endl;
		cout<<endl<<"CA Copy constructor"<<x<<endl;
	}

};

void main()
{
	CA obj(500,200);
	//CA obj(100);
	//CA obj1=200;	//casting is performed in absence of explicit keyword
	//obj1=500;
	CA obj1(obj);
}


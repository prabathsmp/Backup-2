#include<iostream.h>

class CA
{
	int x;
	mutable int y;
	public:
		CA(int i):x(i),y(x)//initialisation
		{
			
			//x=10;//assignment
			//y=20;
			cout<<endl<<"resource allotted"<<endl;
			cout<<endl<<"resource allotted"<<x<<y<<endl ;                    //i altered                
		}
		void disp_data()const;                      //declaration
		void myDisplay()const
		{
			cout<<"from my display"<<endl;
		//	x++;
			cout<<endl<<"x="<<x<<endl;
			y++;
			cout<<endl<<"y="<<y<<endl;
		}
		~CA()
		{
			cout<<endl<<"resource de-allotted"<<endl;
		}
};

void CA::disp_data() const//non inline
{
	cout<<endl<<"x="<<x<<endl;
	cout<<endl<<"y="<<y<<endl;
}

void main()
{
	 const CA obj(10);
	//obj.set_data();
	obj.disp_data();
	obj.myDisplay();
	obj.CA:: display_data();                       //i altered
	//obj.Release();
}
#include<iostream.h>

class CA
{
 static int s;
	int b;
public:
	CA():b(10)
	{
	}
	void statFun()const
	{
	//	s=12;
		cout<<endl<<"s="<<s<<endl;
	}
	void disp()
	{
		//s=15;
		cout<<"b="<<b<<endl;
		cout<<endl<<"s="<<s<<endl;
	}
};

int CA::s=100;              //declaration of static variable

void main()
{
	
	CA obj;
	//int CA::s=100;
	obj.statFun();
	obj.disp();
	 //CA::statFun();
}
#include<iostream.h>

class CA//Interface
{
public:
	virtual void fun1()
	{
		cout<<endl<<"fun1"<<endl;
	}
	virtual void fun2()
	{
		cout<<endl<<"fun2 base"<<endl;
	}
	
};


class CB:public CA
{
public:
	
	void fun2()
	{
		cout<<endl<<"fun2 derived"<<endl;
	}
	virtual void fun3()
	{
		cout<<endl<<"fun3 called"<<endl;
	}
	
};

void main()
{
	CB *pt=new CB();
	//cout<<endl<<"sizeof(CB)<<endl;
	((void(*)())*((long *)*((long*)(pt))+0))();
	((void(*)())*((long *)*((long*)(pt))+1))();
	((void(*)())*((long *)*((long*)(pt))+2))();
}

#include<iostream.h>

int i=10;

int * getI()
{
	return &i;
}

int & getICPP()
{
	return i;
}

void main()
{
/*
	int x=10;
	int *ptr=&x;
	*ptr=100;
*/
/*
	int x=10;
	int & ptr=x;
	ptr=100;
	*/

	*getI()=1000;
	cout<<endl<<"i="<<i;

	int & u=getICPP();
	u=4000;
	cout<<endl<<"i="<<i;
	getICPP()=5000;              //i have put same as for 4000
	cout<<endl<<"i="<<i;

}

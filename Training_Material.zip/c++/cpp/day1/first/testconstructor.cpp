#include<iostream.h>

class CA
{
public:
	CA()
	{
		cout<<endl<<"CA default called"<<endl;
	}
	~CA()
	{
		cout<<"CA Destructor called"<<endl;
	}
};

class CB
{
	CA ob;                //object of class CA declared//contained object
public:
	CB()
	{
		cout<<endl<<"CB default called"<<endl;
	}
	~CB()
	{
		cout<<"CB Destructor called"<<endl;
	}
};

void main()
{
	CB obj;
}
#include<iostream.h>

class IX//Interface
{
public:
	virtual void fx1()=0;
	virtual void fx2()=0;
};

class IY//Interface
{
public:
	virtual void fy1()=0;
	virtual void fy2()=0;
};


class CA:public IX,public IY//Derived
{
public:
	void fx1()
	{
		cout<<endl<<"fx1"<<endl;
	}
	void fx2()
	{
		cout<<endl<<"fx2"<<endl;
	}
	void fy1()
	{
		cout<<endl<<"fy1"<<endl;
	}
	void fy2()
	{
		cout<<endl<<"fy2"<<endl;
	}

};

void main()
{
	IX *px=new CA();
	//px->fx1();
	//px->fx2();
	IY *py=(IY*)px;//IY *py=new CA();
	//px->fx1();
	//px->fx2();
	py->fy1();
	py->fy2();
}

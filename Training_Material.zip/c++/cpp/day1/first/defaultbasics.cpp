#include<iostream.h>


/*void DFun(int, int, int, int=1000);
void DFun(int, int, int=2000, int);
void DFun(int, int=3000, int, int);
void DFun(int=4000, int, int, int);
*/

void DFun( int a, int b, int c, int d) //Dfinition
{
  
	cout<<endl<<"a="<<a<<endl;
	cout<<endl<<"b="<<b<<endl;
	cout<<endl<<"c="<<c<<endl;
	cout<<endl<<"d="<<d<<endl;
}

void main()
{

	DFun(10,20,30,40);               //i altered it was 10 ,i gave extra

}
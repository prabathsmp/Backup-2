#Author: Ramesh Asangi
#Modified by: Prabath 
#Script to check the Build Error
#Version : 1.2
#set -x 
export NO_OF_ARG=$#
export BUILD_CHECK_DIR="/home/plugin_tsip/Prabath"
#export BUILD_CHECK_DIR=`pwd`
export PROD_NAME=$1
export TARGET=$2
export COMPONENT=$3
export INDEX=-1 
export PROD_PATH=$BUILD_CHECK_DIR/$PROD_NAME
if [ "$TARGET" = "L7.0" ]
then
	PROD_PATH=$BUILD_CHECK_DIR/$TARGET"_"$PROD_NAME
	echo "New PROD_PATH=$PROD_PATH"
fi
#export PROD_PATH=$BUILD_CHECK_DIR/$PROD_NAME
export WORKSET=""
export LAYER="-al"
export COMPILATION_PATH="$PROD_PATH"
export SUB_WORKSET_1=""
export SUB_WORKSET_2=""
export SUB_WORKSET_3=""
export SYS_PATH="$COMPILATION_PATH/BUILD_SETUP/SYSROM_SRC"

DIM_USR_NAME="t0573526"
DIM_USD_PWD="httpd123"
DIM_HOST_NAME="tec-mssd003"
DIM_DB_NAME="ebx"
DIM_DB_CONN_NAME="dim14"
export LD_LIBRARY_PATH=/opt/serena/dimensions/14.3/cm/lib:/usr/lib:/usr/X11R6/lib:$LD_LIBRARY_PATH

echo "NO_OF_ARG passed = $NO_OF_ARG"
echo "Product name=$PROD_NAME"
echo "Target =$TARGET"
echo "Product Path=$PROD_PATH"
echo "LAYER=$LAYER"
echo "COMPILATION_PATH=$COMPILATION_PATH"
function no_arguments
{
cat <<EOF
************************************************************************************************************************************         
*                                 Usage:                                                              				         	   
*---------------------------------------------------------------------------------------------------------------------------------- 
*./Build_Check_EBN.sh <Product Name> <Target> <ComponentName>  
Example :
* 1) To compile particular component in particular TARGET/PRODUCT
		./Build_Check_EBN.sh WEISS_3H L6.5 	SoftwareFunction/MailBox	
* 2) To compile all components in particular TARGET/PRODUCT
		./Build_Check_EBN.sh WEISS_3H L6.5
* 3) To compile ALL TARGETS/PRODCUTS, 
		Run Initiate_Build.sh		
*__________________________________________________________________________________________________________________________________
*SING18/16  Product Name ===>MATTERHORN, WEISS_3H, WEISS2H, WEISS2L, REUSS, SHASTA, SHASTINA,CASPIAN   							   
*SING20 	Product Name ===>WEISS4L,  WEISS4HL,  WEISS3H_S20									    							   
*SING20 	Product Name ===>WEISS4HH,  WEISS4HHH,  REUSS3L, REUSS3H							   								   			*  																																   
*Target ====================> L7.0, L6.5, L6.01, L6.015, L6.02 , L6.03  
*ComponentName =============> SoftwareFunction/JobTemplates
							SoftwareFunction/MailBox
							SoftwareFunction/USBApplication
							Maintenance/FileStorageManager
							PrintJobManager
							SoftwareFunction/HomeDataManager
							AppAccessor
							SoftwareFunction/LogRetriever
							SharedPrintDeployer
							SoftwareFunction/Accounting
							SoftwareFunction/USBApplication/USBInterface
							SoftwareFunction/SecurePDFLibrary
							SoftwareFunction/HomeDataLibrary
							SoftwareFunction/AccountingLibrary
							Reporting
							JobController                         					                          								                       													                           
************************************************************************************************************************************
EOF
}

function chk_prd_n_init_param
{
    #echo "in function chk_prd_n_init_param"
    if [ "$TARGET" = "L6.5" ]
    then 
		if [ "$PROD_NAME" = "WEISS_3H" ]
		then
			WORKSET="EBN_L6_5FC_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_WEISS3_COM_SUB_REL_WS"	
			SUB_WORKSET_2=""
			SUB_WORKSET_3=""
		elif [ "$PROD_NAME" = "WEISS_3L" ]
		then
			WORKSET="EBN_L6_5FC_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_WEISS3_COM_SUB_REL_WS"
			SUB_WORKSET_2="EBN_INTEG_WEISS3_L_SUB_REL_WS"
			SUB_WORKSET_3=""
		elif [ "$PROD_NAME" = "MATTERHORN" ]
		then
			WORKSET="EBN_L6_5FC_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_MATTERHORN_SUB_REL_WS"
			SUB_WORKSET_2="EBN_INTEG_SKELIOS20_SUB_REL_WS"
			SUB_WORKSET_3=""	
		elif [ "$PROD_NAME" = "REUSS2" ]
		then
			WORKSET="EBN_L6_5FC_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_REUSS2_SUB_REL_WS"
			SUB_WORKSET_2=""
			SUB_WORKSET_3=""	
		elif [ "$PROD_NAME" = "SHASTA2" ]
		then
			WORKSET="EBN_L6_5FC_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_SHASTA2_SUB_REL_WS"
			SUB_WORKSET_2=""
			SUB_WORKSET_3=""	
		elif [ "$PROD_NAME" = "SHASTINA2" ]
		then
			WORKSET="EBN_L6_5FC_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_SHASTINA2_SUB_REL_WS"
			SUB_WORKSET_2=""
			SUB_WORKSET_3=""	
		elif [ "$PROD_NAME" = "WEISS2H" ]
		then
			WORKSET="EBN_L6_5FC_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_SING16_COM_REL_WS"
			SUB_WORKSET_2="EBN_INTEG_WEISS2_COM_SUB_REL_WS"
			SUB_WORKSET_3=""
		elif [ "$PROD_NAME" = "WEISS2L" ]
		then
			WORKSET="EBN_L6_5FC_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_SING16_COM_REL_WS"
			SUB_WORKSET_2="EBN_INTEG_WEISS2_COM_SUB_REL_WS"
			SUB_WORKSET_3="EBN_INTEG_WEISS2_L_SUB_REL_WS"
		elif [ "$PROD_NAME" = "REUSS" ]
		then
			WORKSET="EBN_L6_5FC_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_SING16_COM_REL_WS"
			SUB_WORKSET_2="EBN_INTEG_REUSS_SUB_REL_WS"
			SUB_WORKSET_3=""
		elif [ "$PROD_NAME" = "SHASTA" ]
		then
			WORKSET="EBN_L6_5FC_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_SING16_COM_REL_WS"
			SUB_WORKSET_2="EBN_INTEG_SHASTA_SUB_REL_WS"
			SUB_WORKSET_3=""
		elif [ "$PROD_NAME" = "SHASTINA" ]
		then
			WORKSET="EBN_L6_5FC_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_SING16_COM_REL_WS"
			SUB_WORKSET_2="EBN_INTEG_SHASTINA_SUB_REL_WS"
			SUB_WORKSET_3=""	
		elif [ "$PROD_NAME" = "CASPIAN" ]
		then
			WORKSET="EBN_L6_5FC_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_SING16_COM_REL_WS"
			SUB_WORKSET_2="EBN_INTEG_CASPIAN_SUB_REL_WS"
			SUB_WORKSET_3=""	
		else	
			echo -e "Invalid Combination!!!\n"
			no_arguments
			exit -1
		fi
	elif [ "$TARGET" = "L7.0" ]
    	then 
		if [ "$PROD_NAME" = "MATTERHORN" ]
		then
			WORKSET="EBN_L6_5FC_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_MATTERHORN_SUB_REL_WS"
			SUB_WORKSET_2="EBN_INTEG_SKELIOS20_SUB_REL_WS"
			SUB_WORKSET_3="EBN_INTEG_SING20_DEV_COM_SUB_REL_WS"	
##SET#1
		elif [ "$PROD_NAME" = "WEISS4L" ]
		then
			WORKSET="EBN_INTEG_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_WEISS4_COM_SUB_REL_WS"
			SUB_WORKSET_2="EBN_INTEG_WEISS4_L_SUB_REL_WS"
			SUB_WORKSET_3="EBN_INTEG_SING20_DEV_COM_SUB_REL_WS"
		elif [ "$PROD_NAME" = "WEISS4HL" ]
		then
			WORKSET="EBN_INTEG_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_WEISS4_COM_SUB_REL_WS"
			SUB_WORKSET_2="EBN_INTEG_WEISS4_HL_SUB_REL_WS"
			SUB_WORKSET_3="EBN_INTEG_SING20_DEV_COM_SUB_REL_WS"
		elif [ "$PROD_NAME" = "WEISS3H_S20" ]
		then
			WORKSET="EBN_INTEG_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_WEISS4_COM_SUB_REL_WS"
			SUB_WORKSET_2="EBN_INTEG_SING20_WEISS3_SUB_REL_WS"
			SUB_WORKSET_3="EBN_INTEG_SING20_DEV_COM_SUB_REL_WS"
##SET#2
		elif [ "$PROD_NAME" = "WEISS4HH" ]
		then
			WORKSET="EBN_INTEG_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_WEISS4_COM_SUB_REL_WS"
			SUB_WORKSET_2=""
			SUB_WORKSET_3="EBN_INTEG_SING20_DEV_COM_SUB_REL_WS"
		elif [ "$PROD_NAME" = "WEISS4HHH" ]
		then
			WORKSET="EBN_INTEG_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_WEISS4_COM_SUB_REL_WS"
			SUB_WORKSET_2="EBN_INTEG_WEISS4_HHH_SUB_REL_WS"
			SUB_WORKSET_3="EBN_INTEG_SING20_DEV_COM_SUB_REL_WS"
		elif [ "$PROD_NAME" = "REUSS3L" ]
		then
			WORKSET="EBN_INTEG_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_REUSS3_SUB_REL_WS"
			SUB_WORKSET_2=""
			SUB_WORKSET_3="EBN_INTEG_SING20_DEV_COM_SUB_REL_WS"	
		elif [ "$PROD_NAME" = "REUSS3H" ]
		then
			WORKSET="EBN_INTEG_COM_REL_WS"
			SUB_WORKSET_1="EBN_INTEG_REUSS3_SUB_REL_WS"
			SUB_WORKSET_2="EBN_INTEG_REUSS3_HHH_SUB_REL_WS"
			SUB_WORKSET_3="EBN_INTEG_SING20_DEV_COM_SUB_REL_WS"	
		else		
			echo -e "Invalid Combination!!!\n"
			no_arguments
			exit -1
		fi
	fi
}

function pre_chk
{
	##INITIALIZE LOOKUP ENTRIES
	ARGUMENT_LIST1=(
	MATTERHORN
	WEISS_3H
	WEISS2H
	WEISS2L
	REUSS2
	REUSS
	SHASTA
	SHASTA2
	SHASTINA
	SHASTINA2
	CASPIAN
	WEISS4L
	WEISS4HL
	WEISS3H_S20
	WEISS4HH
	WEISS4HHH
	REUSS3L
	REUSS3H
			)

	ARGUMENT_LIST2=(
	L6.5
	L7.0
			)

	##INITIALIZE COMPONENT LOOKUP ENTRIES
	COMPONENT_lIST1=(
	SoftwareFunction/JobTemplates
	SoftwareFunction/MailBox
	SoftwareFunction/USBApplication
	Maintenance/FileStorageManager
	PrintJobManager
	SoftwareFunction/HomeDataManager
	AppAccessor
	SoftwareFunction/LogRetriever
	SharedPrintDeployer
	SoftwareFunction/Accounting
	SoftwareFunction/USBApplication/USBInterface
	SoftwareFunction/SecurePDFLibrary
	SoftwareFunction/HomeDataLibrary
	SoftwareFunction/AccountingLibrary
	##COMPONENT_lIST2
	Reporting
	##COMPONENT_lIST3
	JobController
			)

	SINGLE_BINARY_LIST=(
	$SYS_PATH/bin/aljobtemplatemgr
	$SYS_PATH/bin/almailboxapplication
	$SYS_PATH/bin/alusbmscapplication
	$SYS_PATH/bin/alfilestoragem
	$SYS_PATH/bin/alprintmn
	$SYS_PATH/bin/alhomedatamgr
	$SYS_PATH/bin/alAppAccessor
	$SYS_PATH/bin/alLogRetriever
	$SYS_PATH/bin/alsharedprintDp
	$SYS_PATH/bin/alaccountmgr
	$SYS_PATH/lib/libalusbinterface.so.0
	$SYS_PATH/lib/libalsecurepdf.so.0
	$SYS_PATH/lib/libhdmaccess.so		
	$SYS_PATH/lib/libalaccountmgr.so.0	
	)
	
	DOUBLE_BINARY_LIST=(
	$SYS_PATH/bin/alreportsmsgr
	$SYS_PATH/bin/alreportmanager
	)
	
	QUAD_BINARY_LIST=(
	$SYS_PATH/bin/aljobcontroller
	$SYS_PATH/lib/libalworkflowdatalist.so.0
	$SYS_PATH/lib/libalsessiondatalist.so.0
	$SYS_PATH/lib/libalparameterhandler.so.0
	)
	
			
	##Validate given arguments against lookup arrays
	if [ "$NO_OF_ARG" -le 2 ];then
		if [[ " ${ARGUMENT_LIST1[@]} " =~ " ${PROD_NAME} " ]];then
			echo "Argument1 =$PROD_NAME is valid"
		else
			echo "Argument1 =$PROD_NAME is Invalid!!!"
			no_arguments
			exit -1
		fi
		
		if [[ " ${ARGUMENT_LIST2[@]} " =~ " ${TARGET} " ]];then
			echo "Argument2 =$TARGET is valid"
		else
			echo "Argument2 =$TARGET is Invalid!!!"
			no_arguments
			exit -1
		fi
	elif [ "$NO_OF_ARG" -eq 3 ];then
		if [[ " ${COMPONENT_lIST1[@]} " =~ " ${COMPONENT} " ]];then
			echo "Argument3 =$COMPONENT is valid"
		else
			echo "Argument3 =$COMPONENT is Invalid!!!"
			no_arguments
			exit -1
		fi
	else
		no_arguments
        exit -1
	fi
	
	##Initialize Worksets based on Arguments
    chk_prd_n_init_param
	if [ -d "$COMPILATION_PATH" ]
	then
		if [ -d "$SYS_PATH" ]
		then
			echo "Valid path to the SYSROM_SRC $SYS_PATH"
		else
            mkdir -p "$SYS_PATH"
		fi
	else
		echo "Directory $PROD_PATH is not present,Creating it"
		mkdir -p "$SYS_PATH"
		echo "Valid path to the SYSROM_SRC $SYS_PATH"
	fi
}

function getIndexOfBinaryArray
{
	
	for i in "${!COMPONENT_lIST1[@]}"; do
	   if [[ "${COMPONENT_lIST1[$i]}" = "${COMPONENT}" ]]; then
		  INDEX=${i};
		  echo "${i}";
		  echo $INDEX
	   fi
	done
}

function chk_lyr
{
	if [ ! -z "$WORKSET"  ];then
		if [ ! -z "$COMPONENT" ];then
			echo "for $WORKSET Prepare DownLoad operation for specific component -$COMPONENT"
			files_download_command_main=(
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/$COMPONENT\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		)
		else
			echo "Building ALL Component"
			files_download_command_main=(
		"FI /WORKSET=\"$WORKSET\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/AL/status.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/AL/status.h\" /NOEXPAND - /OVERWRITE"
		"FI /WORKSET=\"$WORKSET\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/portids.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/portids.h\" /NOEXPAND - /OVERWRITE"
		"FI /WORKSET=\"$WORKSET\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/servicenames.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/servicenames.h\" /NOEXPAND - /OVERWRITE"
#		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/LayerInterface\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
#		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/ComponentInterface/AL\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
#		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/HierarchicalDB\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
#		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/MfpUtility\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
#		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/PriorityManager\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
#		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/NetworkClients\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
#		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/PresentationResources\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
#		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/UnifiedLicenseManager\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
#		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/UIController\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
#		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/ApplicationServers/ContentWebServer\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Maintenance\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Reporting\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/AppAccessor\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/JobController\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/PrintJobManager\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SharedPrintDeployer\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/Accounting\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/AccountingLibrary\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/eFiling\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/HomeDataLibrary\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/HomeDataManager\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/JobTemplates\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/LogRetriever\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/MailBox\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"		
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/PDLFilters\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/SecurePDFLibrary\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/USBApplication\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
#		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/FrontPanel/FrontPanelLib\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
#		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Utility\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Spooler\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
#		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/ThirdParty/gsoap\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
#		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Stage2\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
#		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/eAppManagerLibrary\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
			)
			
			chk_files=(
		$SYS_PATH/bin/aljobtemplatemgr
		$SYS_PATH/bin/almailboxapplication
		$SYS_PATH/bin/alusbmscapplication
		$SYS_PATH/bin/alfilestoragem
		$SYS_PATH/bin/alreportsmsgr
		$SYS_PATH/bin/alreportmanager
		$SYS_PATH/bin/aljobcontroller
		$SYS_PATH/bin/alprintmn
		$SYS_PATH/bin/alhomedatamgr
		$SYS_PATH/bin/alAppAccessor
		$SYS_PATH/bin/alLogRetriever
		$SYS_PATH/bin/alsharedprintDp
		$SYS_PATH/bin/alaccountmgr
		$SYS_PATH/lib/libalusbinterface.so.0
		$SYS_PATH/lib/libalsecurepdf.so.0
		$SYS_PATH/lib/libalworkflowdatalist.so.0
		$SYS_PATH/lib/libalsessiondatalist.so.0
		$SYS_PATH/lib/libalparameterhandler.so.0
		$SYS_PATH/lib/libhdmaccess.so		
		$SYS_PATH/lib/libalaccountmgr.so.0		
			)
		fi
	fi
	
	if [ ! -z "$SUB_WORKSET_1" ];then
		if [ ! -z "$COMPONENT" ];then
			echo "For $SUB_WORKSET_1 Prepare DownLoad operation for specific component -$COMPONENT"
			files_download_command_sub1=(
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/$COMPONENT\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		)
		else
			echo "Building ALL Component"
			files_download_command_sub1=(
		"FI /WORKSET=\"$SUB_WORKSET_1\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/AL/status.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/AL/status.h\" /NOEXPAND - /OVERWRITE"
		"FI /WORKSET=\"$SUB_WORKSET_1\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/portids.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/portids.h\" /NOEXPAND - /OVERWRITE"
		"FI /WORKSET=\"$SUB_WORKSET_1\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/servicenames.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/servicenames.h\" /NOEXPAND - /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Maintenance\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Reporting\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/JobController\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/PrintJobManager\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SharedPrintDeployer\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/AppAccessor\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/Accounting\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/AccountingLibrary\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/eFiling\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/HomeDataLibrary\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/HomeDataManager\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/JobTemplates\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/LogRetriever\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/MailBox\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/PDLFilters\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/SecurePDFLibrary\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/USBApplication\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Spooler\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

			)
		fi
	fi
	if [ ! -z "$SUB_WORKSET_2"  ];then
		if [ ! -z "$COMPONENT" ];then
			echo "For $WORKSET_2 Prepare DownLoad operation for specific component -$COMPONENT"
			files_download_command_sub2=(
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/$COMPONENT\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		)
		else
			echo "Building ALL Component"
			files_download_command_sub2=(
		"FI /WORKSET=\"$SUB_WORKSET_2\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/AL/status.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/AL/status.h\" /NOEXPAND - /OVERWRITE"
		"FI /WORKSET=\"$SUB_WORKSET_2\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/portids.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/portids.h\" /NOEXPAND - /OVERWRITE"
		"FI /WORKSET=\"$SUB_WORKSET_2\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/servicenames.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/servicenames.h\" /NOEXPAND - /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Maintenance\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Reporting\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/JobController\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/PrintJobManager\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SharedPrintDeployer\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
        "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/AppAccessor\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/Accounting\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/AccountingLibrary\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/eFiling\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/HomeDataLibrary\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/HomeDataManager\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/JobTemplates\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/LogRetriever\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/MailBox\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/PDLFilters\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/SecurePDFLibrary\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/USBApplication\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Spooler\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		)
		fi
	fi
	
	if [ ! -z "$SUB_WORKSET_3"  ];then
		if [ ! -z "$COMPONENT" ];then
			echo "For $SUB_WORKSET_3 Prepare DownLoad operation for specific component -$COMPONENT"
			files_download_command_sub3=(
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/$COMPONENT\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		)
		else
			echo "For $SUB_WORKSET_3 Building ALL Component"
			files_download_command_sub3=(
		"FI /WORKSET=\"$SUB_WORKSET_3\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/AL/status.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/AL/status.h\" /NOEXPAND - /OVERWRITE"
		"FI /WORKSET=\"$SUB_WORKSET_3\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/portids.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/portids.h\" /NOEXPAND - /OVERWRITE"
		"FI /WORKSET=\"$SUB_WORKSET_3\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/servicenames.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/servicenames.h\" /NOEXPAND - /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Maintenance\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Reporting\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/JobController\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/PrintJobManager\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SharedPrintDeployer\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
        "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/AppAccessor\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/Accounting\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/AccountingLibrary\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/eFiling\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/HomeDataLibrary\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/HomeDataManager\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/JobTemplates\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/LogRetriever\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/MailBox\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/PDLFilters\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/SecurePDFLibrary\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction/USBApplication\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Spooler\" /WORKSET=\"$SUB_WORKSET_3\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		)
		fi
	fi
	
}

function DownLoad
{
	cd $COMPILATION_PATH
	if [ -d "05_Implement" ]
	then
		chmod 777 05_Implement/
		rm -rf 05_Implement/
		echo "Removed Previous Available Codes"
	fi
	
	if [ -a pvcs.log ] 
	then
		chmod 777 pvcs.log
		rm pvcs.log
	fi
	
	if [ -a command ] 
	then
		chmod 777 command
		rm command
	fi

	if [ -a maillist.txt ]
	then
		chmod 777 maillist.txt
		rm maillist.txt
	fi
	
	if [ ! -z "$WORKSET"  ];then
		for file in ${!files_download_command_main[*]}
		do
        		echo ${files_download_command_main[$file]}
			echo ${files_download_command_main[$file]} >> command
		done
	fi
	
	if [ ! -z "$SUB_WORKSET_1" ];then
		for file in ${!files_download_command_sub1[*]}
		do
	        	echo ${files_download_command_sub1[$file]}
			echo ${files_download_command_sub1[$file]} >> command
		done
	fi

	if [ ! -z "$SUB_WORKSET_2" ];then
		for file in ${!files_download_command_sub2[*]}
		do
        		echo ${files_download_command_sub2[$file]}
			echo ${files_download_command_sub2[$file]} >> command
		done
	fi

	if [ ! -z "$SUB_WORKSET_3" ];then
		for file in ${!files_download_command_sub3[*]}
		do
        		echo ${files_download_command_sub3[$file]}
			echo ${files_download_command_sub3[$file]} >> command
		done
	fi
	
	chmod 777 command

	echo "DOWNLOAD Start"
	
	#/opt/serena/dimensions/10.1/cm/prog/dmcli -con ebx_DIM_10_New -user aramesh -pass Toshiba1 -file command > pvcs.log 2>&1
	#/opt/serena/dimensions/10.1/cm/prog/dmcli -user tsaurabh -pass dldlteam -host TEC-MSSD003 -dbname ebx -dsn ora11dim -file command > pvcs.log 2>&1
	for i in {1..30}
	do 
		echo "dmcli -user $DIM_USR_NAME -pass $DIM_USD_PWD -host $DIM_HOST_NAME -dbname $DIM_DB_NAME -dsn $DIM_DB_CONN_NAME"
		/opt/serena/dimensions/14.3/cm/prog/dmcli -user $DIM_USR_NAME -pass $DIM_USD_PWD -host $DIM_HOST_NAME -dbname $DIM_DB_NAME -dsn $DIM_DB_CONN_NAME -file command > pvcs.log 2>&1
		#	/opt/serena/dimensions/14.3/cm/prog/dmcli -user $DIM_USR_NAME -pass $DIM_USD_PWD -host $DIM_HOST_NAME -dbname $DIM_DB_NAME -dsn $DIM_DB_CONN_NAME -file command > pvcs.log 2>&1
		RET_VAL=$?
		echo "dimention ret_val=$RET_VAL"
		chmod 777 pvcs.log
		x=`grep -cy "expired\|Failed to start" pvcs.log`
#x=0	
		if [ $x -eq 1 ]
		then
			echo "No Error in Downloading "
			break
		else
			echo "$x errors in downloading file"
			tmp=`cat pvcs.log | grep -e "$WORKSET" | grep -c "does not exist"`
			if [ "$tmp" -ne 0 ]
			then
				echo "Please Enter a valid WORKSET"
				exit -1
			fi
			tmp1=`cat pvcs.log | grep -e "$SUB_WORKSET_1" | grep -c "does not exist"`
					if [ "$tmp1" -ne 0 ]
					then
							echo "Please Enter a valid SUB_WORKSET_1"
							exit -1
					fi
			tmp2=`cat pvcs.log | grep -e "$SUB_WORKSET_2" | grep -c "does not exist"`
					if [ "$tmp2" -ne 0 ]
					then
							echo "Please Enter a valid SUB_WORKSET_2"
							exit -1
					fi	
			
			tmp3=`cat pvcs.log | grep -e "$SUB_WORKSET_3" | grep -c "does not exist"`
					if [ "$tmp3" -ne 0 ]
					then
							echo "Please Enter a valid SUB_WORKSET_3"
							exit -1
					fi	
			echo "Trouble in Downloading files from Dimensions"
			sleep 2;
			echo "Retrying $i th time"
		fi
	done
	if [ $RET_VAL -eq 0 ];then
		echo "Retry Mechanism failed to connect Dimension"
		exit -1;
	fi
	
	if [ -d "05_Implement" ]
	then
		chmod 777 05_Implement/
		echo "05_Implement download completed"
	else
		echo "Some problem in Downloading files May be the WORKSET $WORKSET doesnot contain any files"
		exit -1
	fi
}

function remove_existing_binaries
{
	echo "Removing the existing Binaries and Libraries"
	##COMPONENT LEVEL 
	if [ ! -z "$COMPONENT" ];then
		if [ $INDEX -lt 14 ];then
			echo "rm ${SINGLE_BINARY_LIST[$INDEX]}"
			if [ -a ${SINGLE_BINARY_LIST[$INDEX]} ];then
				rm ${SINGLE_BINARY_LIST[$INDEX]}
			else
				echo "${SINGLE_BINARY_LIST[$INDEX]} already removed"
			fi
		elif [ $INDEX -eq 14 ];then
			for rmv_file in ${DOUBLE_BINARY_LIST[*]}  
			do
				if [ -a $rmv_file ]
				then
					echo "rm $rmv_file"
					rm $rmv_file
				else
					echo "$rmv_file already removed"
				fi
			done
				
		else
			for rmv_file in ${QUAD_BINARY_LIST[*]}
			do
				if [ -a $rmv_file ]
				then
					echo "rm $rmv_file"
					rm $rmv_file
				else
					echo "$rmv_file already removed"
				fi
			done
		fi
	else
		for rmv_file in ${chk_files[*]}
		do
			if [ -a $rmv_file ]
			then
				echo "$rmv_file"
				rm $rmv_file
			else
				echo "$rmv_file already removed"
			fi
		done
	fi
	
	if [ -a $SYS_PATH/dev/AL/completed_list ] 
	then
		rm $SYS_PATH/dev/AL/completed_list
		touch $SYS_PATH/dev/AL/completed_list
	fi
	
	if [ -a $SYS_PATH/dev/AL/mail ]
	then
		rm $SYS_PATH/dev/AL/mail
		touch $SYS_PATH/dev/AL/mail
	fi

	if [ -a $SYS_PATH/dev/AL/Available_List ]
	then
		rm $SYS_PATH/dev/AL/Available_List
		touch $SYS_PATH/dev/AL/Available_List
	fi

	if [ -a $SYS_PATH/dev/AL/UnAvailable_List ]
	then
		rm $SYS_PATH/dev/AL/UnAvailable_List
		touch $SYS_PATH/dev/AL/UnAvailable_List
	fi

}

function Copy_Files
{
	rm -rf $SYS_PATH/dev/AL/Spooler
	rm -rf $SYS_PATH/dev/AL/PrintJobManager
	rm -rf $SYS_PATH/dev/AL/JobController
	rm -rf $SYS_PATH/dev/AL/Maintenance
	rm -rf $SYS_PATH/dev/AL/Reporting
	rm -rf $SYS_PATH/dev/AL/SharedPrintDeployer
	rm -rf $SYS_PATH/dev/AL/AppAccessor
	rm -rf $SYS_PATH/dev/AL/SoftwareFunction/eFiling
	rm -rf $SYS_PATH/dev/AL/SoftwareFunction/HomeDataLibrary
	rm -rf $SYS_PATH/dev/AL/SoftwareFunction/HomeDataManager
	rm -rf $SYS_PATH/dev/AL/SoftwareFunction/JobTemplates
	rm -rf $SYS_PATH/dev/AL/SoftwareFunction/LogRetriever
	rm -rf $SYS_PATH/dev/AL/SoftwareFunction/PDLFilters
	rm -rf $SYS_PATH/dev/AL/SoftwareFunction/SecurePDFLibrary
	rm -rf $SYS_PATH/dev/AL/SoftwareFunction/USBApplication
	rm -rf $SYS_PATH/dev/AL/SoftwareFunction/Accounting
	rm -rf $SYS_PATH/dev/AL/SoftwareFunction/AccountingLibrary
	rm -rf $SYS_PATH/dev/AL/SoftwareFunction/MailBox

	cp -rf $COMPILATION_PATH/05_Implement/SYSROM_SRC/* $SYS_PATH/  
	cp /home/plugin_tsip/Prabath/Makefile_AL_TESI $SYS_PATH/dev/AL/
	cp /home/plugin_tsip/Prabath/Makefile_anand $SYS_PATH/dev/AL/SoftwareFunction/
	echo "Copied files from 05_Implement/ to SYSROM_SRC/"
}

function apply_env
{
	## Cross compiler for ISYS board
	#export PATH=$PATH:/opt/WindRiver40/wrlinux-4/sysroots/mfp_sys210d-glibc_std/x86-linux2/:/opt/WindRiver40/wrlinux-4/layers/wrll-toolchain-4.4a-323/powerpc/toolchain/x86-linux2/bin:/opt/WindRiver40/wrlinux-4/layers/wrll-toolchain-4.4a-323/i586/toolchain/x86-linux2/bin:/opt/WindRiver40/wrlinux-4/foundation//x86-linux2/wrbin
	###LATEST###export PATH=$PATH:/opt/WindRiver30/wrlinux-3.0/sysroots/mfp_sys470d-glibc_std/x86-linux2:/opt/WindRiver30/wrlinux-3.0/sysroots/mfp_sys430exd-glibc_cgl/x86-linux2:/opt/WindRiver30/wrlinux-3.0/layers/wrll-toolchain-4.3-85/powerpc/toolchain/x86-linux2/bin
	#export TOOLCHAIN_PATH=/opt/WindRiver40/wrlinux-4/sysroots/mfp_sys210d-glibc_std/sysroot	
	###LATEST###export TOOLCHAIN_PATH=/opt/WindRiver30/wrlinux-3.0/sysroots/mfp_sys470d-glibc_std/sysroot
	#. setup_isys.sh
	echo "Applying setenv"
#anand::changed
#	cd SYSROM_SRC
	cd $SYS_PATH/
	PWD=`pwd`
	ls -l setenv
	# anand:: hard coded the below line
	#. /home/eBN/setenv_icc
	. $PWD/setenv
	. $PWD/build_exports
	echo $EB2
	cd $COMPILATION_PATH 
	echo "Settings Completed"
}

function Compile
{
	echo -e "------------------------------------------------------------------\n" >> $SYS_PATH/dev/AL/mail
	echo -e "Compilation StartTime -`date`\n ">> $SYS_PATH/dev/AL/mail
	echo "Compilation Started \n"
	if [ -a $SYS_PATH/dev/AL/build.logs ] 
	then
		rm $SYS_PATH/dev/AL/build.logs
	fi
	
#	if [ -a error.logs ];
#	then
#		rm error.logs
#	fi
	
	if [ ! -z "$COMPONENT" ];then
		echo "Building specific component - $COMPONENT"
		cd $SYS_PATH/dev/AL/$COMPONENT
		make -f Makefile > $SYS_PATH/dev/AL/build.logs 2>&1
	elif [ "$LAYER" = "-al" ];then
		echo "Building Al Components"
		#sh $SYS_PATH/Makefile_AL_TESI -s 2>&1 | tee build.logs
		cd $SYS_PATH/dev/AL/
		#system("cd dev/AL/ && make -f Makefile_AL_TESI clean all > build.logs 2>&1");
		 make -f Makefile_AL_TESI all > $SYS_PATH/dev/AL/build.logs 2>&1
	fi
	
	chmod +x $SYS_PATH/dev/AL/build.logs
	echo -e "Compilation EndTime:`date` \n" >> $SYS_PATH/dev/AL/mail

	echo "Compilation Completed"
	echo -e "------------------------------------------------------------------\n" >> $SYS_PATH/dev/AL/mail
	setup_cnt=`cat $SYS_PATH/dev/AL/build.logs | grep -c "Please run setenv script firstly..."`
	if [ "$setup_cnt" -eq 1 ]
	then
		echo "setup_isys.sh is not executed"
		exit -1
	fi
	
	chk=`grep -c ":.error" $SYS_PATH/dev/AL/build.logs`
	if [ "$chk" -eq 0 ]
	then
		Build_Status="OK" 
		echo "Compilation is completed without Errors."
	#	cat $SYS_PATH/dev/AL/mail 
		echo -e "Compilation is completed without Errors.\n" >> $SYS_PATH/dev/AL/mail
	else
		Build_Status="ERROR"
		echo "Compilation is completed with Errors.Please check the build.logs for further details. "
		echo -e " \n" >> $SYS_PATH/dev/AL/mail
		echo -e "Compilation is completed with Errors.Please check the build.logs.tar.gz for further details.\n " >> $SYS_PATH/dev/AL/mail
		echo -e "\n" >> $SYS_PATH/dev/AL/mail
		echo -e "Please check the below Errors: \n" >> $SYS_PATH/dev/AL/mail
		echo -e "============================================\n" >> $SYS_PATH/dev/AL/mail
		echo `grep "error:" build.logs` >> $SYS_PATH/dev/AL/mail
		echo -e " \n" >> $SYS_PATH/dev/AL/mail
		echo -e "=============================================\n" >> $SYS_PATH/dev/AL/mail
		
	fi		
}

function check_build
{
	
	echo "Checking for the libraries and binaries"
	
	##SPECIFIC COMPONENT LEVEL 
	if [ ! -z "$COMPONENT" ];then
		#SINGLE BINARY
		if [ $INDEX -lt 14 ];then
			if [ -f ${chk_files[$INDEX]} ];then
				echo -e "${chk_files[$INDEX]} available \n"  >> $SYS_PATH/dev/AL/completed_list  
				echo -e "${chk_files[$INDEX]} \n" >> $SYS_PATH/dev/AL/Available_List
			else
				echo -e "${chk_files[$INDEX]} not available\n " >> $SYS_PATH/dev/AL/completed_list
				echo -e "${chk_files[$INDEX]}\n" >> $SYS_PATH/dev/AL/UnAvailable_List
			fi
		##DOUBLE BINARY
		elif [ $INDEX -eq 14 ];then
			for file in ${DOUBLE_BINARY_LIST[*]}  
			do
				if [ -f $file ];then
					echo -e "$file available \n"  >> $SYS_PATH/dev/AL/completed_list  
					echo -e "$file \n" >> $SYS_PATH/dev/AL/Available_List
				else
					echo -e "$file not available\n " >> $SYS_PATH/dev/AL/completed_list
					echo -e "$file\n" >> $SYS_PATH/dev/AL/UnAvailable_List
				fi
			done
		## MULTIPLE BINARY
		else
			for file in ${QUAD_BINARY_LIST[*]}
			do
				if [ -f $file ];then
					echo -e "$file available \n"  >> $SYS_PATH/dev/AL/completed_list  
					echo -e "$file \n" >> $SYS_PATH/dev/AL/Available_List
				else
					echo -e "$file not available\n " >> $SYS_PATH/dev/AL/completed_list
					echo -e "$file\n" >> $SYS_PATH/dev/AL/UnAvailable_List
				fi
			done
		fi
	##ALL COMPONENTS LEVEL	
	else
		for file in ${chk_files[*]}
		do
		#	echo $file
			if [ -f $file ]	
			then
				echo -e "$file available \n" >> $SYS_PATH/dev/AL/completed_list
				echo -e "$file\n" >> $SYS_PATH/dev/AL/Available_List
			else
				echo -e "$file not available\n " >> $SYS_PATH/dev/AL/completed_list
				echo -e "$file\n" >> $SYS_PATH/dev/AL/UnAvailable_List
			fi
		done
	fi
	##COMMON OUTPUT RESULT
	chmod +x $SYS_PATH/dev/AL/completed_list
	cnt=`grep -c "not available" $SYS_PATH/dev/AL/completed_list`
	if [ $cnt -eq 0 ]
	then
		echo "All Compiled binaries and Libraries are available @below location "
		echo -e "All Compiled binaries and Libraries are available @below location\n" >> $SYS_PATH/dev/AL/mail
		echo -e "$SYS_PATH\n" >> $SYS_PATH/dev/AL/mail
		#echo "Thank you for your support." >> $SYS_PATH/dev/AL/mail
		echo -e "Following binaries are built successfully : \n" >> $SYS_PATH/dev/AL/mail
		echo -e "******************************************************************\n" >> $SYS_PATH/dev/AL/mail
	#	`grep -e "available" completed_list >> $SYS_PATH/dev/AL/mail`			
		cat $SYS_PATH/dev/AL/Available_List >> $SYS_PATH/dev/AL/mail
		echo -e "******************************************************************\n" >> $SYS_PATH/dev/AL/mail
	else
		Build_Status="Linking Error"
		echo "$cnt files are not available in the below location Please check"
		echo -e "$cnt files are not available in the below location\n" >> $SYS_PATH/dev/AL/mail
		echo -e "$SYS_PATH\n" >> $SYS_PATH/dev/AL/mail
		echo -e "Following binaries are failed : \n" >> $SYS_PATH/dev/AL/mail
		echo -e "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n" >> $SYS_PATH/dev/AL/mail
		#`grep -e "not available" completed_list >> $SYS_PATH/dev/AL/mail`
		cat $SYS_PATH/dev/AL/UnAvailable_List >> $SYS_PATH/dev/AL/mail
		echo -e "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n" >> $SYS_PATH/dev/AL/mail
	fi
		

}

function Mail_Details
{
	echo "" > $SYS_PATH/dev/AL/mail
	echo -e "Hi all,\n" >> $SYS_PATH/dev/AL/mail
	echo -e "The build check for following WORKSET combination downloaded in the Path : $SYS_PATH is completed\n." >>$SYS_PATH/dev/AL/mail
	echo -e "=================================================================================================================\n" >>$SYS_PATH/dev/AL/mail
	
	if [[ -n $SUB_WORKSET_3 ]]; then	
#		echo -e "**********************************************\n">>$SYS_PATH/dev/AL/mail
		echo -e " MAIN_WORKSET = $WORKSET \n">>$SYS_PATH/dev/AL/mail
		echo -e " SUB_WORKSET_1= $SUB_WORKSET_1\n">>$SYS_PATH/dev/AL/mail
		echo -e " SUB_WORKSET_2= $SUB_WORKSET_2\n">>$SYS_PATH/dev/AL/mail
		echo -e " SUB_WORKSET_3= $SUB_WORKSET_3\n">>$SYS_PATH/dev/AL/mail
		echo -e "********************************************************\n">>$SYS_PATH/dev/AL/mail
	elif [[ -n $SUB_WORKSET_2 ]]; then	
#		echo -e "**********************************************\n">>$SYS_PATH/dev/AL/mail
		echo -e " MAIN_WORKSET = $WORKSET \n">>$SYS_PATH/dev/AL/mail
		echo -e " SUB_WORKSET_1= $SUB_WORKSET_1\n">>$SYS_PATH/dev/AL/mail
		echo -e " SUB_WORKSET_2= $SUB_WORKSET_2\n">>$SYS_PATH/dev/AL/mail
		echo -e "********************************************************\n">>$SYS_PATH/dev/AL/mail
	else
		
#		echo -e "**********************************************\n">>$SYS_PATH/dev/AL/mail
		echo -e " MAIN_WORKSET = $WORKSET \n">>$SYS_PATH/dev/AL/mail
		echo -e " SUB_WORKSET_1= $SUB_WORKSET_1 \n">>$SYS_PATH/dev/AL/mail
		echo -e "********************************************************\n">>$SYS_PATH/dev/AL/mail
	fi
	if [ "$LAYER" = "-al" ];then
		echo -e "The compilation for AL-Plugin components are completed.\n " >> $SYS_PATH/dev/AL/mail
		echo -e "Refer Build Log report @$SYS_PATH/dev/AL/build.logs" >> $SYS_PATH/dev/AL/mail
	fi
}

function send_mail
{
#	echo -e "Regards,\n" >> $SYS_PATH/dev/AL/mail
#	echo -e "BuildCheck_AL_Plugin\n" >> $SYS_PATH/dev/AL/mail
#	tar -czf build.logs.tar.gz $SYS_PATH/dev/AL/build.logs 
	cat $SYS_PATH/dev/AL/mail
#	echo "AL-Plugin\@toshiba-tsip.com" > maillist.txt

#	MAILTO=`cat maillist.txt`
	
	#`/usr/bin/mailx -s " Compilation Status : [ $Build_Status ]  < $PROD_NAME > " -r NoReply@BuildCheck.DL -a build.logs.tar.gz $MAILTO < mail`
	#`/usr/bin/mailx -v -s " Compilation Status : [ $Build_Status ] <$TARGET> < $PROD_NAME > " -a build.logs.tar.gz AL-Plugin\@toshiba-tsip.com < mail`
	#`/usr/bin/mailx -v -s " Compilation Status : [ $Build_Status ] <$TARGET> < $PROD_NAME > " -a build.logs.tar.gz AL-Plugin\@toshiba-tsip.com < $SYS_PATH/dev/AL/mail`
	#`/usr/bin/mailx -v -s " Compilation Status : [ $Build_Status ] <$TARGET> < $PROD_NAME > " -a build.logs.tar.gz Prabath.muthusamy\@toshiba-tsip.com < $SYS_PATH/dev/AL/mail`
}

pre_chk
echo "Worksets are"
echo $WORKSET
echo $SUB_WORKSET_1
echo $SUB_WORKSET_2
echo $SUB_WORKSET_3
chk_lyr
getIndexOfBinaryArray
DownLoad
apply_env
remove_existing_binaries
Copy_Files
Mail_Details
Compile
check_build
send_mail

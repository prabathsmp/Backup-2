#!/bin/bash

#WEDNESDAY BUILD TARGETS
SET1=(
WEISS4L
WEISS4HL
WEISS3H_S20
	)
#THURSDAY BUILD TARGETS
SET2=(
WEISS4HH
WEISS4HHH
REUSS3L
REUSS3H
	)
	
function no_arguments
{
cat <<EOF
************************************************************************************************************************************         
*                   Usage:                                                              										  
*----------------------------------------------------------------------------------------------------------------------------------
*SING18/16  Product Name ===>MATTERHORN, WEISS_3H, WEISS2H, WEISS2L, REUSS, SHASTA, SHASTINA,CASPIAN   							   
*SING20 	Product Name ===>WEISS4L,  WEISS4HL,  WEISS3H_S20									    							   
*SING20 	Product Name ===>WEISS4HH,  WEISS4HHH,  REUSS3L, REUSS3H							   								                  	

*Target =========> L7.0, L6.5, L6.01, L6.015, L6.02 , L6.03                            					                           
* TO COMPILE SPECIFIC PRODUCT & TARGETS													                                           
*         sh Initiate_Build.sh <PRODUCT> <TARGET>												                                           
* EXAMPLES:																				                                           
*	sh Initiate_Build.sh WEISS4L L7.0												 	                                           	
*	sh Initiate_Build.sh REUSS3L L7.0													                                           
*	sh Initiate_Build.sh WEISS_3H L6.5																				                                     *__________________________________________________________________________________________________________________________________												
* TO COMPILE L6.5 MATTERHORN
*         sh Initiate_Build.sh MATTERHORN L6.5 
*__________________________________________________________________________________________________________________________________
* To COMPILE L7.0 Set of Targets [Wed. Build:  WEISS4L,  WEISS4HL,  WEISS3H_S20]                                       		           
* sh Initiate_Build.sh <SETNAME> 
  Example:  sh Initiate_Build.sh SET1																                                                          		
__________________________________________________________________________________________________________________________________
* To COMPILE L7.0 Set of Targets [Thu. Build:   WEISS4HH,  WEISS4HHH,  REUSS3L, REUSS3H] 												   
*         sh Initiate_Build.sh <SETNAME> 
Example:
* sh Initiate_Build.sh SET2		
____________________________________________________________________________________________________________________________________
* TO COMPILE SPECIFIC COMPONENT for SPECIFIC PRODUCT & TARGETS	
*       sh Initiate_Build.sh <PRODUCT> <TARGET> <ComponentName>												                                           
* EXAMPLES:																				                                           
*	sh Initiate_Build.sh WEISS4L L7.0 SoftwareFunction/USBApplication												 	                                           	
*	sh Initiate_Build.sh REUSS3L L7.0 AppAccessor													                                           
*	sh Initiate_Build.sh WEISS_3H L6.5 Reporting 	
_________________________________________________________________________________________________________________________________                           					
* To COMPILE SPECIFIC COMPONENET in L7.0 SET OF TARGETS [Thu. Build:   WEISS4HH,  WEISS4HHH,  REUSS3L, REUSS3H] 												   
* sh Initiate_Build.sh <SETNAME> <ComponentName>
Example:
		sh Initiate_Build.sh SET1 SoftwareFunction/Accounting
*
*SETNAME   =================>SET1, SET2
*ComponentName =============> SoftwareFunction/JobTemplates
							SoftwareFunction/MailBox
							SoftwareFunction/USBApplication
							Maintenance/FileStorageManager
							PrintJobManager
							SoftwareFunction/HomeDataManager
							AppAccessor
							SoftwareFunction/LogRetriever
							SharedPrintDeployer
							SoftwareFunction/Accounting
							SoftwareFunction/USBApplication/USBInterface
							SoftwareFunction/SecurePDFLibrary
							SoftwareFunction/HomeDataLibrary
							SoftwareFunction/AccountingLibrary
							Reporting
							JobController  													                                           
************************************************************************************************************************************
EOF
}

#BUILD EXECUTION
function build_execution()
{
	PWD=`pwd`
	if [ $NO_OF_ARGUMENTS -eq 2 ];then
		sh $PWD/Build_Check_EBN.sh $1 $2
        out=$?
    else
        sh $PWD/Build_Check_EBN.sh $1 $2 $3
        out=$?
    fi

	if [ $out -ne -1 ]
	then
		echo $1 vs $2 combination completed!!!
	else
		echo "Invalid combination!!!"
	fi
	echo "=================================================================="
}	
	
#SING20 TARGETS BUILD VERIFICATION
export NO_OF_ARGUMENTS=$#
if [ $NO_OF_ARGUMENTS -lt 1 ]
then
        no_arguments
        exit -1
elif [ $NO_OF_ARGUMENTS -le 2 ]
then
	if [ $1 = "SET1" ];then
		for product in ${SET1[*]}
		do
			PWD=`pwd`
			sh $PWD/Build_Check_EBN.sh $product L7.0 $2
			out=$?
			if [ $out -ne -1 ];then
				echo "$product vs $target combination completed!!!"
			else
				echo "Invalid combination!!!"
			fi
			echo "=================================================================="
		done
	elif [ $1 = "SET2" ];then
		for product in ${SET2[*]}
		do
			PWD=`pwd`
			sh $PWD/Build_Check_EBN.sh $product L7.0 $2
			out=$?
			if [ $out -ne -1 ];then
				echo "$product vs $target combination completed!!!"
			else
				echo "Invalid combination!!!"
			fi
			echo "=================================================================="
		done
	else
		build_execution $1 $2
	fi
elif [ $NO_OF_ARGUMENTS -eq 3 ]
then
        build_execution $1 $2 $3
else
	no_arguments
	exit -1
fi
echo "done.........."








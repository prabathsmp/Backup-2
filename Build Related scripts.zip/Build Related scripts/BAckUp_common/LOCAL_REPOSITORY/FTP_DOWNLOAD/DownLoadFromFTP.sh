echo  "Build DownLoad Started for eBN Target"
echo -e "Hi All,\n"> mail
echo  "Download Started at `date`"
echo -e "Download of eBN Build Target L6.02 and L6.03 has been initiated!!!\n">>mail
echo -e "Regards\n">>mail
echo -e "Build_ALPlugin Team\n">>mail
Status="Download Initiated"
 `/usr/bin/mailx -v -s " Download Status : [ $Status ] " Prabath.muthusamy\@toshiba-tsip.com < mail`
if [ -d "157.69.121.248" ]
then
	rm -rf 157.69.121.248/
fi
echo -e "-----------------------L6.02 DownLoad Started--------------------------\n"
#wget -m -np -A '*.tar.gz' ftp://eBN_Build_M2TW:kWr6o2sP@157.69.121.248/fromTTEC/L6.02/* 2> ftp.logs 1>dev/null 
echo -e "-----------------------L6.02 DownLoad Completed------------------------\n"

echo -e "-----------------------L6.03 DownLoad Started------------------------\n"
#wget -m -np -A '*.tar.gz' ftp://eBN_Build_M2TW:kWr6o2sP@157.69.121.248/fromTTEC/L6.03/* 2>> ftp.logs 1>dev/null
echo -e "-----------------------L6.03 DownLoad Completed------------------------\n"

#cho "f" > ftp.logs
tar -czf ftp.logs.tar.gz ftp.logs
echo -e "Hi All,\n"> mail
chk=`grep -cy "not found" ftp.logs`

if [ $chk -eq 0 ]
then
	if [ -d "157.69.121.248" ]
	then

		Status="Completed Successfully"
        	echo "SYSROM Download is completed without Errors."
        	echo -e "SYSROM Download is completed without Errors.\n" >> mail
		echo -e "Latest Build Downloaded and kept in /home/eBN/LOCAL_REPOSITORY/FTP_DOWNLOAD/157.69.121.248/fromTTEC\n" >>mail
		echo -e "Following are list of available SYSROMS:\n">>mail
		echo -e "========================L6.02==================================">>mail
		echo -e "`ls -ltr /home/eBN/LOCAL_REPOSITORY/FTP_DOWNLOAD/157.69.121.248/fromTTEC/L6.02`\n" >> mail
		echo -e "========================L6.03==================================">>mail
		echo -e "`ls -ltr /home/eBN/LOCAL_REPOSITORY/FTP_DOWNLOAD/157.69.121.248/fromTTEC/L6.03`\n" >> mail 
	else
		
		Status="Error in Downloading"
        	echo -e "SYSROM Download is failed since 157.69.121.248 is unavailable!!!.\n" >>mail
		echo -e "Kindly refer attached logs\n" >> mail
	
else
	Status="Error in Downloading"
        echo -e "SYSROM Download is failed with Errors.\n" >>mail
	echo -e "Kindly refer attached logs\n" >> mail

fi
echo -e "Regards\n">>mail
echo -e "Build_ALPlugin Team\n">>mail

`/usr/bin/mailx -v -s " Download Status : [ $Status ] " -a ftp.logs.tar.gz Prabath.muthusamy\@toshiba-tsip.com < mail`
echo "Done..."

#AuthorName Bharathi kannan 
#EmailId:bharathikannan.kuppan@toshiba-tsip.com
#Description:This script is for Download SysRoms and FR logs.
#
option="${1}" 
if [ $# -eq 3 ] 
then
DIR="${3}"
FileName="${DIR##*/}"
else
DIR="${2}"
FileName="${DIR##*/}"
echo $FileName
fi
case ${option} in 
   fr) FILE="${2}" 
        echo "Going to download Logs file name is $FILE"
	cd /home/data/COMPILATION_SETUP1/FR
        wget ftp://eBX_FRLog:eBX_Log1@157.69.121.248/$FILE
	/home/data/COMPILATION_SETUP1/LogDecryption_v02.sh $FileName
	exit 0
      ;; 
   L6.01) FILE="${3}" 
	if [ $# -ne 3 ]
	then
		echo "Enter the Product Name and Build version"
      		echo -e " \t\tex:-L6.01 /REUSS/B602.31 /S_HYO/L6.01/T2-0/Remote_EBX_STFR_17848_Build602.31.zip"
		exit 1
	fi
        echo "Going to download L6.1 SysROM, file name is $FILE"
	DestDir=`echo ${2}`
	echo $DestDir
	mkdir -p $DestDir
        wget ftp://eBN_Build_M2TW:kWr6o2sP@157.69.121.248/$FILE
	tar -zxvf $FileName
        exit 0 # Command to come out of the program with status 0
      ;; 
   L6.0) FILE="${3}" 
	if [ $# -ne 3 ]
	then
		echo "Enter the Product Name and Build version"
      		echo -e " \t\tex:-L6.0 /REUSS/B602.31 /S_HYO/L6.01/T2-0/Remote_EBX_STFR_17848_Build602.31.zip"
		exit 1
	fi
        echo "Going to download L6.1 SysROM, file name is $FILE"
	DestDir=`echo ${2}`
	echo $DestDir
	mkdir -p $DestDir
        wget ftp://eBN_Build_M2TW:kWr6o2sP@157.69.121.248/$FILE
	tar -zxvf $FileName
	rm $FileName
        exit 0 # Command to come out of the program with status 0
      ;; 
   L4.9) FILE="${3}" 
	if [ $# -ne 3 ]
	then
		echo "Enter the Product Name and Build version"
      		echo -e " \t\tex:-L4.9 /REUSS/B602.31 /S_HYO/L6.01/T2-0/Remote_EBX_STFR_17848_Build602.31.zip"
		exit 1
	fi
        echo "Going to download L6.1 SysROM, file name is $FILE"
	DestDir=`echo ${2}`
	echo $DestDir
	cd L4.9_SYSROMS
	mkdir -p $DestDir
	cd ./$DestDir
	wget ftp://ebx_tsip_build_all:EBX123%21%40%23@10.188.100.148/$FILE
	tar -zxvf $FileName
	rm $FileName
        exit 0 # Command to come out of the program with status 0
      ;; 
   *)  
      echo "`basename ${0}`:usage:" 
      echo -e "\t1\tfor FR fr /S_HYO/L6.01/T2-0/Remote_EBX_STFR_17848_Build602.31.zip"
      echo -e "\t2\tfor SysRom -<Target>  <Product/Buildnumber> File";
      echo -e " \t\tex:-L6.01 /REUSS/B602.31 /S_HYO/L6.01/T2-0/Remote_EBX_STFR_17848_Build602.31.zip"
      exit 1 # Command to come out of the program with status 1
      ;; 
esac 


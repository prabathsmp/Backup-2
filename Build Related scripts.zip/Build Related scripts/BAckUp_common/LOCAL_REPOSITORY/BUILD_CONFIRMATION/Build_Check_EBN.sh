#Author: Ramesh Asangi
#Modified by: Prabath 
#Script to check the Build Error
#Version : 1.2
#set -x 
export NO_OF_ARG=$#
export BUILD_CHECK_DIR="/home/eBN"
#export BUILD_CHECK_DIR=`pwd`
export PROD_NAME=$1
export TARGET=$2
export PROD_PATH=$BUILD_CHECK_DIR/$PROD_NAME
export WORKSET="EBN_INTEG_COM_REL_WS"
export LAYER="-al"
export COMPILATION_PATH="$PROD_PATH/"
export SUB_WORKSET_1=""
export SUB_WORKSET_2=""
export SYS_PATH="$COMPILATION_PATH/BUILD_SETUP/SYSROM_SRC/"

DIM_USR_NAME="t0573526"
DIM_USD_PWD="snmp1994"
DIM_HOST_NAME="tec-mssd003"
DIM_DB_NAME="ebx"
DIM_DB_CONN_NAME="dim14"

#REUSS_COM_WORKSET="EBN_INTEG_COM_REL_WS"
#REUSS_SUB1_WORKSET="EBN_INTEG_REUSS_SUB_REL_WS"

#SHASTINA_COM_WORKSET="EBN_INTEG_COM_REL_WS"
#SHASTINA_SUB1_WORKSET="EBN_INTEG_SHASTINA_SUB_REL_WS"

#SHASTA_COM_WORKSET="EBN_INTEG_COM_REL_WS"
#SHASTA_SUB1_WORKSET="EBN_INTEG_SHASTA_SUB_REL_WS"

#WEISS2_L_SUB1_WORKSET="EBN_INTEG_WEISS2_COM_SUB_REL_WS" 
#WEISS2_L_SUB2_WORKSET="EBN_INTEG_WEISS2_L_SUB_REL_WS"

#WEISS2_H_COM_WORKSET="EBN_INTEG_COM_REL_WS"
#WEISS2_H_SUB1_WORKSET="EBN_INTEG_WEISS2_COM_SUB_REL_WS"

#CASPIAN_SUB1_WORKSET="EBN_INTEG_CASPIAN_SUB_REL_WS"

#if [[ -n $SUB_WORKSET_2 ]]; then
#        echo "SUB_WORKSET_2=$SUB_WORKSET_2"
#fi
echo "NO_OF_ARG passed = $NO_OF_ARG"
echo "Product name=$PROD_NAME"
echo "Target =$TARGET"
echo "Product Path=$PROD_PATH"
echo "WORKSET=$WORKSET"
echo "LAYER=$LAYER"
echo "COMPILATION_PATH=$COMPILATION_PATH"
echo "SUB_WORKSET_1=$SUB_WORKSET_1"
echo "SUB_WORKSET_2=$SUB_WORKSET_2"
echo "SYSROM_PATH=$SYS_PATH"

export LD_LIBRARY_PATH=/opt/serena/dimensions/10.1/cm/lib:/usr/lib:/usr/X11R6/lib:$LD_LIBRARY_PATH
function no_arguments
{
cat <<EOF
*****************************************************************************************         
*                   Usage:                                                              *
*---------------------------------------------------------------------------------------* 
*./Build_Check_EBN.sh <Product Name> <Target>                                           *
*_______________________________________________________________________________________*
*Product Name ===> MATTERHORN, WEISS_3H, WEISS2H, WEISS2L, REUSS, SHASTA, SHASTINA      *
*Target =========> L6.5, L6.01, L6.015, L6.02 , L6.03                                   *
*								                        *
*****************************************************************************************
EOF
}

function pre_chk
{
	if [ "$NO_OF_ARG" -ne 0 ];then
		echo "No of argument is equal to $NO_OF_ARG"
	else
		no_arguments
        exit -1
	fi
    chk_prd_n_init_param
	if [ -d "$COMPILATION_PATH" ]
	then
		if [ -d "$SYS_PATH" ]
		then
			echo "Valid path to the SYSROM_SRC $SYS_PATH"
		else
            mkdir -p "$SYS_PATH"
		fi
	else
		echo "Directory $PROD_PATH is not present,Creating it"
		mkdir -p "$SYS_PATH"
		echo "Valid path to the SYSROM_SRC $SYS_PATH"
	fi
}


function chk_prd_n_init_param
{
    #echo "in function chk_prd_n_init_param"
    if [ "$PROD_NAME" = "WEISS_3H" ]
    then 
        #echo "----------build is for WEISS2H------------"
	if [ "$TARGET" = "L6.14" ]
	then
		WORKSET="EBN_INTEG_COM_REL_WS"	
       		SUB_WORKSET_1="EBN_L6_14_TMP_COM_SUB_REL_WS"
		SUB_WORKSET_2="EBN_L6_14_TMP_WEISS3_COM_SUB_REL_WS"
	elif [ "$TARGET" = "L6.02" ]
	then
		#WORKSET="EBN_INTEG_COM_REL_WS"
		WORKSET="EBN_L6_02FC_COM_REL_WS"
		SUB_WORKSET_1="EBN_WEISS2_COM_L6_02FC_SUB_REL_WS"       		
		#SUB_WORKSET_1="EBN_INTEG_WEISS2_COM_SUB_REL_WS"
		SUB_WORKSET_2=""
	elif [ "$TARGET" = "L6.5" ]
	then
		WORKSET="EBN_INTEG_COM_REL_WS"
		SUB_WORKSET_1="EBN_INTEG_WEISS3_COM_SUB_REL_WS"
	else
		echo -e "Invalid Target!!!\n"
		no_arguments
		exit -1
	fi
    elif [ "$PROD_NAME" = "WEISS2L" ]
    then
        #echo "----------build is for WEISS2L------------"
	if [ "$TARGET" = "L6.015" ]
	then
		WORKSET="EBN_L6_015_COM_REL_WS" 	
       		SUB_WORKSET_1="EBN_WEISS2_COM_L6_015_SUB_REL_WS"
		SUB_WORKSET_2="EBN_WEISS2_L_L6_015_SUB_REL_WS"
	elif [ "$TARGET" = "L6.02" ]
	then
		#WORKSET="EBN_INTEG_COM_REL_WS"
        #	SUB_WORKSET_1="EBN_INTEG_WEISS2_COM_SUB_REL_WS"
       # 	SUB_WORKSET_2="EBN_INTEG_WEISS2_L_SUB_REL_WS"
		WORKSET="EBN_L6_02FC_COM_REL_WS"
		SUB_WORKSET_1="EBN_WEISS2_COM_L6_02FC_SUB_REL_WS"       		
        	SUB_WORKSET_2="EBN_WEISS2_L_L6_02FC_SUB_REL_WS"
	else
		echo -e "Invalid Target!!!\n"
		no_arguments
		exit -1
	fi
    elif [ "$PROD_NAME" = "REUSS" ]
    then
        #echo "----------build is for REUSS------------"
	if [ "$TARGET" = "L6.015" ]
	then
		WORKSET="EBN_L6_015_COM_REL_WS" 	
       		SUB_WORKSET_1="EBN_REUSS_L6_015_SUB_REL_WS"
		SUB_WORKSET_2=""
	elif [ "$TARGET" = "L6.02" ]
	then
		#WORKSET="EBN_INTEG_COM_REL_WS"
		WORKSET="EBN_L6_02FC_COM_REL_WS"
        	#SUB_WORKSET_1="EBN_INTEG_REUSS_SUB_REL_WS"
        	SUB_WORKSET_1="EBN_REUSS_L6_02FC_SUB_REL_WS"
		SUB_WORKSET_2=""
	else
		echo -e "Invalid Target!!!\n"
		no_arguments
		exit -1
	fi
	
    elif [ "$PROD_NAME" = "SHASTA" ]
    then
        #echo "----------build is for SHASTA------------"
	if [ "$TARGET" = "L6.015" ]
	then
		WORKSET="EBN_L6_015_COM_REL_WS" 	
       		SUB_WORKSET_1="EBN_SHASTA_L6_015_SUB_REL_WS"
		SUB_WORKSET_2=""
	elif [ "$TARGET" = "L6.02" ]
	then
		#WORKSET="EBN_INTEG_COM_REL_WS"
		WORKSET="EBN_L6_02FC_COM_REL_WS"
        	#SUB_WORKSET_1="EBN_INTEG_SHASTA_SUB_REL_WS"
        	SUB_WORKSET_1="EBN_SHASTA_L6_02FC_SUB_REL_WS"
		SUB_WORKSET_2=""
	else
		echo -e "Invalid Target!!!\n"
		no_arguments
		exit -1
	fi
	
    elif [ "$PROD_NAME" = "SHASTINA" ]
    then
        #echo "----------build is for SHASTINA------------"
	if [ "$TARGET" = "L6.015" ]
	then
		#WORKSET="EBN_L6_015_COM_REL_WS" 	
		 WORKSET="EBN_L6_02FC_COM_REL_WS"
       		#SUB_WORKSET_1="EBN_SHASTINA_L6_015_SUB_REL_WS"
       		SUB_WORKSET_1="EBN_SHASTINA_L6_02FC_SUB_REL_WS"
		SUB_WORKSET_2=""
	elif [ "$TARGET" = "L6.02" ]
	then
		WORKSET="EBN_INTEG_COM_REL_WS"
        	SUB_WORKSET_1="EBN_INTEG_SHASTINA_SUB_REL_WS"
		SUB_WORKSET_2=""
	else
		echo -e "Invalid Target!!!\n"
		no_arguments
		exit -1
	fi
	
    elif [ "$PROD_NAME" = "CASPIAN" ]
    then
        #echo "----------build is for CASPIAN------------"
	if [ "$TARGET" = "L6.03" ]
	then
		#WORKSET="EBN_INTEG_COM_REL_WS"	
		#SUB_WORKSET_1="EBN_INTEG_CASPIAN_SUB_REL_WS"
		WORKSET="EBN_L6_02FC_COM_REL_WS"	
		SUB_WORKSET_1="EBN_CASPIAN_L6_03FC_SUB_REL_WS"
		SUB_WORKSET_2=""
	else
		echo -e "Invalid Target!!!\n"
		no_arguments
		exit -1
	fi
    elif [ "$PROD_NAME" = "MATTERHORN" ]
    then
	if [ "$TARGET" = "L6.5" ]
	then
		WORKSET="EBN_INTEG_COM_REL_WS"
		SUB_WORKSET_1="EBN_INTEG_MATTERHORN_SUB_REL_WS"
	else
		echo -e "Invalid Target!!!\n"
		no arguments
		exit -1
	fi
    else
        no_arguments
        exit -1
    fi
}

function chk_lyr
{
	#if [ "$NO_OF_ARG" -eq 5 ];then
	if [ ! -z "$WORKSET"  ];then
    #echo "5 argument"
		if [ "$LAYER" = "-al" ];then
			echo "Building AL Component"
			files_download_command_main=(
		"FI /WORKSET=\"$WORKSET\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/AL/status.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/AL/status.h\" /NOEXPAND - /OVERWRITE"
                "FI /WORKSET=\"$WORKSET\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/portids.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/portids.h\" /NOEXPAND - /OVERWRITE"

                "FI /WORKSET=\"$WORKSET\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/servicenames.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/servicenames.h\" /NOEXPAND - /OVERWRITE"
                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/LayerInterface\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/ComponentInterface/AL\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		 "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/HierarchicalDB\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/MfpUtility\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/PriorityManager\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/NetworkClients\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/PresentationResources\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/UnifiedLicenseManager\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/UIController\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/ApplicationServers/ContentWebServer\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Maintenance\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Reporting\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/JobController\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/PrintJobManager\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SharedPrintDeployer\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/FrontPanel/FrontPanelLib\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Utility\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/PrintJobManager\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Spooler\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/ThirdParty/gsoap\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Stage2\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/eAppManagerLibrary\" /WORKSET=\"$WORKSET\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

			)
			
			chk_files=(
$SYS_PATH/bin/aljobtemplatemgr
 $SYS_PATH/bin/almailboxapplication
 $SYS_PATH/bin/alusbmscapplication
 $SYS_PATH/bin/alfilestoragem
 $SYS_PATH/bin/alreportsmsgr
 $SYS_PATH/bin/alreportmanager
 $SYS_PATH/bin/aljobcontroller
$SYS_PATH/bin/alprintmn
$SYS_PATH/bin/alhomedatamgr
  $SYS_PATH/bin/alLogRetriever
  $SYS_PATH/bin/alsharedprintDp
  $SYS_PATH/lib/libalusbinterface.so.0
  $SYS_PATH/lib/libalsecurepdf.so.0
  $SYS_PATH/lib/libalworkflowdatalist.so.0
  $SYS_PATH/lib/libalsessiondatalist.so.0
  $SYS_PATH/lib/libalparameterhandler.so.0
  $SYS_PATH/lib/libhdmaccess.so				
			)
		fi
	fi
	#elif [ "$NO_OF_ARG" -eq 4 ];then
	if [ ! -z "$SUB_WORKSET_1" ];then
  #  	echo "4 argument prabath1"
		if [ "$LAYER" = "-al" ];then
			echo "Building AL Component"
			files_download_command_sub1=(
		"FI /WORKSET=\"$SUB_WORKSET_1\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/AL/status.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/AL/status.h\" /NOEXPAND - /OVERWRITE"
		"FI /WORKSET=\"$SUB_WORKSET_1\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/portids.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/portids.h\" /NOEXPAND - /OVERWRITE"

		"FI /WORKSET=\"$SUB_WORKSET_1\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/servicenames.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/servicenames.h\" /NOEXPAND - /OVERWRITE"
                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/LayerInterface\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"


                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/ComponentInterface/AL\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/HierarchicalDB\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/MfpUtility\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/PriorityManager\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/NetworkClients\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
                
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/PresentationResources\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/UnifiedLicenseManager\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"


                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/UIController\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/ApplicationServers/ContentWebServer\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Maintenance\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Reporting\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/JobController\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/PrintJobManager\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SharedPrintDeployer\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/FrontPanel/FrontPanelLib\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Utility\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/PrintJobManager\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Spooler\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/ThirdParty/gsoap\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

                "DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Stage2\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
                
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/eAppManagerLibrary\" /WORKSET=\"$SUB_WORKSET_1\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

			)
		else
			echo "Please Enter either -s or -d or -sd"
			exit 1
		fi
	fi
	#elif [ "$NO_OF_ARG" -eq 3 ];then
	if [ -z "$SUB_WORKSET_2"  ];then
#	    echo "3 argument prabath2"
		if [ "$LAYER" = "-al" ];then
			echo "Building AL Component"
			files_download_command_sub2=(
		"FI /WORKSET=\"$SUB_WORKSET_2\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/AL/status.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/AL/status.h\" /NOEXPAND - /OVERWRITE"
		"FI /WORKSET=\"$SUB_WORKSET_2\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/portids.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/portids.h\" /NOEXPAND - /OVERWRITE"
		"FI /WORKSET=\"$SUB_WORKSET_2\" /FILENAME=\"05_Implement/SYSROM_SRC/dev/servicenames.h\" /USER_FILENAME=\"$COMPILATION_PATH/05_Implement/SYSROM_SRC/dev/servicenames.h\" /NOEXPAND - /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/LayerInterface\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/ComponentInterface/AL\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/HierarchicalDB\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/MfpUtility\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/PriorityManager\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/NetworkClients\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/PresentationResources\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/CI/UnifiedLicenseManager\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/UIController\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/ApplicationServers/ContentWebServer\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Maintenance\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Reporting\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/JobController\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
	
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/PrintJobManager\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SharedPrintDeployer\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/SoftwareFunction\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/FrontPanel/FrontPanelLib\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Utility\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/PrintJobManager\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Spooler\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/ThirdParty/gsoap\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/Stage2\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"
		
		"DOWNLOAD /DIRECTORY=\"05_Implement/SYSROM_SRC/dev/AL/eAppManagerLibrary\" /WORKSET=\"$SUB_WORKSET_2\" /USER_DIRECTORY=\"$COMPILATION_PATH\" /OVERWRITE"

			)
		else
			echo "Please Enter layer as either -s or -d or -sd"
			exit 1
		fi
	fi
}

function DownLoad
{
	cd $COMPILATION_PATH
	if [ -d "05_Implement" ]
	then
		chmod 777 05_Implement/
		rm -rf 05_Implement/
		echo "Removed Previous Available Codes"
	fi
	
	if [ -a pvcs.log ] 
	then
		chmod 777 pvcs.log
		rm pvcs.log
	fi
	
	if [ -a command ] 
	then
		chmod 777 command
		rm command
	fi

	if [ -a maillist.txt ]
	then
		chmod 777 maillist.txt
		rm maillist.txt
	fi
	
	if [ ! -z "$WORKSET"  ];then
		for file in ${!files_download_command_main[*]}
		do
        		echo ${files_download_command_main[$file]}
			echo ${files_download_command_main[$file]} >> command
		done
	fi
	
	if [ ! -z "$SUB_WORKSET_1" ];then
		for file in ${!files_download_command_sub1[*]}
		do
	        	echo ${files_download_command_sub1[$file]}
			echo ${files_download_command_sub1[$file]} >> command
		done
	fi

	if [ ! -z "$SUB_WORKSET_2" ];then
		for file in ${!files_download_command_sub2[*]}
		do
        		echo ${files_download_command_sub2[$file]}
			echo ${files_download_command_sub2[$file]} >> command
		done
	fi

	chmod 777 command

	echo "DOWNLOAD Start"
	
	#/opt/serena/dimensions/10.1/cm/prog/dmcli -con ebx_DIM_10_New -user aramesh -pass Toshiba1 -file command > pvcs.log 2>&1
	#/opt/serena/dimensions/10.1/cm/prog/dmcli -user tsaurabh -pass dldlteam -host TEC-MSSD003 -dbname ebx -dsn ora11dim -file command > pvcs.log 2>&1
	echo "dmcli -user $DIM_USR_NAME -pass $DIM_USD_PWD -host $DIM_HOST_NAME -dbname $DIM_DB_NAME -dsn $DIM_DB_CONN_NAME"
	#/opt/serena/dimensions/10.1/cm/prog/dmcli -user $DIM_USR_NAME -pass $DIM_USD_PWD -host $DIM_HOST_NAME -dbname $DIM_DB_NAME -dsn $DIM_DB_CONN_NAME -file command > pvcs.log 2>&1
	/opt/serena/dimensions/10.1/cm/prog/dmcli -user t0573526 -pass snmp1994 -host tec-mssd003 -dbname ebx -dsn dim14 -file command > pvcs.log 2>&1
	RET_VAL=$?
	echo "dimention ret_val=$RET_VAL"
	chmod 777 pvcs.log
	x=`grep -cy "expired\|Failed to start" pvcs.log`
#x=0	
	if [ $x -eq 1 ]
	then
		echo "No Error in Downloading "
	else
		echo "$x errors in downloading file"
		tmp=`cat pvcs.log | grep -e "$WORKSET" | grep -c "does not exist"`
		if [ "$tmp" -ne 0 ]
		then
			echo "Please Enter a valid WORKSET"
			exit -1
		fi
		tmp1=`cat pvcs.log | grep -e "$SUB_WORKSET_1" | grep -c "does not exist"`
                if [ "$tmp1" -ne 0 ]
                then
                        echo "Please Enter a valid SUB_WORKSET_1"
                        exit -1
                fi
		tmp2=`cat pvcs.log | grep -e "$SUB_WORKSET_2" | grep -c "does not exist"`
                if [ "$tmp2" -ne 0 ]
                then
                        echo "Please Enter a valid SUB_WORKSET_2"
                        exit -1
                fi		
		echo "Trouble in Downloading files from Dimensions"
		exit -1
	fi
	
	if [ -d "05_Implement" ]
	then
		chmod 777 05_Implement/
		echo "05_Implement download completed"
	else
		echo "Some problem in Downloading files May be the WORKSET $WORKSET doesnot contain any files"
		exit -1
	fi
}

function remove_existing_binaries
{
	echo "Removing the existing Binaries and Libraries"
	for rmv_file in ${chk_files[*]}
	do
		if [ -a $rmv_file ]
		then
			rm $rmv_file
		fi
	done
	
	if [ -a completed_list ] 
	then
		rm completed_list
	fi
	
#	if [ -a mail ]
#	then
#		rm mail
#	fi

#	if [ -a Available_List ]
##	then
#		rm Available_List
#	fi

#	if [ -a UnAvailable_List ]
#	then
#		rm UnAvailable_List
#	fi

}

function Copy_Files
{
	rm -rf $SYS_PATH/dev/AL/
	cp -r $COMPILATION_PATH/05_Implement/SYSROM_SRC/* $SYS_PATH/  
	cp /home/eBN/Makefile_AL_TESI $SYS_PATH/dev/AL/
	cp /home/eBN/Makefile_anand $SYS_PATH/dev/AL/SoftwareFunction/
	echo "Copied files from 05_Implement/ to SYSROM_SRC/"
}

function apply_env
{
	## Cross compiler for ISYS board
	#export PATH=$PATH:/opt/WindRiver40/wrlinux-4/sysroots/mfp_sys210d-glibc_std/x86-linux2/:/opt/WindRiver40/wrlinux-4/layers/wrll-toolchain-4.4a-323/powerpc/toolchain/x86-linux2/bin:/opt/WindRiver40/wrlinux-4/layers/wrll-toolchain-4.4a-323/i586/toolchain/x86-linux2/bin:/opt/WindRiver40/wrlinux-4/foundation//x86-linux2/wrbin
	export PATH=$PATH:/opt/WindRiver30/wrlinux-3.0/sysroots/mfp_sys470d-glibc_std/x86-linux2:/opt/WindRiver30/wrlinux-3.0/sysroots/mfp_sys430exd-glibc_cgl/x86-linux2:/opt/WindRiver30/wrlinux-3.0/layers/wrll-toolchain-4.3-85/powerpc/toolchain/x86-linux2/bin
	#export TOOLCHAIN_PATH=/opt/WindRiver40/wrlinux-4/sysroots/mfp_sys210d-glibc_std/sysroot	
	export TOOLCHAIN_PATH=/opt/WindRiver30/wrlinux-3.0/sysroots/mfp_sys470d-glibc_std/sysroot
	#. setup_isys.sh
	echo "Applying setenv"
#anand::changed
#	cd SYSROM_SRC
	cd $SYS_PATH/
	PWD=`pwd`
	ls -l setenv
	# anand:: hard coded the below line
	. /home/eBN/setenv_icc
	. $PWD/setenv
	echo $EB2
	cd $COMPILATION_PATH 
	echo "Settings Completed"
}

function Compile
{
	echo -e "------------------------------------------------------------------\n" >> $SYS_PATH/dev/AL/mail
	echo -e "Compilation StartTime -`date`\n ">> $SYS_PATH/dev/AL/mail
	echo "Compilation Started \n"
	if [ -a $SYS_PATH/dev/AL/build.logs ] 
	then
		rm $SYS_PATH/dev/AL/build.logs
	fi
	
#	if [ -a error.logs ];
#	then
#		rm error.logs
#	fi
	
	if [ "$LAYER" = "-al" ];then
		echo "Building Al Components"
		#sh $SYS_PATH/Makefile_AL_TESI -s 2>&1 | tee build.logs
		cd $SYS_PATH/dev/AL/
		#system("cd dev/AL/ && make -f Makefile_AL_TESI clean all > build.logs 2>&1");
		 make -f Makefile_AL_TESI all > build.logs 2>&1
	fi
	
	chmod +x build.logs
	echo -e "Compilation EndTime:`date` \n" >> $SYS_PATH/dev/AL/mail

	echo "Compilation Completed"
	echo -e "------------------------------------------------------------------\n" >> $SYS_PATH/dev/AL/mail
	setup_cnt=`cat build.logs | grep -c "Please run setenv script firstly..."`
	if [ "$setup_cnt" -eq 1 ]
	then
		echo "setup_isys.sh is not executed"
		exit -1
	fi
	
	chk=`grep -c ":.error" build.logs`
	if [ "$chk" -eq 0 ]
	then
		Build_Status="OK" 
		echo "Compilation is completed without Errors."
		cat mail 
		echo -e "Compilation is completed without Errors.\n" >> mail
	else
		Build_Status="ERROR"
		echo "Compilation is completed with Errors.Please check the build.logs for further details. "
		echo -e " \n" >> mail
		echo -e "Compilation is completed with Errors.Please check the build.logs.tar.gz for further details.\n " >> mail
		echo -e "\n" >> mail
		echo -e "Please check the below Errors: \n" >> mail
		echo -e "============================================\n" >> mail
		echo `grep "error:" build.logs` >> mail
		echo -e " \n" >> mail
		echo -e "=============================================\n" >> mail
		
	fi		
}

function check_build
{
	
		echo "Checking for the libraries and binaries"
	#if [ "$Build_Status" = "OK" ];then
	#	echo -e " \n" >> mail
	#	echo -e "Following binaries are built successfully : \n" >> mail
	#	echo -e "**********************************************\n" >> mail
		for file in ${chk_files[*]}
		do
			echo $file
			if [ -f $file ]	
			then
				echo -e "$file available \n" >> completed_list
				echo -e "$file\n" >> Available_List
			else
				echo -e "$file not available\n " >> completed_list
				echo -e "$file\n" >> UnAvailable_List
			fi
		done
		chmod +x completed_list
		cnt=`grep -c "not available" completed_list`
		if [ $cnt -eq 0 ]
		then
			echo "All Compiled binaries and Libraries are available @below location "
			echo -e "All Compiled binaries and Libraries are available @below location\n" >> mail
			echo -e "$SYS_PATH\n" >> mail
			#echo "Thank you for your support." >> mail
			echo -e "Following binaries are built successfully : \n" >> mail
		 	echo -e "******************************************************************\n" >> mail
		#	`grep -e "available" completed_list >> mail`			
			cat Available_List >> mail
		#	echo -e "\n" >> mail
			echo -e "******************************************************************\n" >> mail
		else
			Build_Status="Linking Error"
			echo "$cnt files are not available in the below location Please check"
			echo -e "$cnt files are not available in the below location\n" >> mail
			echo -e "$SYS_PATH\n" >> mail
			echo -e "Following binaries are failed : \n" >> mail
		 	echo -e "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n" >> mail
			#`grep -e "not available" completed_list >> mail`
			cat UnAvailable_List >> mail
			echo -e "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n" >> mail
		fi
	#fi	

}

function Mail_Details
{
	echo "" > $SYS_PATH/dev/AL/mail
	echo -e "Hi all,\n" >> $SYS_PATH/dev/AL/mail
	echo -e "The build check for following WORKSET combination downloaded in the Path : $SYS_PATH is completed\n." >>$SYS_PATH/dev/AL/mail
	echo -e "=================================================================================================================\n" >>$SYS_PATH/dev/AL/mail
	if [[ -n $SUB_WORKSET_2 ]]; then	
#		echo -e "**********************************************\n">>$SYS_PATH/dev/AL/mail
		echo -e " MAIN_WORKSET = $WORKSET \n">>$SYS_PATH/dev/AL/mail
		echo -e " SUB_WORKSET_1= $SUB_WORKSET_1\n">>$SYS_PATH/dev/AL/mail
		echo -e " SUB_WORKSET_2= $SUB_WORKSET_2\n">>$SYS_PATH/dev/AL/mail
		echo -e "********************************************************\n">>$SYS_PATH/dev/AL/mail
	else
		
#		echo -e "**********************************************\n">>$SYS_PATH/dev/AL/mail
		echo -e " MAIN_WORKSET = $WORKSET \n">>$SYS_PATH/dev/AL/mail
		echo -e " SUB_WORKSET_1= $SUB_WORKSET_1 \n">>$SYS_PATH/dev/AL/mail
		echo -e "********************************************************\n">>$SYS_PATH/dev/AL/mail
	fi
	if [ "$LAYER" = "-al" ];then
		echo -e "The compilation for AL-Plugin components are completed.\n " >> $SYS_PATH/dev/AL/mail
	fi		
}

function send_mail
{
#	echo -e"\n" >> mail 
	echo -e "Regards,\n" >> mail
	echo -e "BuildCheck_AL_Plugin\n" >> mail
	tar -czf build.logs.tar.gz build.logs 
#	echo "AL-Plugin\@toshiba-tsip.com" > maillist.txt
#	echo "AL-Plugin\@toshiba-tsip.com" > maillist.txt

#	MAILTO=`cat maillist.txt`
	
	#`/usr/bin/mailx -s " Compilation Status : [ $Build_Status ]  < $PROD_NAME > " -r NoReply@BuildCheck.DL -a build.logs.tar.gz $MAILTO < mail`
	#`/usr/bin/mailx -v -s " Compilation Status : [ $Build_Status ] <$TARGET> < $PROD_NAME > " -a build.logs.tar.gz AL-Plugin\@toshiba-tsip.com < mail`
	#`/usr/bin/mailx -v -s " Compilation Status : [ $Build_Status ] <$TARGET> < $PROD_NAME > " -a build.logs.tar.gz AL-Plugin\@toshiba-tsip.com < mail`
	`/usr/bin/mailx -v -s " Compilation Status : [ $Build_Status ] <$TARGET> < $PROD_NAME > " -a build.logs.tar.gz Prabath.muthusamy\@toshiba-tsip.com < mail`
}

pre_chk
echo "Worksets are"
echo $WORKSET
echo $SUB_WORKSET_1
echo $SUB_WORKSET_2
chk_lyr
DownLoad
apply_env
remove_existing_binaries
Copy_Files
Mail_Details
Compile
check_build
#send_mail

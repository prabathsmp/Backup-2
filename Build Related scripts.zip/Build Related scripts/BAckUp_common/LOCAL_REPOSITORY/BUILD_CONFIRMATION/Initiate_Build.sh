Product_array=(
MATTERHORN
WEISS_3H
WEISS2H
WEISS2L
REUSS
CASPIAN
SHASTA
SHASTINA
	)

Target_array=(
L6.5
L6.02
L6.03
	)

for product in ${Product_array[*]}
do
	for target in ${Target_array[*]}
	do
		sh /home/eBN/LOCAL_REPOSITORY/BUILD_CONFIRMATION/Build_Check_EBN.sh $product $target
		out=$?
		if [ $out -ne -1 ];then
			echo "$product vs $target combination success!!!"
		else
			echo "Invalid combination!!!"
		fi
		echo "=================================================================="
        done
done

echo "done.........."



